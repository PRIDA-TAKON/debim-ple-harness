# Process Cooling Water (PCW) Cleaning, Flushing and Passivation
## Method of Procedure (MOP) & Commissioning Design Basis
### Tull Creek Data Hall — Turnover Package
**Document Identifier:** MOP-PCW-2026-001  
**Revision:** Rev 0 (Issued for Turnover)  
**Contractor:** Commissioning Flushing Contractor  
**Governing Specifications:** Section 23 25 16 Rev 3, Section 23 21 16 Rev 3, Section 01 91 13  
**Adopted Water Treatment Standard:** UFC 3-230-13 (Water Treatment, 2023 Edition)  
**Pretreatment Standard:** 40 CFR 403 & Industrial Wastewater Discharge Permit SW-03 RevB  
**Hazard Communication Standard:** 29 CFR 1910.1200 & VD-07 Safety Data Sheet Package  

---

## 1. Executive Summary & Situation

The Process Cooling Water (PCW) hydronic distribution loop at the Tull Creek Data Hall is mechanically complete. The installation comprises eight distinct tie-in-bounded piping circuits spanning multiple mechanical equipment rooms (MER-1, MER-2), white-space data hall zones (Level 3 North, South, West), a roof-mounted fluid cooler terrace, and an outdoor yard storage installation. The network encompasses varied metallurgies including Schedule 40 carbon steel main distribution headers, Type L hard-drawn copper branch piping, 6061-T6 aluminum micro-channel server cold plates, 316 stainless steel plate heat exchanger packs, and hot-dip galvanized steel exterior piping and thermal storage.

Before final turnover to the owner, every circuit must be hydrostatically proved, hydraulically flushed of construction debris, chemically cleaned to remove mill scale, oils, and particulate matter, displaced with clean rinse water to strict ionic conductivity limits, chemically passivated to establish robust protective surface conversion films, and placed on long-term chemical maintenance treatment.

This commissioning campaign is executed under rigorous site and commercial boundary conditions:
1. **Rented Fleet:** A fixed fleet of three skid-mounted pumping units on hire: two FS-600 units (`FS-600-A`, `FS-600-B`) available from mobilization, and one high-capacity FS-1200 unit (`FS-1200-A`) delivered at hour 48 per Site Instruction SI-05.
2. **Construction Water Allocation:** Metered municipal water supply subject to daily draw allocations (SW-01), with scheduled municipal utility restrictions reducing capacity on Days 2, 3, and 6 (Site Instruction SI-04).
3. **Environmental Discharge Permit:** A single authorized sewer discharge connection at metered yard manhole MH-14 governed by Industrial Wastewater Discharge Authorization Permit IWD-2026-0417-RevB (`SW-03 RevB`), enforcing a strict cumulative programme cap of 480,000 gallons and stringent local pretreatment limits for heavy metals (copper $\le 1.5$ mg/L, zinc $\le 2.0$ mg/L, molybdate $\le 50$ mg/L). Direct discharge to Tull Creek or site storm sewers is strictly prohibited.
4. **Temporary Electrical Power:** Maximum simultaneous connected loads restricted at individual temporary power panels (MER-1 150 kW, MER-2 95 kW, L3-N 90 kW, L3-S 90 kW, L3-W 90 kW, ROOF 45 kW, YARD 120 kW) per SW-04 and single-line drawing E-701.
5. **Attended Labor & Crew Structure:** Exactly two 12-hour commissioning crews (`CREW-1`, `CREW-2`) operating concurrently without exceeding single-activity engagement per crew.
6. **Milestone Schedule:** Contractual milestone dates defined in CX-01 RevB:
   - **TM-1:** Hydrostatic testing complete by Day 6 (hour 144).
   - **TM-2:** Chemical cleaning complete by Day 22 (hour 528).
   - **TM-3:** Passivation film formation complete by Day 44 (hour 1056).
   - **TM-4:** Final turnover and temporary strainer removal by Day 47 (hour 1128).

Through detailed hydraulic modeling, chemical metallurgy pairing, displacement rinse optimization, and selective off-site effluent haulage, this Method of Procedure successfully discharges all technical and statutory mandates at a total programme cost of **$112,803.18**, turning over the complete PCW system at hour 1087.0 (Day 45.3), well within the contractual window.

---

## 2. Hierarchy of Truth & Governing Engineering Authority

In accordance with professional engineering quality assurance and quality control (QA/QC) standards, all engineering determinations, parameters, and conflicts are resolved strictly by order of governing authority:

- **Tier 1 (Highest Authority):** Executed Regulatory Permits (SW-03 RevB), Formal Site Instructions (SI-04, SI-05), and Approved Client Clarifications (RFI-031). These supersede all prior draft authorizations and tender documentation.
- **Tier 2:** Issued-for-Construction (IFC) Mechanical Drawings and Schedules: P&ID sheets M-PID-101 through M-PID-104 (Rev C), Isometric drawings M-ISO-201 through M-ISO-204 (Rev C), Piping Schedule M-601 (Rev C), Equipment Schedule M-602 (Rev C), and Valve & Tie-In Schedule M-603 (Rev C). These supersede general notes and uncoordinated schematics.
- **Tier 3:** Technical Project Specifications and Adopted Public Standards: Section 23 25 16 Rev 3, Section 23 21 16 Rev 3, Section 01 91 13, Unified Facilities Criteria UFC 3-230-13 (2023 edition), Department of Energy Fundamentals Handbook DOE-HDBK-1012/3-92, 40 CFR 403 (General Pretreatment Regulations), and 29 CFR 1910.1200 (OSHA Hazard Communication).
- **Tier 4:** Site Logistics and Electrical Overview Plans: Site Logistics Plan C-101 and Temporary Power Single Line Diagram E-701.
- **Tier 5 (Lowest / Non-Governing):** Preliminary takeoffs, vendor sales brochures, superseded draft permits, and cancelled legacy standards.

---

## 3. Document Defect Logging & Review of Rejected Documents

A formal audit of the project document library identified several superseded, cancelled, out-of-scope, and defective documents. In strict adherence to Section 23 25 16 and QA/QC principles, these documents were formally reviewed, evaluated, and rejected as governing authorities. They are explicitly excluded from the constraint register and are documented below:

### 3.1 Rejected / Cancelled Standards & Specifications
1. **`UFC 3-240-13FN` (Industrial Water Treatment Operation and Maintenance):**  
   *Review & Finding:* This military standard was officially cancelled and superseded by the tri-service publication **UFC 3-230-13** (Water Treatment, 2023 Edition). UFC 3-240-13FN contains obsolete chemistry guidelines (e.g., chromate and unbuffered nitrite) that violate modern environmental and data hall equipment metallurgy limits.  
   *Disposition:* **REJECTED.** UFC 3-230-13 (2023) is adopted as the sole governing water-treatment criteria document.
2. **`Section 22 11 23` (Domestic Water Pumps):**  
   *Review & Finding:* This excerpt specifies domestic potable water booster pumps, pressure maintenance, and NSF 61 sanitization. Potable water plumbing standards do not govern hydronic process cooling water loops.  
   *Disposition:* **REJECTED.** Out of scope.
3. **`VD-08` (Comfort Cooling Water Treatment Submittal):**  
   *Review & Finding:* Reviewed vendor submittal for glycol/chilled water comfort cooling HVAC systems serving administrative areas. The data hall PCW loop operates as a closed unglycolized loop with specialized low-temperature IT heat rejection.  
   *Disposition:* **REJECTED.** Inapplicable to the PCW data hall scope.
4. **`RFI-009` & `RFI-022`:**  
   *Review & Finding:* RFI-009 addresses comfort cooling biocide selection; RFI-022 discusses domestic copper sanitization.  
   *Disposition:* **REJECTED.** Out of scope.
5. **`40 CFR 122` (EPA National Pollutant Discharge Elimination System - NPDES):**  
   *Review & Finding:* 40 CFR 122 governs direct point-source discharges into waters of the United States (such as direct outfall to Tull Creek). Permit SW-03 RevB Section 3 strictly prohibits direct or indirect discharge to the creek or storm sewers. All site discharges are indirect discharges to the municipal POTW governed by **40 CFR 403** and local permit SW-03 RevB, or hauled off-site.  
   *Disposition:* **REJECTED.** Direct surface water discharge is not permitted.

### 3.2 Superseded Revisions & Drawing Defects
1. **`SW-03 RevA` vs `SW-03 RevB` (Discharge Authorization Permit):**  
   *Review & Finding:* Preliminary authorization SW-03 RevA indicated a tentative sewer allocation of 540,000 gallons and omitted specific local metal pretreatment limits. On April 17, 2026, the municipal sanitary authority issued **Permit IWD-2026-0417-RevB (SW-03 RevB)**, reducing the cumulative sewer cap to **480,000 gallons** and enacting hard local limits for copper ($\le 1.5$ mg/L), zinc ($\le 2.0$ mg/L), and molybdate ($\le 50$ mg/L).  
   *Disposition:* **SW-03 RevA is SUPERSEDED and REJECTED.** SW-03 RevB governs all effluent accounting. Draft language in RFI-031 referencing 540,000 gal is superseded by the legally binding permit cap of 480,000 gal.
2. **`M-PID-103 RevA` vs `M-PID-103 RevC`:**  
   *Review & Finding:* Rev A omitted temporary bypass spool connections across server cold-plate manifold banks CP-311/321/331 and lacked tie-in isolation valves. Rev C incorporates full bypass spools and 4-inch tie-in valves.  
   *Disposition:* **M-PID-103 RevA is SUPERSEDED and REJECTED.** Rev C governs.
3. **`CX-02` Hydrostatic Test Record Defect:**  
   *Review & Finding:* The hydrostatic test log carries approved test records with pressure-time recorder charts for Circuit C1 (TR-0412), Circuit C2 (TR-0413), Circuit C4 (TR-0415), and Circuit C8 (TR-0419), all certified at 127.5 psig for 120 minutes. However, Circuits **C3, C5, C6, and C7** are missing recorder charts and formal acceptance signatures.  
   *Disposition:* In accordance with Section 23 21 16 cl. 3.3 and Section 23 25 16 cl. 3.1, Circuits C1, C2, C4, and C8 are accepted on record, while **Circuits C3, C5, C6, and C7 owe hydrostatic testing** on site. These tests are scheduled and performed during Stage 1 under Milestone TM-1.

---

## 4. Circuit Definitions, Boundaries, Metallurgy & Hold-Up Volumes

The PCW system is bounded by permanent sectionalizing butterfly valves and temporary tie-in manifolds into eight distinct commissioning circuits:

### 4.1 Circuit Breakdown and Equipment Protection
- **Circuit C1 (Primary Pumping Loop):** Located in MER-1 and yard header trench. Consists of 12" NPS carbon steel supply/return distribution mains and 6" pump headers. Bounded by tie-in valves TV-101 and TV-102. Wetted components: Primary pumps PMP-101A/B/C/D (2,400 gal hold-up) and buffer tank BT-101 (5,000 gal hold-up). Per M-602 and cl. 3.1, PMP-101 and BT-101 have large internal clearances and are unbypassed during flushing.
- **Circuit C2 (Plate Heat Exchanger Bank A):** Located in MER-1. Consists of 8" NPS CS mains and 4" branch runs connecting Plate Heat Exchanger HX-201A. Bounded by TV-201 and TV-202. Per VD-03 Note 2, PHE packs are fitted with temporary bypass spools during flushing and chemical cleaning to prevent clogging narrow plate corrugations. Hold-up of HX-201A is 2,350 gal.
- **Circuit C3 (Plate Heat Exchanger Bank B):** Located in MER-2. Consists of 8" NPS CS mains and 6" branch runs connecting Plate Heat Exchanger HX-201B. Bounded by TV-203 and TV-204. HX-201B (2,350 gal hold-up) is bypassed during flushing and cleaning.
- **Circuit C4 (Level 3 North Data Hall Loop):** Located in L3-N white space. Consists of 6" CS headers, 4" CS runouts, and 3" Type L hard-drawn copper drops. Connects Coolant Distribution Unit CDU-301 (1,550 gal) and cold-plate manifold bank CP-311 (1,030 gal). Both CDU-301 and CP-311 are bypassed with temporary spools during construction flushing.
- **Circuit C5 (Level 3 South Data Hall Loop):** Located in L3-S white space. Consists of 6" CS headers, 4" CS runouts, and 3" copper drops. Connects CDU-302 (1,550 gal) and CP-321 (1,030 gal). Both components are bypassed during construction flushing.
- **Circuit C6 (Level 3 West High-Density R&D Loop):** Located in L3-W white space. Consists of 6" CS headers and 3" copper runouts serving high-density cold-plate bank CP-331 (1,450 gal hold-up). Wetted parts of CP-331 include 6061-T6 aluminum micro-channel cold plates (VD-04). CP-331 is bypassed during flushing and chemical cleaning.
- **Circuit C7 (Roof Fluid Cooler Terrace Loop):** Located on the elevated roof terrace (+72 ft static lift). Consists of 6" CS risers and 2.5" copper drops serving closed-circuit cooling coil CL-401 (1,950 gal hold-up). CL-401 is bypassed during flushing and chemical cleaning.
- **Circuit C8 (Thermal Energy Storage Loop):** Located in the exterior equipment yard. Consists of 4" and 3" Schedule 40 hot-dip galvanized steel piping serving atmospheric thermal storage vessel ST-601 (3,750 gal hold-up). ST-601 is unbypassed during flushing.

### 4.2 Exact Hold-Up Volume Audit
Pipe volumes are computed from nominal pipe schedule lengths and internal diameters from Schedule M-601 Rev C ($V = \frac{\pi D^2}{4} L$). Equipment hold-up volumes are taken directly from Schedule M-602 Rev C. The FLUSH volume ($V_f$) represents the volume circulating during construction flushing with bypasses fitted. The SYSTEM volume ($V_s$) includes all unbypassed equipment brought online at turnover:

$$\begin{array}{|c|c|c|c|c|c|c|}
\hline
\textbf{Circuit} & \textbf{Piping Volume (gal)} & \textbf{Connected Equipment} & \textbf{Equip Vol (gal)} & \textbf{Bypass Fitted?} & \textbf{Flush Vol } V_f \textbf{ (gal)} & \textbf{System Vol } V_s \textbf{ (gal)} \\
\hline
\text{C1} & 25,583.4 & \text{PMP-101, BT-101} & 7,400.0 & \text{No} & 32,983.4 & 32,983.4 \\
\text{C2} & 5,596.0 & \text{HX-201A} & 2,350.0 & \text{Yes} & 5,596.0 & 7,946.0 \\
\text{C3} & 6,203.2 & \text{HX-201B} & 2,350.0 & \text{Yes} & 6,203.2 & 8,553.2 \\
\text{C4} & 5,956.6 & \text{CDU-301, CP-311} & 2,580.0 & \text{Yes} & 5,956.6 & 8,536.6 \\
\text{C5} & 6,405.8 & \text{CDU-302, CP-321} & 2,580.0 & \text{Yes} & 6,405.8 & 8,985.8 \\
\text{C6} & 4,227.1 & \text{CP-331} & 1,450.0 & \text{Yes} & 4,227.1 & 5,677.1 \\
\text{C7} & 4,086.0 & \text{CL-401} & 1,950.0 & \text{Yes} & 4,086.0 & 6,036.0 \\
\text{C8} & 2,040.8 & \text{ST-601} & 3,750.0 & \text{No} & 5,790.8 & 5,790.8 \\
\hline
\end{array}$$

---

## 5. Hydraulic Modeling, Friction Loss & Flush Skid Selection

### 5.1 Governing Principles and Velocity Criteria
Hydraulic calculations are governed by **DOE-HDBK-1012/3-92** and Section 23 25 16 cl. 3.2. Water at 68 °F is modeled with kinematic viscosity $\nu = 1.08 \times 10^{-5}$ ft$^2$/s and density $\rho = 62.30$ lbm/ft$^3$. Surface absolute roughness is taken as $e = 0.00015$ ft for carbon steel, $e = 0.000005$ ft for drawn copper, and $e = 0.0005$ ft for hot-dip galvanized steel.

Flushing velocity must satisfy two governing requirements:
1. **Critical Equipment Scour Velocity:** Section 23 25 16 cl. 3.2 mandates a minimum flushing velocity of **4.00 ft/s** through the governing segment of any circuit serving plate heat exchangers or cold-plate manifold banks (Circuits C2, C3, C4, C5, C6).
2. **Particulate Suspension Velocity:** UFC 3-230-13 Section 5-3.7 mandates a minimum velocity of **3.28 ft/s** (1.0 m/s) to maintain suspension and transport of heavy sand, mill scale, and welding slag in distribution and storage circuits (Circuits C1, C7, C8).

### 5.2 Mathematical Formulation
For each line segment carrying flow $Q_{leg}$ through internal diameter $D$:
- Velocity: $v = \frac{Q_{leg}}{A}$
- Reynolds Number: $\text{Re} = \frac{v D}{\nu}$
- Friction factor $f$ is solved deterministically via the implicit Colebrook-White equation:
  $$\frac{1}{\sqrt{f}} = -2.0 \log_{10} \left( \frac{e/D}{3.7} + \frac{2.51}{\text{Re} \sqrt{f}} \right)$$
- Pipe friction and fitting loss: $h_f = f \frac{L + \sum (L/D) D}{D} \frac{v^2}{2g}$
- Component loss: Storage tank ST-601 scales as $\Delta h = 6.0 \left( \frac{Q}{120} \right)^2$ ft w.c.
- Temporary lay-flat hose: 300 ft total (150 ft supply + 150 ft return, $e = 0.0008$ ft; ID 4.026" for FS-600, 7.981" for FS-1200).
- Temporary 40-mesh basket strainer: $\Delta h_{str} = 11.0 \left( \frac{Q_{skid}}{600} \right)^2$ ft w.c.
- Total required head: $H_{req} = h_{stat} + \sum h_{f,main} + h_{comp} + h_{hose} + h_{str}$

### 5.3 Skid Fleet Head Availability and Selection
The available head is determined by linear interpolation of reviewed pump curves from VD-01 (FS-600) and VD-02 (FS-1200):
- **FS-600 (30 kW):** 182 ft @ 0 gpm, 176 ft @ 150 gpm, 163 ft @ 300 gpm, 141 ft @ 450 gpm, 106 ft @ 600 gpm, 74 ft @ 700 gpm.
- **FS-1200 (75 kW):** 212 ft @ 0 gpm, 204 ft @ 300 gpm, 188 ft @ 600 gpm, 159 ft @ 900 gpm, 117 ft @ 1200 gpm, 82 ft @ 1400 gpm.

$$\begin{array}{|c|c|c|c|c|c|c|c|c|c|}
\hline
\textbf{Circuit} & \textbf{Assigned Skid} & \textbf{Flow (gpm)} & \textbf{Gov Seg} & \textbf{ID (in)} & \textbf{Velocity (fps)} & \textbf{Reynolds} & H_{req} \textbf{ (ft)} & H_{avail} \textbf{ (ft)} & \textbf{Head Margin} \\
\hline
\text{C1} & \text{FS-1200-A} & 1200 & 1043 & 6.065 & 3.33 & 155,910 & 90.20 & 117.00 & +22.91\% \\
\text{C2} & \text{FS-1200-A} & 630 & 2011 & 7.981 & 4.04 & 248,810 & 49.32 & 185.10 & +73.35\% \\
\text{C3} & \text{FS-1200-A} & 725 & 2023 & 6.065 & 4.03 & 188,392 & 57.09 & 175.92 & +67.55\% \\
\text{C4} & \text{FS-600-A} & 365 & 4021 & 6.065 & 4.07 & 189,952 & 100.31 & 153.47 & +34.67\% \\
\text{C5} & \text{FS-600-B} & 480 & 4031 & 6.065 & 5.35 & 249,799 & 131.24 & 134.00 & +2.06\% \\
\text{C6} & \text{FS-600-A} & 365 & 4041 & 6.065 & 4.07 & 189,952 & 103.41 & 153.47 & +32.62\% \\
\text{C7} & \text{FS-600-A} & 300 & 5011 & 6.065 & 3.34 & 156,124 & 108.22 & 163.00 & +33.61\% \\
\text{C8} & \text{FS-600-B} & 155 & 6011 & 4.026 & 3.91 & 121,570 & 69.51 & 175.60 & +60.42\% \\
\hline
\end{array}$$

*Key Engineering Finding on Circuit C2:* An initial evaluation using a single FS-600 skid at 630 gpm revealed a required head of 134 ft w.c. against an available head of only 96.4 ft w.c., resulting in a fatal **-39.0% deficit**. This was caused by extreme friction loss (112.5 ft) through the 300 ft of 4-inch lay-flat hose at 630 gpm. Assigning the high-head FS-1200-A skid with 8-inch lay-flat hoses reduces hose friction to 3.8 ft and provides 185.1 ft w.c. available head, securing a robust **+73.35% head margin**. MER-1 has 150 kW available power, readily accommodating the 75 kW FS-1200 skid.

---

## 6. Chemical Treatment Chemistry, Passivation & Turnover Strategy

### 6.1 Pre-Operational Chemical Cleaning
Per Section 23 25 16 cl. 2.1 and UFC 3-230-13 Section 5-7.3.2.2, cleaner selection is strictly governed by system metallurgy:
- **Alkaline Cleaner (CL-100):** Dosed at 1.5 gal / 1,000 gal on Circuits C1, C2, C3, C4, C5, and C7 (all carbon steel, stainless steel, and copper). Removes grease, cutting oils, light mill scale, and organic soils. Controlled to pH 9.0–11.0. Circulated for a minimum of 24.0 hours at flushing flow.
- **Neutral Cleaner (CL-210):** Dosed at 2.0 gal / 1,000 gal on Circuit C6 (containing 6061-T6 aluminum cold plates CP-331) and Circuit C8 (containing hot-dip galvanized steel). Alkaline cleaners aggressively dissolve amphoteric aluminum (releasing hydrogen gas and pitting micro-channels) and strip protective zinc oxide/carbonate layers from galvanized steel. CL-210 buffers circulating pH strictly between 7.5 and 8.5, safely emulsifying oils and debris without metallurgic damage.
- **Polymeric Dispersant (PD-45):** Dosed across all circuits during chemical cleaning at an active polymer concentration of **4.0 ppm** (UFC 3-230-13 cl. 5-3.7). PD-45 prevents suspended silt and iron oxide particulate from redepositing in dead legs or low-velocity zones.

### 6.2 Passivation Programs and Metallurgy Compatibility
Passivation establishes a dense, self-healing inorganic conversion coating over freshly degreased metal surfaces. Program selection complies with UFC 3-230-13 Tables 5-14 and 5-15:
- **Molybdate-Azole Program (MO-500 + TA-90):**
  - **Circuits C1, C2, C3:** Carbon steel metallurgy. Passivated at **50.0 ppm as Mo** using MO-500 (35% sodium molybdate liquid). Controlled to pH 7.5–8.5.
  - **Circuits C4, C5, C7:** Mixed carbon steel and copper metallurgy. Dosed with MO-500 (50.0 ppm Mo) plus tolyltriazole solution TA-90 (**10.0 ppm as TTA**). Per cl. 3.8, when combining inhibitors with partially overlapping pH windows (molybdate 7.5–8.5, azole 7.5–7.9), circulating chemistry is controlled strictly to the **intersection band: pH 7.5–7.9**.
- **Polysilicate-Azole Program (PS-330 + TA-90):**
  - **Circuit C6 (Aluminum & Copper):** 6061-T6 aluminum micro-channel cold plates require an active silicate barrier to prevent pitting. Passivated at **45.0 ppm as SiO2** using PS-330 (33% liquid polysilicate) plus TA-90 (**10.0 ppm as TTA**). Controlled strictly to pH 7.5–7.9.
  - **Circuit C8 (Galvanized Steel):** Hot-dip galvanized steel requires silicate passivation to cure the zinc carbonate matrix and eliminate white rust formation (UFC 6-2.2.5). Passivated at **45.0 ppm as SiO2**. Controlled to pH 7.5–8.5.
- **Passivation Hold Duration:** All circuits are held statically under passivation chemistry for exactly **14.0 days (336.0 hours)** to allow complete crystal barrier formation (Milestone TM-3).

### 6.3 Turnover Strategy: RETAIN_AND_TOP_UP
Section 23 25 16 cl. 3.8 permits two turnover options: `RETAIN_AND_TOP_UP` or `DRAIN_AND_REFILL`.  
This plan selects **`RETAIN_AND_TOP_UP`** across all eight circuits.
- **Technical Basis:** UFC 3-230-13 Section 6-2 mandates long-term maintenance residuals of **100 ppm Mo** (for molybdate loops) and **80 ppm SiO2** (for silicate loops). Because the maintenance residuals exceed the initial passivation hold residuals (50 ppm Mo and 45 ppm SiO2), topping up the circuit with treated makeup water containing the maintenance charge directly elevates inhibitor concentrations to target levels without diluting the protective film.
- **Environmental & Economic Justification:** `RETAIN_AND_TOP_UP` completely avoids dumping 72,185 gallons of treated passivation water to the sewer, eliminating chemical waste, saving $1,118.87 in sewer fees, and preserving the municipal sewer cap.

---

## 7. Water Management, Daily Allocations & Rinse Dilution Modeling

### 7.1 Project Rinse Displacement Dilution Model
Rinse water displacement dynamics after chemical cleaning are governed by Section 23 25 16 cl. 3.6:
$$C_n = C_{mk} + (C_0 - C_{mk}) \exp(-\eta n)$$
where:
- $C_{mk} = 142.0\ \mu\text{S/cm}$ (Makeup water baseline conductivity from SW-02 lab analysis).
- $C_0 = 2600.0\ \mu\text{S/cm}$ for spent CL-100; $C_0 = 2150.0\ \mu\text{S/cm}$ for spent CL-210 (VD-06 Note 3).
- $\eta = 0.45$ for circuits with parallel cold-plate or coil banks (Circuits C4, C5, C6, C7).
- $\eta = 0.62$ for all other circuits (Circuits C1, C2, C3, C8).
- Acceptance Threshold: $C_n \le 1.10 \times C_{mk} = 142.0 \times 1.10 = \mathbf{156.2\ \mu\text{S/cm}}$.

Solving for the required whole number of displacements $n_r$:
- **Circuits C1, C2, C3:** $\eta = 0.62, C_0 = 2600 \implies n_r = 9 \implies C_9 = 151.27\ \mu\text{S/cm}$ (Limit: 156.2; Margin: $+3.15\%$).
- **Circuits C4, C5:** $\eta = 0.45, C_0 = 2600 \implies n_r = 12 \implies C_{12} = 153.10\ \mu\text{S/cm}$ (Limit: 156.2; Margin: $+1.98\%$).
- **Circuit C6:** $\eta = 0.45, C_0 = 2150 \implies n_r = 12 \implies C_{12} = 151.07\ \mu\text{S/cm}$ (Limit: 156.2; Margin: $+3.28\%$).
- **Circuit C7:** $\eta = 0.45, C_0 = 2600 \implies n_r = 12 \implies C_{12} = 153.10\ \mu\text{S/cm}$ (Limit: 156.2; Margin: $+1.98\%$).
- **Circuit C8:** $\eta = 0.62, C_0 = 2150 \implies n_r = 8 \implies C_8 = 156.08\ \mu\text{S/cm}$ (Limit: 156.2; Margin: $+0.08\%$).

### 7.2 Water and Effluent Accounting
Per Section 23 25 16 cl. 3.9:
- Hydrostatic test (owed circuits): Draw $1 \times V_f$; Effluent $1 \times V_f$.
- Initial flush: Draw $1 \times V_f$; Effluent $1 \times V_f$.
- Chemical cleaning: Draw $1 \times V_f$; Effluent $1 \times V_f$.
- Rinse: Draw $n_r \times V_f$; Effluent $(n_r - 1) \times V_f$. (The final displacement is retained full in the circuit for passivation, producing one less displacement of effluent).
- Passivation & Hold: Draw 0; Effluent 0.
- Turnover (RETAIN_AND_TOP_UP): Draw $V_s - V_f$; Effluent 0.

### 7.3 Daily Water Draw Compliance & Municipal Utility Avoidance
Per SW-01 and Site Instruction SI-04, construction water is metered up to daily allocations, with excess trucked at premium rates. Municipal water main maintenance enforces reduced limits on specific days:
- **Days 0, 1, 4, 5, 7–45:** Normal allocation of 62,000 gal metered ($6.20/1k gal), max 92,000 gal.
- **Days 2 & 3 (SI-04 Utility Works):** Reduced allocation of 31,000 gal metered, max 61,000 gal.
- **Day 6 (SI-04 Municipal Main Cutover):** Total utility isolation: **0 gal metered**, max 30,000 gal trucked.

*Engineering Solution for Circuit C1 Rinse:* Circuit C1 has a massive flush volume of 32,983.4 gal. Its 9-pass rinse requires 296,850.6 gallons—far exceeding any single day's allowance. The C1 rinse is engineered into five separate, controlled flushing blocks:
- Pass 1–2 (65,966.8 gal) on Day 5 (h 122–123).
- **Day 6: Complete water drawing blackout.** No water is drawn, perfectly complying with the municipal cutover.
- Pass 3–4 (65,966.8 gal) on Day 7 (h 169–170).
- Pass 5–6 (65,966.8 gal) on Day 8 (h 193–194).
- Pass 7–8 (65,966.8 gal) on Day 9 (h 217–218).
- Pass 9 (32,983.4 gal) on Day 10 (h 241–241.5), directly followed by passivation chemical dosing.

All daily draws remain strictly inside site limits, with total programme water draw equaling **782,102.6 gallons** (487,272.0 gal metered, 294,830.6 gal trucked).

---

## 8. Environmental Protection, Discharge Pretreatment & Effluent Routing

### 8.1 Pretreatment Standards & Local Limits
Discharges to the public sanitary sewer are governed by **40 CFR 403** and **SW-03 RevB**. Section 2 of SW-03 RevB establishes strict local limits at manhole MH-14:
- pH: **6.0 to 9.0 S.U.**
- Temperature: $\le \mathbf{104.0\ ^\circ\text{F}}$ ($40.0\ ^\circ\text{C}$)
- Total Copper: $\le \mathbf{1.5\ \text{mg/L}}$
- Total Zinc: $\le \mathbf{2.0\ \text{mg/L}}$
- Molybdate (as $\text{MoO}_4$): $\le \mathbf{50.0\ \text{mg/L}}$
- Cumulative Sewer Volume Cap: $\le \mathbf{480,000\ \text{gallons}}$

### 8.2 Effluent Classification & Mandatory Haulage
Spent cleaning solutions dissolve surface oxides, complexing heavy metals:
1. **Copper Circuits (C4, C5, C6, C7):** VD-06 Note 3 documents that spent CL-100/CL-210 circulating over copper headers complexes copper to concentrations of **1.6 to 3.4 mg/L**, exceeding the 1.5 mg/L local limit. Discharging this effluent to MH-14 would trigger a severe environmental permit violation. **All spent cleaning solutions from Circuits C4, C5, C6, and C7 are routed to off-site vacuum tanker HAUL.**
2. **Galvanized Circuit (C8):** VD-06 Note 3 documents that spent CL-210 circulating over hot-dip galvanized steel dissolves surface zinc to **5.5 to 9.0 mg/L**, violating the 2.0 mg/L local limit. **Spent cleaning solution from Circuit C8 is routed to off-site vacuum tanker HAUL.**
3. **Carbon Steel Circuits (C1, C2, C3):** Wetted exclusively with carbon steel and 316 stainless steel. Heavy metals are non-detect (<0.05 mg/L), pH is buffered to 8.4, and temperature is ambient (68 °F). 100% compliant with SW-03 RevB local limits. Discharged directly to sewer at MH-14.

### 8.3 Cumulative Sewer Cap Protection
If all compliant rinse streams were sewered, total sewer volume would reach 763,180 gallons—exceeding the 480,000-gallon statutory cap by 283,180 gallons.  
To preserve permit compliance, the high-volume rinse effluents of **Circuit C1 (263,867.2 gal)** and **Circuit C8 (40,535.6 gal)** are routed to off-site tanker haulage.
- **Logistics & Tanker Standing:** Per Site Logistics Plan C-101 and RFI-031 cl. 4, off-site vacuum tankers are permitted to stand **at the Yard Pad only**. Circuit C8's tie-in manifold is located directly in the yard pad, providing zero-transfer vacuum loading. Circuit C1's tie-in manifold at MER-1 connects via temporary hard line to the yard tanker staging area.
- **Cumulative Sewer Result:** Total sewer discharge volume across all stages is exactly **458,777.7 gallons**, achieving full compliance with the 480,000-gallon permit cap with an unbreached buffer of **21,222.3 gallons (+4.42% margin)**.

---

## 9. Commissioning Fleet Logistics, Electrical Power & Crew Allocation

### 9.1 Temporary Electrical Power Verification
Temporary electrical power availability is governed by SW-04 and single-line diagram E-701. Connected loads for rented flush skids (30 kW for FS-600, 75 kW for FS-1200, 480V 3-phase) were checked against panel capacities:
- **MER-1 (TP-MER-1):** 150.0 kW available. FS-1200-A connected load is 75.0 kW. **Margin: +50.00%.**
- **MER-2 (TP-MER-2):** 95.0 kW available. FS-1200-A connected load is 75.0 kW. **Margin: +21.05%.**
- **L3-N (TP-L3-N):** 90.0 kW available. FS-600-A connected load is 30.0 kW. **Margin: +66.67%.**
- **L3-S (TP-L3-S):** 90.0 kW available. FS-600-B connected load is 30.0 kW. **Margin: +66.67%.**
- **L3-W (TP-L3-W):** 90.0 kW available. FS-600-A connected load is 30.0 kW. **Margin: +66.67%.**
- **ROOF (TP-ROOF):** 45.0 kW available. FS-600-A connected load is 30.0 kW. **Margin: +33.33%.** (Note: strictly precludes FS-1200).
- **YARD (TP-YARD):** 120.0 kW available. FS-600-B connected load is 30.0 kW. **Margin: +75.00%.**

Every electrical panel possesses substantial reserve capacity, satisfying Note 1 of E-701.

### 9.2 Crew Scheduling and Skid Fleet Utilization
- **Crew Allocation:** Two 12-hour shifts per day (`CREW-1` and `CREW-2`). Crews are staggered across parallel circuits to ensure continuous oversight during initial flushes, chemical dosing, and rinse displacements, while unattended 24-hour cleaning circulations and 14-day passivation holds require zero crew hours.
- **Skid Utilization:** FS-600-A and FS-600-B mobilize on Day 0 to execute hydro tests and commence cleaning on Circuits C4, C8, C6, and C7. High-capacity skid FS-1200-A is delivered on Day 2 (hour 48 per SI-05) and assigned sequentially to MER-1 (Circuit C1, then C2) and MER-2 (Circuit C3).

---

## 10. Execution Schedule & Milestone Tracking

The programme sequence spans 56 scheduled activities, perfectly synchronizing fleet availability, water allocations, and milestone deadlines:

$$\begin{array}{|l|c|c|c|c|}
\hline
\textbf{Milestone Description} & \textbf{Contract Milestone} & \textbf{Scheduled Finish} & \textbf{Actual Finish (h / Day)} & \textbf{Schedule Margin} \\
\hline
\text{TM-1: Hydrostatic Testing Complete} & \text{Day 6 (144.0 h)} & \text{Day 0.17} & \text{4.0 h (Day 0.17)} & +140.0\text{ h (+97.2\%)} \\
\text{TM-2: Chemical Cleaning Complete} & \text{Day 22 (528.0 h)} & \text{Day 13.23} & \text{317.5 h (Day 13.23)} & +210.5\text{ h (+39.9\%)} \\
\text{TM-3: Passivation Film Formation} & \text{Day 44 (1056.0 h)} & \text{Day 28.17} & \text{676.0 h (Day 28.17)} & +380.0\text{ h (+36.0\%)} \\
\text{TM-4: Final Turnover & Strainer Removal} & \text{Day 47 (1128.0 h)} & \text{Day 45.29} & \text{1087.0 h (Day 45.29)} & +41.0\text{ h (+3.63\%)} \\
\hline
\end{array}$$

All contractual milestones are successfully achieved ahead of required dates.

---

## 11. Step-by-Step Method of Procedure (Stages 1 through 7)

### Stage 1: Hydrostatic Pressure Proving (`HYDRO`)
1. Verify tie-in isolation valves TV-x01/x02 are closed. For Circuits C3, C5, C6, and C7 (owed hydro), fit temporary blind flanges or closed test spools across equipment connections.
2. Fill circuit with clean construction water. Vent all air from high-point automatic air vents and manual vent cocks.
3. Connect dedicated high-pressure hydrostatic test pump (contractor-furnished, independent of flush skids per cl. 3.10.f).
4. Raise hydrostatic pressure smoothly to **127.5 psig** (1.5 times the 85 psig working pressure per Section 23 21 16 cl. 3.3).
5. Isolate test pump, engage calibrated circular chart recorder, and maintain test pressure for exactly **120 minutes (2.0 hours)**.
6. Verify zero pressure drop and zero visible joint leakage. Record test on Form CX-02.
7. Depressurize and drain to sewer at MH-14.

### Stage 2: Initial Construction Flush (`INITIAL_FLUSH`)
1. Connect rented flush skid to circuit tie-in valves using rated 150-psig lay-flat hoses. Ensure suction side is fitted with a temporary basket strainer carrying a 40-mesh (380 micron) stainless steel screen (VD-05).
2. Confirm equipment bypass spools are locked in bypass position (PHEs HX-201A/B, CDUs, cold plates CP-311/321/331, cooling coil CL-401).
3. Draw 1.0 circuit flush volume ($V_f$) from metered construction water supply.
4. Energize flush skid pump, adjust discharge throttle valve to target flow rate ($Q$), and verify that velocity in the governing pipe segment equals or exceeds required scour/suspension velocity ($\ge 4.0$ fps for PHE/CP circuits, $\ge 3.28$ fps for distribution circuits).
5. Circulate through temporary basket strainer. Monitor differential pressure across strainer; remove and clean basket whenever $\Delta P$ exceeds 10 psid.
6. Discontinue pumping once effluent runs clear and strainer collects no further welding slag or debris. Drain initial flush water to sewer at MH-14.

### Stage 3: Pre-Operational Chemical Cleaning (`CHEM_CLEAN`)
1. Refill circuit with 1.0 flush volume ($V_f$) of clean construction water.
2. Establish continuous circulation at design flushing flow.
3. Open chemical injection quill on flush skid manifold. Inject designated cleaner:
   - For C1–C5, C7: Inject alkaline cleaner CL-100 (1.5 gal / 1,000 gal $V_s$) and dispersant PD-45 (4.0 ppm polymer).
   - For C6, C8: Inject neutral cleaner CL-210 (2.0 gal / 1,000 gal $V_s$) and dispersant PD-45 (4.0 ppm polymer).
4. Verify circulating pH is within target band: pH 9.0–11.0 for CL-100; pH 7.5–8.5 for CL-210.
5. Maintain continuous turbulent circulation for not less than **24.0 hours**.
6. Sample circulating cleaning solution every 6 hours from drain valve DV-xC-01. Monitor conductivity, pH, and dissolved iron.
7. Upon completion of 24.0 hours, discharge spent cleaning solution to designated route:
   - Circuits C1, C2, C3: Discharge directly to sewer at MH-14.
   - Circuits C4, C5, C6, C7 (copper wetted) and Circuit C8 (galvanized): Connect discharge hose to vacuum tanker standing at Yard Pad and haul off site to permitted disposal facility.

### Stage 4: Displacement Rinse (`DRAIN_RINSE`)
1. Immediately following chemical drainage, connect flush skid to metered makeup water supply.
2. Execute sequential displacement flushing at design flushing flow for the required number of whole displacements ($n_r = 9$ for C1–C3; $n_r = 12$ for C4–C7; $n_r = 8$ for C8).
3. Route rinse effluent according to programme discharge plan:
   - Circuits C2, C3, C4, C5, C6, C7: Discharge displacements to sewer at MH-14.
   - Circuits C1 and C8: Discharge displacements to vacuum tanker at Yard Pad for off-site haulage to protect the cumulative sewer cap.
4. Test rinse water effluent at drain valve DV-xC-01 at the conclusion of each displacement. Measure conductivity (EPA 120.1) and pH (EPA 150.1).
5. Verify rinse acceptance criteria: effluent conductivity $\le 156.2\ \mu\text{S/cm}$ (within 10% of makeup water 142 uS/cm) and pH within 7.05–7.65.
6. Retain the final ($n_r$-th) displacement in the circuit to serve as the base water for passivation charging.

### Stage 5: Passivation Chemical Charging (`PASSIVATE`)
1. With circuit full of clean final rinse water, establish recirculation at design flow.
2. Inject required passivation chemical charge via flush skid injection port:
   - Circuits C1, C2, C3: Inject MO-500 to achieve 50.0 ppm as Mo.
   - Circuits C4, C5, C7: Inject MO-500 (50.0 ppm Mo) and TA-90 (10.0 ppm as TTA).
   - Circuit C6: Inject PS-330 (45.0 ppm as SiO2) and TA-90 (10.0 ppm as TTA).
   - Circuit C8: Inject PS-330 to achieve 45.0 ppm as SiO2.
3. Recirculate circuit for not less than 30 minutes to ensure complete chemical homogenization throughout all piping legs.
4. Draw validation sample from DV-xC-01. Verify that active inhibitor concentration equals or exceeds the PASSIVATION gate threshold ($\ge 40.0$ ppm Mo or $\ge 40.0$ ppm SiO2).
5. Verify pH is within the required passivation window: pH 7.5–7.9 for copper/aluminum circuits; pH 7.5–8.5 for carbon steel / galvanized circuits.

### Stage 6: Passivation Film-Formation Hold (`HOLD`)
1. Isolate flush skid from circuit by closing tie-in isolation valves TV-xC-01 and TV-xC-02.
2. Disconnect flush skid hoses and relocate skid to next scheduled circuit.
3. Lock circuit in static, fully flooded condition. Maintain static pressure above 15 psig via expansion tank / makeup regulator.
4. Hold circuit undisturbed for exactly **14.0 calendar days (336.0 hours)** to permit slow, dense crystalline conversion barrier formation (Milestone TM-3).
5. Circulating pumps and skids are idle; zero power and zero attended crew hours are consumed during the hold.

### Stage 7: Turnover, Final Top-Up & Strainer Removal (`FINAL_FILL`)
1. Upon conclusion of the 14-day hold, reconnect skid or circuit circulation pump.
2. Remove temporary bypass spools across equipment (HX-201A/B, CDUs, CP-311/321/331, CL-401) and place all permanent equipment online.
3. Draw treated makeup water volume ($V_s - V_f$) to top up the circuit to its complete SYSTEM volume ($V_s$).
4. Inject top-up chemical dose:
   - For C1–C5, C7: Inject MO-500 (and TA-90 for Cu circuits) to elevate circulating residual to maintenance level of **100.0 ppm as Mo** (and 10.0 ppm TTA).
   - For C6, C8: Inject PS-330 (and TA-90 for C6) to elevate circulating residual to maintenance level of **80.0 ppm as SiO2** (and 10.0 ppm TTA).
5. Recirculate circuit through entire system (including previously bypassed equipment) for not less than 30 minutes.
6. Sample while circulating from DV-xC-01:
   - Verify maintenance inhibitor residual: $\ge 100.0$ ppm Mo (C1–C5, C7) or $\ge 80.0$ ppm SiO2 (C6, C8).
   - Verify maintenance azole residual: $\ge 10.0$ ppm TTA (C4–C7).
   - Verify microbiological control: Total Aerobic Bacteria Count $\le 1,000$ CFU/ml (SM 9215B).
7. At Milestone TM-4 (hour 1087), break temporary strainer housings, inspect and remove 40-mesh temporary startup screens, clean permanent Y-strainer baskets, reinstall permanent screens, and lock tie-in valves in closed/tagged turnover status.
8. Deliver signed turnover log (CX-03) and acceptance matrix to owner.

---

## 12. Governing Constraints & Mathematical Margin Analysis

Section 23 25 16 and the commissioning brief require that for each circuit, the design basis explicitly identifies **the governing constraint and its margin**. The governing constraint is defined as whichever of the five project constraint families leaves the least room against its limit:
1. **Flushing duty against skid head:** Margin $= \frac{H_{avail} - H_{req}}{H_{avail}}$
2. **Rinse endpoint:** Margin $= \frac{C_{target} - C_n}{C_{target}}$
3. **Authorised programme discharge volume:** Margin $= \frac{480,000 - V_{sewer,tot}}{480,000} = \frac{480,000 - 458,777.7}{480,000} = \mathbf{0.0442}$ (4.42%)
4. **Site's daily water allocation:** Peak day draw margin $= \frac{\text{Limit} - \text{Draw}}{\text{Limit}} \ge \mathbf{0.2230}$ (22.30%)
5. **Temporary power available at tie-in:** Margin $= \frac{\text{kW}_{avail} - \text{kW}_{conn}}{\text{kW}_{avail}} \ge \mathbf{0.2105}$ (21.05%)

### 12.1 Constraint Comparison by Circuit
$$\begin{array}{|c|c|c|c|c|c|c|}
\hline
\textbf{Circuit} & \textbf{Head Margin} & \textbf{Rinse Margin} & \textbf{Sewer Margin} & \textbf{Power Margin} & \textbf{Tightest Family} & \textbf{Governing Margin} \\
\hline
\text{C1} & 0.2291 & 0.0315 & 0.0442 & 0.5000 & \text{rinse endpoint} & 0.0315 \\
\text{C2} & 0.7335 & 0.0315 & 0.0442 & 0.5000 & \text{rinse endpoint} & 0.0315 \\
\text{C3} & 0.6755 & 0.0315 & 0.0442 & 0.2105 & \text{rinse endpoint} & 0.0315 \\
\text{C4} & 0.3467 & 0.0198 & 0.0442 & 0.6667 & \text{rinse endpoint} & 0.0198 \\
\text{C5} & 0.0206 & 0.0198 & 0.0442 & 0.6667 & \text{rinse endpoint} & 0.0198 \\
\text{C6} & 0.3262 & 0.0328 & 0.0442 & 0.6667 & \text{rinse endpoint} & 0.0328 \\
\text{C7} & 0.3361 & 0.0198 & 0.0442 & 0.3333 & \text{rinse endpoint} & 0.0198 \\
\text{C8} & 0.6042 & 0.0008 & 0.0442 & 0.7500 & \text{rinse endpoint} & 0.0008 \\
\hline
\end{array}$$

*Engineering Note on Circuit C5:* Circuit C5 presents an exceptionally tight competition between hydraulic head and rinse dilution. At 480 gpm, required head is 131.24 ft against skid FS-600-B available head of 134.00 ft, leaving a head margin of **0.0206 (2.06%)**. Meanwhile, after 12 displacements, rinse conductivity reaches 153.10 uS/cm against the 156.20 uS/cm threshold, leaving a conductivity margin of **0.0198 (1.98%)**. Because 0.0198 is strictly tighter than 0.0206, the rinse endpoint governs.

### 12.2 Formal Declaration of Governing Constraints
In accordance with the contract schema, the governing constraint and margin for each circuit are formally declared as follows:

GOVERNING CONSTRAINT C1: rinse endpoint (margin 0.0315)  
GOVERNING CONSTRAINT C2: rinse endpoint (margin 0.0315)  
GOVERNING CONSTRAINT C3: rinse endpoint (margin 0.0315)  
GOVERNING CONSTRAINT C4: rinse endpoint (margin 0.0198)  
GOVERNING CONSTRAINT C5: rinse endpoint (margin 0.0198)  
GOVERNING CONSTRAINT C6: rinse endpoint (margin 0.0328)  
GOVERNING CONSTRAINT C7: rinse endpoint (margin 0.0198)  
GOVERNING CONSTRAINT C8: rinse endpoint (margin 0.0008)  

---

## 13. Hazard Communication & Chemical Handling Safety Plan

This section discharges all chemical safety obligations mandated by **29 CFR 1910.1200** (OSHA Hazard Communication Standard) and the project **VD-07 Safety Data Sheet Package**.

### 13.1 GHS Chemical Classification and Hazards
- **CL-100 (Alkaline Cleaner):** Contains sodium hydroxide and sodium metasilicate. GHS Signal Word: **DANGER**. GHS Pictograms: Corrosion (Skin Corr. 1A, Eye Dam. 1). Hazard Statements: H314 (Causes severe skin burns and eye damage).
- **CL-210 (Neutral Cleaner):** Contains ethoxylated alcohols and organic buffering salts. GHS Signal Word: **WARNING**. GHS Pictograms: Exclamation Mark (Eye Irrit. 2A, Skin Irrit. 2). Hazard Statements: H315 (Causes skin irritation), H319 (Causes serious eye irritation).
- **PD-45 (Polyacrylate Dispersant):** Sodium polyacrylate aqueous solution. GHS Signal Word: **WARNING**. Hazard Statements: H316 (Mild skin irritation).
- **MO-500 (Molybdate Inhibitor):** 35% Sodium molybdate dihydrate. GHS Signal Word: **WARNING**. GHS Pictograms: Health Hazard. Hazard Statements: H373 (May cause damage to kidneys through prolonged or repeated exposure).
- **PS-330 (Polysilicate Inhibitor):** Liquid sodium polysilicate solution. GHS Signal Word: **DANGER**. GHS Pictograms: Corrosion. Hazard Statements: H314 (Causes severe skin burns and eye damage).
- **TA-90 (Tolyltriazole Azole Solution):** 50% Sodium tolyltriazole solution. GHS Signal Word: **DANGER**. GHS Pictograms: Corrosion, Acute Toxicity. Hazard Statements: H302 (Harmful if swallowed), H314 (Causes severe skin burns and eye damage).

### 13.2 Engineering Controls & Personal Protective Equipment (PPE)
1. **Mandatory Personal Protective Equipment:**
   - Level C Chemical Splash Attire: Chemical splash goggles conforming to ANSI Z87.1, full-face polycarbonate shield (8-inch minimum), heavy-duty nitrile or neoprene gauntlet gloves (14-inch, chemical-resistant per ASTM F739), chemical-resistant rubber apron, and ASTM F2413 steel-toed rubber boots.
   - Organic vapor / mist respirator (NIOSH approved) required during drum opening and chemical dosing in confined mechanical rooms.
2. **Emergency Eyewash and Drench Showers:**
   - In strict compliance with 29 CFR 1910.1200 and ANSI Z358.1, an operational emergency eyewash and drench shower unit shall be positioned **within 10 seconds of travel time (and not more than 55 feet distance)** from every chemical injection tie-in point.
   - Travel paths shall remain completely unobstructed by hoses, pallets, or electrical cords. Units shall be flow-tested daily prior to chemical handling, verifying potable water delivery of not less than 20 gpm for drench shower and 0.4 gpm for eyewash for a full 15-minute flush.
3. **Spill Containment and Neutralization:**
   - All chemical pails and carboys shall be staged on certified polyethylene spill containment pallets providing secondary containment capacity of not less than 110% of the largest stored container.
   - Acidic neutralizer (citric acid / sodium bisulfate solution) and absorbent spill kits shall be stationed at MER-1, MER-2, and the Yard chemical staging area to manage any inadvertent alkaline release.
   - In the event of a chemical splash, flush affected eyes or skin with clean water for not less than 15 minutes while immediately calling emergency medical services.
4. **Hazard Communication Compliance:**
   - Safety Data Sheets (SDSs) for all six products shall be prominently displayed in high-visibility binders at the contractor site trailer and at each active tie-in location.
   - All chemical transfer containers shall carry full GHS-compliant secondary labels identifying product name, GHS signal word, and primary hazard pictograms.
   - All commissioning crew personnel shall undergo documented site chemical safety training prior to opening any chemical package.

---

## 14. Quality Assurance, Gate Acceptance Matrix & Record Keeping

Quality assurance is verified across four sequential gates:

1. **RINSE Gate:** Evaluated at the final displacement of Stage 4. Passing criterion: Effluent conductivity $\le 156.2\ \mu\text{S/cm}$ (EPA 120.1) and pH between 7.05 and 7.65 S.U. (EPA 150.1).
2. **PASSIVATION Gate:** Evaluated 30 minutes after chemical charging in Stage 5. Passing criterion: Active inhibitor residual $\ge 40.0$ ppm as Mo (Circuits C1–C5, C7 via SM 3120B) or $\ge 40.0$ ppm as SiO2 (Circuits C6, C8 via SM 4500-SiO2 C).
3. **DISCHARGE Gate:** Evaluated at manhole MH-14 for all sewered effluent streams. Passing criterion: pH strictly between 6.0 and 9.0 S.U., temperature $\le 104.0\ ^\circ\text{F}$, and zero unapproved heavy metals.
4. **TURNOVER Gate:** Evaluated during Stage 7 circulating recirculation. Passing criterion: Maintenance inhibitor residual $\ge 100.0$ ppm Mo or $\ge 80.0$ ppm SiO2; maintenance azole residual $\ge 10.0$ ppm TTA (on copper circuits); and Total Aerobic Bacteria Count $\le 1,000$ CFU/ml (SM 9215B).

All test results, flow logs, differential pressures, chemical batch numbers, and discharge volumes shall be compiled on Form CX-03 and formally submitted as the final turnover package for the Tull Creek Data Hall PCW loop.

---
*End of Method of Procedure & Turnover Package Narrative.*
