# AMENDMENT OF SOLICITATION / MODIFICATION OF CONTRACT
## CONTINUATION SHEET

**SOLICITATION NO.:** N40085-26-R-2041  
**AMENDMENT NO.:** 0003  
**DATE:** 14 September 2026  
**ISSUED BY:** NAVAL FACILITIES ENGINEERING SYSTEMS COMMAND PACIFIC  
258 Makalapa Drive, Suite 100, JBPHH, HI 96860  
**PROJECT:** Fleet Data Center Increment 2, Work Order 74213  
**LOCATION:** Naval Support Activity Ventura Bay, California  
**BID PACKAGE:** BP-2: Central Utility Plant and Site Utilities  

---

### EXPLANATION OF CHANGES

This Amendment 0003 incorporates Engineer-of-Record design review corrections across Civil, Mechanical, Electrical, and Structural disciplines for Bid Package BP-2 (Central Utility Plant and Site Utilities). Specific modifications include:

1. **Civil Discipline:**
   - On Sheet C-101 (NAVFAC DWG NO. 74213-C101), realigned the fire water main at the duct bank crossing to maintain required physical separation per utility installation criteria.

2. **Electrical Discipline:**
   - On Sheet E-001 (NAVFAC DWG NO. 74213-E001), reordered electrical panel schedule columns to achieve standardized layout.
   - On Sheet E-101 (NAVFAC DWG NO. 74213-E101), repositioned feeder tag leaders to the load side of disconnect switches.
   - On Sheet E-501 (NAVFAC DWG NO. 74213-E501), revised electrical equipment details in coordination with structural equipment anchorage updates.

3. **Mechanical Discipline:**
   - On Sheet M-101 (NAVFAC DWG NO. 74213-M101), resized the CUP chilled water supply main per mechanical design analysis calculations.
   - On Sheet M-301 (NAVFAC DWG NO. 74213-M301), lowered chilled water header elevation to resolve structural clash and revised chiller equipment outline to phantom line representation.
   - On Sheet M-401 (NAVFAC DWG NO. 74213-M401), added detail callouts referencing new chiller pad anchorage details on added Sheet M-503.
   - On Sheet M-501 (NAVFAC DWG NO. 74213-M501), coordinated mechanical pipe support hanger rod spacing.
   - On Sheet M-502 (NAVFAC DWG NO. 74213-M502), updated chiller details to reference revised post-installed anchor details.
   - Added Sheet M-503 (NAVFAC DWG NO. 74213-M503) providing dedicated chiller pad anchorage details.

4. **Structural Discipline:**
   - On Sheet S-101 (NAVFAC DWG NO. 74213-S101), revised anchor rod embedment callouts and foundation plan notes to meet seismic design requirements; added detail callouts to new Sheet S-202.
   - On Sheet S-201 (NAVFAC DWG NO. 74213-S201), re-issued exterior framing elevations in coordination with revised sections.
   - Added Sheet S-202 (NAVFAC DWG NO. 74213-S202) providing braced bay framing elevations and brace work point layouts.
   - On Sheet S-301 (NAVFAC DWG NO. 74213-S301), updated building sections to coordinate chilled water header elevations and anchorage details.
   - On Sheet S-501 (NAVFAC DWG NO. 74213-S501), corrected dimensional closure strings on slab edge details.
   - On Sheet S-502 (NAVFAC DWG NO. 74213-S502), deleted cast-in anchor details from equipment anchorage views and replaced with post-installed anchors compatible with post-tensioned slabs.

---

### DOCUMENT 00 01 15 LIST OF DRAWINGS

#### 1.2 Contract Drawings

ADD the following drawings. These drawings accompany this Amendment.

| DRAWING NO. | REVISION NO. | NAVFAC DWG NO. | TITLE |
| :--- | :--- | :--- | :--- |
| S-202 | 1 | 74213-S202 | BRACED BAY FRAMING ELEVATIONS |
| M-503 | 1 | 74213-M503 | CHILLER PAD ANCHORAGE DETAILS |

DELETE and REPLACE the following drawings as of 14 September 2026. These drawings accompany this Amendment.

| DRAWING NO. | REVISION NO. | NAVFAC DWG NO. | TITLE |
| :--- | :--- | :--- | :--- |
| C-101 | 3 | 74213-C101 | SITE UTILITY PLAN |
| E-001 | 3 | 74213-E001 | ELECTRICAL PANEL SCHEDULES |
| E-101 | 3 | 74213-E101 | CUP POWER PLAN |
| E-501 | 3 | 74213-E501 | ELECTRICAL DETAILS |
| M-101 | 3 | 74213-M101 | CUP CHILLED WATER PLAN |
| M-301 | 3 | 74213-M301 | PLANT SECTIONS |
| M-401 | 3 | 74213-M401 | CHILLER BAY ENLARGED PLAN |
| M-501 | 3 | 74213-M501 | MECHANICAL DETAILS |
| M-502 | 3 | 74213-M502 | CHILLER DETAILS |
| S-101 | 3 | 74213-S101 | CUP FOUNDATION PLAN |
| S-201 | 3 | 74213-S201 | EXTERIOR ELEVATIONS |
| S-301 | 3 | 74213-S301 | BUILDING SECTIONS |
| S-501 | 3 | 74213-S501 | STRUCTURAL DETAILS |
| S-502 | 3 | 74213-S502 | FRAMING DETAILS |

---

### STATEMENT CONCERNING BID PACKAGE BP-3

**BID PACKAGE BP-3: DATA HALL 210 SHELL AND INTERIORS**  
**SOLICITATION NO.:** N40085-26-R-3018  

In accordance with Contracting Officer Memorandum dated 26 August 2026, paragraph 2 and paragraph 3, the corrections resulting from the Engineer-of-Record design review for Bid Package BP-3 are incorporated directly into the certified design documents prior to solicitation advertisement (Pre-Advertisement Reissue). Production of the revised drawing package completes on 13 September 2026, which is 57 calendar days prior to the scheduled advertisement date of 9 November 2026 and 27 calendar days prior to the opening of the mandatory 30-calendar-day pre-advertisement backcheck window. Because the corrections are incorporated prior to advertisement, no solicitation amendment is required, no amendment change number is assigned, and no continuation sheet is submitted for Bid Package BP-3.
