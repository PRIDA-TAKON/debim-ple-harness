# DESIGN BASIS: EOR REVIEW CORRECTIONS
## Fleet Data Center Increment 2, Work Order 74213
### Naval Support Activity Ventura Bay, California

```json
{
  "packages": {
    "BP-2": {
      "issue_state": "AMENDMENT",
      "change_number": "0003",
      "overflow_option": 1,
      "revision_layers": [
        "G-ANNO-REVC",
        "G-ANNO-REVS"
      ],
      "n_bundles": 3,
      "production_days": 14,
      "delay_days": 0,
      "backcheck_window_days": 15,
      "ledger": {
        "bundles_usd": 14400,
        "sheets_usd": 22902.53,
        "added_sheets_usd": 12800,
        "revision_marks_usd": 3360,
        "overflow_option_usd": 3120,
        "non_concurrence_usd": 2400,
        "delay_usd": 0,
        "total_usd": 58982.53
      },
      "title_block_defects": [
        {
          "sheet": "E-501",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        },
        {
          "sheet": "S-301",
          "defect": "CHK_EQUALS_DRW"
        }
      ]
    },
    "BP-3": {
      "issue_state": "PRE_ADVERTISEMENT_REISSUE",
      "change_number": "",
      "overflow_option": "NONE",
      "revision_layers": [
        "G-ANNO-REVC",
        "G-ANNO-REVS"
      ],
      "n_bundles": 3,
      "production_days": 14,
      "delay_days": 0,
      "backcheck_window_days": 30,
      "ledger": {
        "bundles_usd": 14400,
        "sheets_usd": 27939.78,
        "added_sheets_usd": 12800,
        "revision_marks_usd": 0,
        "overflow_option_usd": 0,
        "non_concurrence_usd": 0,
        "delay_usd": 0,
        "total_usd": 55139.78
      },
      "title_block_defects": [
        {
          "sheet": "A-501",
          "defect": "CHK_EQUALS_DES"
        },
        {
          "sheet": "M-101",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        },
        {
          "sheet": "T-101",
          "defect": "CHK_EQUALS_DRW"
        }
      ]
    }
  },
  "governing_standards": [
    "FC 1-300-09N (17 May 2024, Change 1 17 April 2025)",
    "ERDC/ITL SR-24-3 (Release 6.2, May 2024)",
    "ERDC/ITL SR-23-1 (Release 2.2, September 2023)",
    "ER 1165-2-217 (1 May 2021)",
    "ERDC/ITL SR-21-6 (September 2021)"
  ],
  "rejected_standards": [
    "UFC 1-300-09N (2005 Change 7) - Cancelled and superseded by FC 1-300-09N",
    "ERDC/ITL TR-12-6 (Release 6.0) - Superseded by CAD Standard Release 6.2 (ERDC/ITL SR-24-3)",
    "GSA PBS CAD Standard (2021) - Non-governing civilian agency standard inapplicable to Navy military construction",
    "ER 1110-1-8159 - Excluded by Contracting Officer Memorandum paragraph 7",
    "ER 415-1-11 - Excluded by Contracting Officer Memorandum paragraph 7"
  ],
  "rate_parameters": {
    "production_start": "2026-08-31",
    "sheets_per_day": 4,
    "days_per_bundle": 3
  },
  "void_markups": [
    {
      "comment_id": "EOR-2-017",
      "reason": "Author G. Halvorsen is not on the approved project reviewer roster."
    },
    {
      "comment_id": "EOR-2-021",
      "reason": "Markup was placed on a superseded drawing sheet from 90 percent review."
    },
    {
      "comment_id": "EOR-2-033",
      "reason": "Comment was formally closed in earlier review phase and not reopened."
    },
    {
      "comment_id": "EOR-3-012",
      "reason": "Markup was placed on a superseded drawing sheet from 60 percent review."
    },
    {
      "comment_id": "EOR-3-022",
      "reason": "Author C. Ballantyne is not on the approved project reviewer roster."
    },
    {
      "comment_id": "EOR-3-036",
      "reason": "Comment was formally closed in earlier review phase and not reopened."
    }
  ]
}
```

## NARRATIVE JUSTIFICATIONS AND TECHNICAL BASIS

### (a) Resolution of Revision-Graphics Layer Conflict
A graphical conflict exists between two shipped standards regarding the CAD layers designated for drawing revision graphics. In FC 1-300-09N paragraph 12-3.6.1, the text references revision cloud layer `Z-ANNO-REVC` and revision symbol layer `Z-ANNO-REVS`. Conversely, in ERDC/ITL SR-24-3 Appendix A (page 50) and ERDC/ITL SR-21-6 (page 19), revision graphics are assigned to layers `G-ANNO-REVC` and `G-ANNO-REVS`.

This discrepancy is resolved by establishing the precise governing scope and order of precedence mandated by FC 1-300-09N paragraph 12-3.3.4. Paragraph 12-3.3.4 establishes that Chapter 12 of FC 1-300-09N governs Navy requirements, followed by the Tri-Service A/E/C CAD and Graphics Standards. Detailed examination of FC 1-300-09N demonstrates that paragraph 12-3.6 is explicitly titled and scoped for "Record Documents" (post-construction as-built modifications prepared after physical construction completion). Under Tri-Service CAD conventions, the leading discipline character "Z" designates contractor as-built modifications.

For active pre-award design submittals, solicitation amendments, and certified design issues prior to construction award, the governing standard is ERDC/ITL SR-24-3 Appendix A and ERDC/ITL SR-21-6. Under these standards, revision deltas, indicator symbols, and revision clouds reside on general annotation layers `G-ANNO-REVC` (revision clouds) and `G-ANNO-REVS` (revision deltas and symbols). Therefore, `["G-ANNO-REVC", "G-ANNO-REVS"]` are applied across all re-issued drawing sheets for both bid packages.

### (b) Decision of BP-3 Issue State and Applicable Review Window
Bid Package BP-3 (Data Hall 210 Shell and Interiors, solicitation N40085-26-R-3018) was certified and pending advertisement. The project schedule export originally reflected an advertisement date of 12 October 2026. However, the later formal memorandum from the Contracting Officer dated 26 August 2026, paragraph 3, controls governing procurement milestones, establishing the scheduled advertisement date as 9 November 2026 and bid opening as 12 November 2026.

In evaluating whether BP-3 corrections should be issued prior to advertisement (`PRE_ADVERTISEMENT_REISSUE`) or post-advertisement as a solicitation change (`AMENDMENT`), the duration of the backcheck window required by the review regulation ER 415-1-11 governs:
1. **Pre-Advertisement Window (30 Calendar Days):** ER 415-1-11 paragraph 6.e dictates that a pre-advertisement backcheck review must be initiated 30 calendar days prior to advertising to ensure complete comment resolution. With scheduled advertisement on 9 November 2026, this 30-day window commences on 10 October 2026. Production of the BP-3 corrections commences on 31 August 2026 and completes in 14 calendar days on 13 September 2026 (5 sheets/day production + 9 days bundle processing). Because production completes 27 calendar days prior to the opening of the 30-day backcheck window (and 57 calendar days prior to advertisement), all review comments and backchecks are closed with zero schedule delay ($D = 0$, delay charge = $0).
2. **Post-Advertisement Window (15 Calendar Days):** ER 415-1-11 paragraph 6.e provides a 15-calendar-day window for backchecking comments during solicitation/post-design reviews. However, the scheduled solicitation period between advertisement (9 November 2026) and bid opening (12 November 2026) spans only 3 calendar days. Conducting an amendment backcheck during advertisement would breach the solicitation window, forcing an extension of the bid opening deadline by at least 12 calendar days. Under Contracting Officer memorandum paragraph 4, this delay would impose escalating extension charges of $2,600 × 12 + $140 × 12² = $51,360, in addition to $4,320 in revision marks and amendment processing charges.

Therefore, `PRE_ADVERTISEMENT_REISSUE` with the 30-calendar-day window is adopted, minimizing cost to the Government and maintaining procurement schedule integrity.

### (c) BP-2 Revision Block Overflow Technical and Cost Evaluation
Standard DoD border sheets provide an 8-row capacity in the Revision (Issue) block, as specified in ERDC/ITL SR-23-1 Section 7.3. Prior to work order 74213, six revised sheets in BP-2 (`C-101`, `M-101`, `M-501`, `S-101`, `S-501`, `S-502`) had already accumulated 8 historical entries (Modifications A through F plus Amendments 0001 and 0002), completely filling the block capacity.

To incorporate Amendment 0003, ERDC/ITL SR-23-1 Section 7.3 outlines two alternative approaches:
- **Option 1 (Replace Oldest):** Displaces the oldest historical revision from the block, shifting entries to record the new amendment at the active row position, and copies displaced entries outside the plotted sheet border for record archiving.
- **Option 2 (Spill into Drawing Area):** Continues stacking revision rows upward past the title block border directly into the active drawing area.

ERDC/ITL SR-23-1 Section 7.3 requires that the chosen overflow method remain consistent across the entire drawing set rather than varied sheet by sheet. Option 1 was selected set-wide based on technical risk and direct Government cost:
1. **Technical Risk:** ERDC/ITL SR-23-1 Section 7.3 warns that Option 2 creates severe graphical clutter and runs the risk of running into items placed in the drawing area. The overflowing sheets contain complex engineering linework, including equipment anchorage details and piping schematics, which would be compromised by spilled text. Option 1 is explicitly designated as the preferred DoD standard.
2. **Cost Basis:** Under the published rate schedule, Option 2 carries a fee of $880 per revised sheet that has 3 or more drawing blocks, requiring extensive drafting re-layout. Option 1 costs $520 per sheet solely to record displaced entries outside the plot border. Across the 6 full sheets, Option 1 costs $3,120 compared to $5,280 for Option 2, saving the Government $2,160 while preserving drawing clarity.
