# 13.8 kV SITE DISTRIBUTION CONVEYANCE STUDY REPORT
## Pacific Crest Space Force Annex — Mission Support Facility MB-1 & Central Utility Plant CUP-1
### Solicitation: FA4610-26-R-0031 | Project: PCSFA 24-0117 | 35% Design Conveyance Study
**Date:** 2026-09-15 | **Prepared By:** Design-Build Contractor Joint Electrical & Cost Engineering Team

---
## 1. EXECUTIVE SUMMARY
This comprehensive conveyance study evaluates the routing, conveyance typology, physical engineering design, and deterministic life-cycle contract pricing for the seven medium-voltage (13.8 kV) distribution circuits serving Pacific Crest Space Force Annex (PCSFA), Los Angeles County, California.

The study has been conducted pursuant to RFP Section 01 11 00 (Amendment 0002), the Installation Electrical Design Standard (PCSFA-IEDS Rev 3), UFC 3-550-01 (*Exterior Electrical Power Distribution*), UFC 3-740-05 (*Construction Cost Estimating*), and governing Department of Defense criteria. Every specified conveyance type across all seven circuits (Items C01 through C07) has been rigorously evaluated for statutory/regulatory permissibility, fully priced using bottom-up labor, equipment, material, and subcontract quotes, and rolled up through DoD Markups to total project cost.

Among conveyance designs that governing criteria permit, the design with the lowest total project cost has been selected and engineered to the 10% design level, complete with exact spatial coordinate polylines, segment cross-sections, excavation protective systems, manhole/pole infrastructure, cable ampacity/short-circuit ratings, and 3D cable pulling tension calculations.

### Table 1.1: Recommended Conveyance Designs Summary
| Item | Feeder Circuit | Recommended Type | Cable Size & Sets | Route Length (LF) | Direct Cost ($) | Contract Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) |
|:---|:---|:---:|:---:|---:|---:|---:|---:|---:|
| **C01** | SS-1 Feeder F1 to MB-1 MSG-A (Primary) | **CEDB** | 2x 500 kcmil | 927.2 | $233,595.26 | $297,849.36 | $330,568.11 | **$356.52** |
| **C02** | SS-1 Feeder F2 to MB-1 MSG-B (Secondary) | **CEDB** | 2x 500 kcmil | 1,182.3 | $280,050.61 | $357,082.99 | $396,308.56 | **$335.20** |
| **C03** | SS-1 Feeder F3 to CUP-1 SWG-C1 | **CEDB** | 1x 500 kcmil | 490.0 | $84,352.31 | $107,554.76 | $119,369.65 | **$243.61** |
| **C04** | CUP-1 Feeder CF-2 to Lift Station LS-2 | **CEDB** | 1x 250 kcmil | 1,327.0 | $260,519.67 | $332,179.75 | $368,669.70 | **$277.82** |
| **C05** | MB-1 MSG-A to Unit Substation USS-A1 | **RMC** | 1x 500 kcmil | 400.0 | $82,464.82 | $105,148.08 | $116,698.60 | **$291.75** |
| **C06** | SS-1 Feeder F4 to Gate House GH-1 | **OH** | 1x 250 kcmil / 1/0 Raven | 1,978.0 | $89,590.88 | $114,234.28 | $126,782.91 | **$64.10** |
| **C07** | CUP-1 Feeder CF-1 to Warehouse W-3 | **CEDB** | 1x 250 kcmil | 680.0 | $157,968.31 | $201,420.01 | $223,546.00 | **$328.74** |
| **TOTAL** | **Entire 13.8 kV Conveyance Package** | — | — | **6,984.5** | **$1,188,541.86** | **$1,515,469.23** | **$1,681,943.52** | **$240.81** |

**Key Engineering Findings and Design Highlights:**
- **MB-1 Feeder Redundancy & Independence (C01 & C02):** Concrete-encased ductbank (CEDB) is the only permitted conveyance inside the congested industrial corridor and across Mission Drive. Feeder F1 (C01, Bus A) and Feeder F2 (C02, Bus B) are physically routed in independent trench alignments maintaining >20 ft physical separation per PCSFA-IEDS 4.4, eliminating common-cause trench failures. Both feeders utilize 80-ft horizontal directional drills (HDD) at 48 in cover under Mission Drive to eliminate traffic disruption.
- **CUP-1 Main Incomer (C03):** Concrete-encased ductbank routed south from SS-1 stub-out across Parking Lot P-1. A 150-ft segment under P-1 is reinforced with 4 No. 4 longitudinal bars and No. 3 ties at 3-ft centers to resist heavy dynamic vehicular loading per IEDS 4.8.
- **Lift Station Feeder (C04):** Features two trenchless crossings: an 80-ft HDD under Mission Drive and a deep 120-ft HDD passing at 120-in cover below the invert of concrete drainage channel DC-1 per UFC 3-550-01 App B. Dewatering is specified along the western 140 LF of the segment near boring B-10, where groundwater is present at 3.0 ft depth.
- **MB-1 Interior Distribution (C05):** Rigid Metal Conduit (RMC) is the sole admissible conveyance. Electrical Metallic Tubing (EMT) is prohibited for voltages >600 V by NEC 300.37 and IEDS 5.1. Cable tray options (TRAY-EN and TRAY-LD) violate the mandatory 18-in maintenance headroom required above suspended ceilings in Corridor COR-1 and breach the 10-ft keep-out zone surrounding SCIF IT-1.
- **Gate House Overhead Line (C06):** Overhead (OH) construction is permitted along the southern utility corridor (y=220) outside the industrial core polygon (IEDS 4.1). At **$126,782.91** ($64.10/LF), overhead construction delivers a **$301,823.37 (70.4%) cost savings** compared to an underground CEDB alternative ($428,606.28), making it the most cost-effective compliant conveyance. Includes 50-ft Class 3 poles across Mission Drive to maintain 24-ft road clearance.
- **Warehouse Feeder (C07):** Concrete-encased ductbank utilizing a 40-ft Jack-and-Bore (JB) crossing housing two 5-in RGS conduits under active railroad spur RR-SPUR-2 at 42-in cover, satisfying AREMA / UFC 3-550-01 requirements without interrupting rail traffic.

---
## 2. GOVERNING CRITERIA & HIERARCHY OF TRUTH
All engineering decisions and cost computations are governed strictly by the contract documents under the formal Order of Precedence established by PCSFA-IEDS Rev 3 Clause 1.3:
1. **Tier 1 (Highest Authority):** Project-specific RFP Amendments (RFP Section 01 11 00 Amd 0002), Approved Submittals (SUB-33 71 02-07), Protective Device Settings Schedule Rev D, SUE Utility Survey SUE-24-0117, and Arborist Survey TS-24-0117.
2. **Tier 2:** PCSFA Installation Electrical Design Standard (PCSFA-IEDS Rev 3, 2026-05-15).
3. **Tier 3:** DoD Unified Facilities Criteria: UFC 3-550-01 (*Exterior Electrical Power Distribution*, with Change 3, 2024), UFC 3-740-05 (*Construction Cost Estimating*, 2022 C1), and Unified Facilities Guide Specifications (UFGS 33 71 02, UFGS 26 05 00).
4. **Tier 4:** Federal Safety Regulations: OSHA 29 CFR 1926 Subpart P (*Excavations*); 29 CFR 1.6 (*Davis-Bacon Wage Determinations*).
5. **Tier 5:** Civil and Architectural Site Drawings (C-101, E-101, A-501) and Geotechnical Report GEO-24-0117 (with primary boring logs governing over summary tables).
6. **Tier 6 (Lowest Authority):** Preliminary/Reference estimates and manufacturer catalogue sheets.

### Permissibility Rules by Conveyance Typology:
- **Concrete-Encased Ductbank (CEDB):** Governed by UFC 3-550-01 Clause 3-11.2.1 and PCSFA-IEDS 4.2. CEDB is the required standard for all primary underground distribution circuits at PCSFA. Minimum burial depth is 30 in (24 in under paved surfaces). Spacers at 5-ft centers maintain 3-in inter-duct separation and 3-in concrete encasement on all sides. Minimum 1/3 spare duct capacity is mandated (50% provided via 2x2 and 1x2 banks).
- **Unencased Conduit Ductbank (UEDB):** Governed by PCSFA-IEDS 4.2 and UFC 3-550-01 3-11.2.1. Strictly prohibited for primary medium-voltage distribution across the Annex. Permitted only for low-voltage secondary circuits (<600 V) or telecommunications.
- **Direct-Buried Cable (DBC):** Governed by PCSFA-IEDS 4.2 and UFC 3-550-01 3-11.2.1 / 3-11.3.1. Prohibited for permanent 13.8 kV distribution due to high failure rates, lack of mechanical protection against excavation strikes, and inability to replace cables without trenching.
- **Horizontal Directional Drilling (HDD) as Sole Run Method:** Governed by PCSFA-IEDS 4.3 and UFC 3-550-01 3-11.4.1. HDD is permitted exclusively for discrete localized obstacle crossings (roads, drainage channels, rail tracks) where open-cut trenching is unacceptable. Continuous HDD for entire feeder runs is excluded due to thermal de-rating from deep placement (>10 ft), risk of bore deviation, inability to install intermediate manholes, and prohibitive cost.
- **Overhead Pole Lines (OH):** Governed by PCSFA-IEDS 4.1. Overhead lines are strictly prohibited within the industrial core and crane operating areas (bounded by the polygon north of y=350, east of x=250, west of x=1600). Overhead construction is permitted only along the southern utility corridor (y=220) serving remote facilities such as Gate House GH-1.
- **Interior Building Raceways (C05):** Governed by PCSFA-IEDS 5.1, NEC 300.37, and UFC 3-520-01. Rigid Metal Conduit (RMC) is permitted. Electrical Metallic Tubing (EMT) is prohibited for systems operating above 600 V. Cable tray (TRAY-EN and TRAY-LD) is prohibited due to geometric interference with HVAC ductwork in Corridor COR-1 (<18 in clearance to ceiling joists) and strict security keep-out requirements around SCIF IT-1.

---
## 3. ELECTRICAL ENGINEERING DESIGN & SYSTEM CALCULATIONS
### 3.1 Load Sizing, Ampacity & Thermal Modeling
Conductor sizing is established through rigorous thermal modeling adhering to Neher-McGrath methodology, IEEE 835, and NEC Article 310.60. 
- **Underground Ductbanks:** Soil thermal resistivity ($rho$) = 90 °C-cm/W (geotechnical baseline); ambient earth temperature = 20 °C; maximum continuous conductor operating temperature = 90 °C.
- **Feeder Load Factors (IEDS 2.3):** C01 and C02 serve critical command facilities (MB-1) and are evaluated at 100% continuous load factor (giving 335 A ampacity per set for 500 kcmil AL in 2x2 ductbank). C03, C04, C06, and C07 are evaluated at 75% load factor (giving 410 A for 500 kcmil AL and 300 A for 250 kcmil AL in 1x2 ductbank).
- **Riser Poles & Conduits in Air:** NEC Table 310.60(C)(71) / Table B.310.15(B)(2)(11) derated for 40 °C ambient summer temperature: 500 kcmil AL provides 245 A in enclosed interior conduit (C05); 250 kcmil AL provides 196 A in vertical pole risers (C06).
- **Overhead Conductor:** 1/0 AWG ACSR 'Raven' evaluated per IEEE 738 (40 °C ambient, 2 ft/s crosswind, 90 °C conductor temp) yields an ampacity of 242 A, easily exceeding the 40 A design load of Gate House GH-1.

### 3.2 Short-Circuit Thermal Withstand Analysis
Per PCSFA-IEDS Clause 2.4, medium-voltage cable conductors must withstand available short-circuit currents for the backup fault clearing time without exceeding maximum insulation damage temperatures (250 °C for XLPE/EPR insulation).

Per Protective Device Settings Schedule Rev D, the available three-phase symmetrical fault current at the 13.8 kV site substation SS-1 bus is **25.1 kA**, and the upstream feeder backup overcurrent clearing time is **0.16 seconds** (9.6 cycles).

The minimum conductor cross-sectional area is determined by the ICEA P-32-382 / Onderdonk short-circuit formula for aluminum conductors with thermoset insulation:
$$I_{sc} = A \cdot \sqrt{\frac{0.0125}{t} \log_{10}\left(\frac{T_2 + 228}{T_1 + 228}\right)}$$

Where:
- $I_{sc} = 25,100{ A}$ (fault current)
- $t = 0.16{ s}$ (clearing time)
- $T_1 = 90^\circ\text{C}$ (maximum continuous operating temperature)
- $T_2 = 250^\circ\text{C}$ (maximum transient short-circuit temperature)
- $(T_2 + 228) / (T_1 + 228) = 478 / 318 = 1.50314$
- $\log_{10}(1.50314) = 0.17700$
- Factor: $sqrt{(0.0125 * 0.17700) / 0.16} = sqrt{0.013828} = 0.11759{ A/cmil}$

Solving for minimum conductor area $A$:
$$A_{min} = 25,100 / 0.11759  ~=  213,450{ cmil}  ~=  213.5{ kcmil}$$

**Engineering Consequence:** Standard conductor sizes are 4/0 AWG (211.6 kcmil), 250 kcmil, 350 kcmil, and 500 kcmil. Because 4/0 AWG AL (211.6 kcmil) is strictly below the 213.5 kcmil thermal withstand threshold, **250 kcmil AL is the absolute statutory minimum conductor size permitted on the PCSFA 13.8 kV distribution network**. This governs the sizing of Item C04 (Lift Station, 60 A load), Item C06 underground risers (40 A load), and Item C07 (Warehouse W-3, 120 A load).

### 3.3 Cable Pulling Tension & Sidewall Bearing Pressure Analysis
Cable pulling calculations have been performed for every pull of the recommended designs using classical pulling mechanics in accordance with IEEE 1185, EPRI EL-5036, and UFGS 33 71 02:
- Conductor pulling eye maximum allowable tension: $T_{max} = 0.008  *  cmil  *  N_{cond}$ (12,000 lb for 3x 1/C 500 kcmil AL; 6,000 lb for 3x 1/C 250 kcmil AL).
- Maximum allowable sidewall bearing pressure (SWBP): **600 lb/ft** (governed by approved submittal SUB-33 71 02-07 for copper tape-shielded medium-voltage cable, overriding catalogue ratings per IEDS 1.3).
- Effective coefficient of friction: $\mu = 0.35$ with approved pulling lubricant in PVC/HDPE/RGS ducts.
- Straight section tension: $T_2 = T_1 + \mu \cdot w \cdot L$
- Horizontal bend tension: $T_2 = T_1 \cdot e^{\mu \theta}$
- Sidewall bearing pressure: $SWBP = \frac{T_{out}}{R}$
- Conduit fill limit: 40% maximum for three conductors (NEC Chapter 9 Table 1).
- Jam ratio ($D/d$): Recommended safe bands are $<2.8$ or $>3.2$ to eliminate triplexed cable wedging during pulling around elbows.

### Table 3.1: Cable Pulling Calculations Log (All 23 Pulls)
| Circuit | Pull ID | From | To | Length (ft) | Max Tension (lb) | Tension Limit (lb) | Max SWBP (lb/ft) | SWBP Limit (lb/ft) | Jam Ratio | Fill % | Status |
|:---|:---|:---|:---|---:|---:|---:|---:|---:|:---:|:---:|:---:|
| C01 | C01-P1 | START | MH-01 | 452.2 | 1,019.3 | 12,000 | 5.4 | 600.0 | 3.21 | 29.1% | **PASSED** |
| C01 | C01-P2 | MH-01 | MH-02 | 80.0 | 229.0 | 12,000 | 0.0 | 600.0 | 2.78 | 39.0% | **PASSED** |
| C01 | C01-P3 | MH-02 | END | 395.0 | 1,760.3 | 12,000 | 31.7 | 600.0 | 3.21 | 29.1% | **PASSED** |
| C02 | C02-P1 | START | MH-03 | 542.3 | 1,230.5 | 12,000 | 6.7 | 600.0 | 3.21 | 29.1% | **PASSED** |
| C02 | C02-P2 | MH-03 | MH-04 | 80.0 | 229.0 | 12,000 | 0.0 | 600.0 | 2.78 | 39.0% | **PASSED** |
| C02 | C02-P3 | MH-04 | END | 560.0 | 1,389.6 | 12,000 | 8.8 | 600.0 | 3.21 | 29.1% | **PASSED** |
| C03 | C03-P1 | START | MH-05 | 270.0 | 815.8 | 12,000 | 8.8 | 600.0 | 3.21 | 29.1% | **PASSED** |
| C03 | C03-P2 | MH-05 | END | 220.0 | 535.3 | 12,000 | 0.0 | 600.0 | 3.21 | 29.1% | **PASSED** |
| C04 | C04-P1 | START | MH-06 | 137.0 | 293.0 | 6,000 | 3.4 | 600.0 | 3.79 | 20.9% | **PASSED** |
| C04 | C04-P2 | MH-06 | MH-07 | 80.0 | 186.0 | 6,000 | 0.0 | 600.0 | 3.27 | 28.0% | **PASSED** |
| C04 | C04-P3 | MH-07 | MH-08 | 370.0 | 532.5 | 6,000 | 0.0 | 600.0 | 3.79 | 20.9% | **PASSED** |
| C04 | C04-P4 | MH-08 | MH-09 | 380.0 | 544.1 | 6,000 | 0.0 | 600.0 | 3.79 | 20.9% | **PASSED** |
| C04 | C04-P5 | MH-09 | MH-10 | 120.0 | 229.1 | 6,000 | 0.0 | 600.0 | 3.27 | 28.0% | **PASSED** |
| C04 | C04-P6 | MH-10 | END | 240.0 | 555.5 | 6,000 | 7.4 | 600.0 | 3.79 | 20.9% | **PASSED** |
| C05 | C05-P1 | START | PB-01 | 339.0 | 1,439.4 | 12,000 | 153.9 | 600.0 | 3.08 | 31.7% | **PASSED** |
| C05 | C05-P2 | PB-01 | END | 75.0 | 422.7 | 12,000 | 56.7 | 600.0 | 3.08 | 31.7% | **PASSED** |
| C06 | C06-P1 | START | P-01 | 268.0 | 480.1 | 6,000 | 6.2 | 600.0 | 3.79 | 20.9% | **PASSED** |
| C06 | C06-P2 | P-01 | P-08 | 1,620.0 | 657.0 | 6,000 | 0.0 | 600.0 | N/A | N/A | **PASSED** |
| C06 | C06-P3 | P-08 | END | 90.0 | 205.2 | 6,000 | 0.0 | 600.0 | 3.79 | 20.9% | **PASSED** |
| C07 | C07-P1 | START | MH-11 | 20.0 | 123.4 | 6,000 | 0.0 | 600.0 | 3.79 | 20.9% | **PASSED** |
| C07 | C07-P2 | MH-11 | MH-12 | 40.0 | 154.4 | 6,000 | 0.0 | 600.0 | 3.63 | 22.8% | **PASSED** |
| C07 | C07-P3 | MH-12 | MH-13 | 295.0 | 551.1 | 6,000 | 4.5 | 600.0 | 3.79 | 20.9% | **PASSED** |
| C07 | C07-P4 | MH-13 | END | 325.0 | 617.9 | 6,000 | 5.9 | 600.0 | 3.79 | 20.9% | **PASSED** |

As shown in Table 3.1, every cable pull operates well within allowable tension and SWBP thresholds, ensuring zero cable jacket elongation or insulation degradation during construction.

---
## 4. CIRCUIT-BY-CIRCUIT ANALYSIS & CONVEYANCE EVALUATION

### 4.01 Item C01: SS-1 Feeder F1 to MB-1 MSG-A (Primary)
**Circuit Operational Parameters:**
- **Origin / Destination:** Per RFP Section 01 11 00 1.2
- **Design Load Current:** 640 A | **Governing Installation Ampacity:** 335 A per set
- **Cable Configuration:** 2 set(s) of 3x 1/C 500 kcmil AL 15 kV 133% TR-XLPE (Underground)
- **Recommended Conveyance:** **CEDB** | **Total Route Length:** 927.2 LF
- **Financial Summary:** Direct Cost: **$233,595.26** | Contract Cost: **$297,849.36** | Total Project Cost: **$330,568.11** (**$356.52 / LF**)

#### Recommended Design Engineering Details (C01 — CEDB):
**Route Segments Summary:**
| Seg # | Method | Route Polyline Coordinates (x, y) | Length (ft) | Cover (in) | Duct Config | Spares | Soil / OSHA | Protective System | Dewatering |
|:---:|:---:|:---|---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | CE | `280,640; 330,625; 730,625` | 452.2 | 30" | 2x2 (5") | 2 | OSHA B | none | N |
| 2 | HDD | `730,625; 810,625` | 80.0 | 48" | 2x2 (5") | 2 | OSHA B | none | N |
| 3 | CE | `810,625; 1040,625; 1040,730; 1100,730` | 395.0 | 30" | 2x2 (5") | 2 | OSHA B | none | N |

**Associated Structures Summary:**
| Structure ID | Type / Kind | Coordinates (x, y) | Pole Height | Guys | Dead-End | Excavation Protection |
|:---|:---:|:---|:---:|:---:|:---:|:---:|
| **MH-01** | MH | (730.0, 625.0) | — | — | N | box |
| **MH-02** | MH | (810.0, 625.0) | — | — | N | box |

#### Comprehensive Alternatives Pricing & Permissibility Table (C01):
| Conveyance Type | Permitted? | Governing Decision Clause | Length (ft) | Labor (MH) | Labor ($) | Equip ($) | Mat ($) | Sub ($) | Direct ($) | Total Project ($) | Cost/LF ($/LF) | Selection Status |
|:---|:---:|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| **CEDB** | Y | UFC 3-550-01 3-11.2.1; PCSFA-IEDS 4.2 | 927.2 | 719.6 | $61,511.79 | $11,941.08 | $146,142.39 | $14,000.00 | $233,595.26 | $330,568.11 | $356.52 | **RECOMMENDED** |
| **UEDB** | N | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1 | 927.2 | 654.1 | $56,165.45 | $12,243.31 | $152,930.48 | $14,000.00 | $235,339.24 | $333,036.07 | $359.18 | Excluded |
| **DBC** | N | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1, 3-11.3.1 | 927.2 | 303.7 | $26,269.33 | $6,513.47 | $65,441.61 | $14,000.00 | $112,224.41 | $158,812.34 | $171.28 | Excluded |
| **HDD** | N | PCSFA-IEDS 4.3; UFC 3-550-01 3-11.4.1 | 927.2 | 450.6 | $38,996.99 | $10,615.43 | $64,207.96 | $103,497.76 | $217,318.14 | $307,533.84 | $331.68 | Excluded |
| **OH** | N | PCSFA-IEDS 4.1; UFC 3-550-01 3-11 | 927.2 | 202.8 | $17,762.82 | $4,523.61 | $37,840.39 | $0.00 | $60,126.82 | $85,087.38 | $91.77 | Excluded |

**Technical & Economic Selection Rationale:**
Item C01 represents a vital mission-critical feeder serving Mission Support Facility MB-1. Open-trench unencased (UEDB) and direct-buried (DBC) typologies are prohibited by UFC 3-550-01 3-11.2.1 and PCSFA-IEDS 4.2 due to lack of mechanical protection against strike hazards and inability to replace cables. Overhead lines (OH) are barred inside the industrial park polygon (IEDS 4.1). Continuous directional drilling (HDD) is technically unacceptable due to thermal derating and lack of pulling vaults. Therefore, CEDB is the sole admissible conveyance. Between CEDB and HDD, CEDB provides lower cost and superior reliability.

### 4.02 Item C02: SS-1 Feeder F2 to MB-1 MSG-B (Secondary)
**Circuit Operational Parameters:**
- **Origin / Destination:** Per RFP Section 01 11 00 1.2
- **Design Load Current:** 560 A | **Governing Installation Ampacity:** 335 A per set
- **Cable Configuration:** 2 set(s) of 3x 1/C 500 kcmil AL 15 kV 133% TR-XLPE (Underground)
- **Recommended Conveyance:** **CEDB** | **Total Route Length:** 1,182.3 LF
- **Financial Summary:** Direct Cost: **$280,050.61** | Contract Cost: **$357,082.99** | Total Project Cost: **$396,308.56** (**$335.20 / LF**)

#### Recommended Design Engineering Details (C02 — CEDB):
**Route Segments Summary:**
| Seg # | Method | Route Polyline Coordinates (x, y) | Length (ft) | Cover (in) | Duct Config | Spares | Soil / OSHA | Protective System | Dewatering |
|:---:|:---:|:---|---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | CE | `280,520; 340,380; 730,380` | 542.3 | 30" | 2x2 (5") | 2 | OSHA B | none | N |
| 2 | HDD | `730,380; 810,380` | 80.0 | 48" | 2x2 (5") | 2 | OSHA B | none | N |
| 3 | CE | `810,380; 1330,380; 1330,420` | 560.0 | 30" | 2x2 (5") | 2 | OSHA B | none | N |

**Associated Structures Summary:**
| Structure ID | Type / Kind | Coordinates (x, y) | Pole Height | Guys | Dead-End | Excavation Protection |
|:---|:---:|:---|:---:|:---:|:---:|:---:|
| **MH-03** | MH | (730.0, 380.0) | — | — | N | box |
| **MH-04** | MH | (810.0, 380.0) | — | — | N | box |

#### Comprehensive Alternatives Pricing & Permissibility Table (C02):
| Conveyance Type | Permitted? | Governing Decision Clause | Length (ft) | Labor (MH) | Labor ($) | Equip ($) | Mat ($) | Sub ($) | Direct ($) | Total Project ($) | Cost/LF ($/LF) | Selection Status |
|:---|:---:|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| **CEDB** | Y | UFC 3-550-01 3-11.2.1; PCSFA-IEDS 4.2 | 1,182.3 | 889.0 | $75,924.74 | $14,866.27 | $175,259.60 | $14,000.00 | $280,050.61 | $396,308.56 | $335.20 | **RECOMMENDED** |
| **UEDB** | N | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1 | 1,182.3 | 803.8 | $68,968.57 | $15,259.50 | $184,091.65 | $14,000.00 | $282,319.72 | $399,519.65 | $337.92 | Excluded |
| **DBC** | N | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1, 3-11.3.1 | 1,182.3 | 374.6 | $32,371.17 | $8,245.52 | $81,896.09 | $14,000.00 | $136,512.78 | $193,183.59 | $163.40 | Excluded |
| **HDD** | N | PCSFA-IEDS 4.3; UFC 3-550-01 3-11.4.1 | 1,182.3 | 559.8 | $48,409.86 | $13,426.88 | $80,290.98 | $130,487.34 | $272,615.06 | $385,786.27 | $326.30 | Excluded |
| **OH** | N | PCSFA-IEDS 4.1; UFC 3-550-01 3-11 | 1,182.3 | 243.3 | $21,252.73 | $5,351.24 | $45,037.92 | $0.00 | $71,641.89 | $101,382.73 | $85.75 | Excluded |

**Technical & Economic Selection Rationale:**
Item C02 represents a vital mission-critical feeder serving Mission Support Facility MB-1. Open-trench unencased (UEDB) and direct-buried (DBC) typologies are prohibited by UFC 3-550-01 3-11.2.1 and PCSFA-IEDS 4.2 due to lack of mechanical protection against strike hazards and inability to replace cables. Overhead lines (OH) are barred inside the industrial park polygon (IEDS 4.1). Continuous directional drilling (HDD) is technically unacceptable due to thermal derating and lack of pulling vaults. Therefore, CEDB is the sole admissible conveyance. Between CEDB and HDD, CEDB provides lower cost and superior reliability.

### 4.03 Item C03: SS-1 Feeder F3 to CUP-1 SWG-C1
**Circuit Operational Parameters:**
- **Origin / Destination:** Per RFP Section 01 11 00 1.2
- **Design Load Current:** 400 A | **Governing Installation Ampacity:** 410 A per set
- **Cable Configuration:** 1 set(s) of 3x 1/C 500 kcmil AL 15 kV 133% TR-XLPE (Underground)
- **Recommended Conveyance:** **CEDB** | **Total Route Length:** 490.0 LF
- **Financial Summary:** Direct Cost: **$84,352.31** | Contract Cost: **$107,554.76** | Total Project Cost: **$119,369.65** (**$243.61 / LF**)

#### Recommended Design Engineering Details (C03 — CEDB):
**Route Segments Summary:**
| Seg # | Method | Route Polyline Coordinates (x, y) | Length (ft) | Cover (in) | Duct Config | Spares | Soil / OSHA | Protective System | Dewatering |
|:---:|:---:|:---|---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | CE | `240,700; 240,740; 470,740; 470,755` | 285.0 | 30" | 1x2 (5") | 1 | OSHA B | none | N |
| 2 | CE | `470,755; 470,905` | 150.0 | 24" | 1x2 (5") | 1 | OSHA B | none | N |
| 3 | CE | `470,905; 470,960` | 55.0 | 30" | 1x2 (5") | 1 | OSHA B | none | N |

**Associated Structures Summary:**
| Structure ID | Type / Kind | Coordinates (x, y) | Pole Height | Guys | Dead-End | Excavation Protection |
|:---|:---:|:---|:---:|:---:|:---:|:---:|
| **MH-05** | MH | (470.0, 740.0) | — | — | N | box |

#### Comprehensive Alternatives Pricing & Permissibility Table (C03):
| Conveyance Type | Permitted? | Governing Decision Clause | Length (ft) | Labor (MH) | Labor ($) | Equip ($) | Mat ($) | Sub ($) | Direct ($) | Total Project ($) | Cost/LF ($/LF) | Selection Status |
|:---|:---:|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| **CEDB** | Y | UFC 3-550-01 3-11.2.1; PCSFA-IEDS 4.2 | 490.0 | 277.0 | $23,579.69 | $3,985.63 | $56,786.99 | $0.00 | $84,352.31 | $119,369.65 | $243.61 | **RECOMMENDED** |
| **UEDB** | N | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1 | 490.0 | 248.4 | $21,251.40 | $4,057.95 | $57,542.85 | $0.00 | $82,852.20 | $117,246.79 | $239.28 | Excluded |
| **DBC** | N | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1, 3-11.3.1 | 490.0 | 97.7 | $8,461.11 | $1,837.28 | $19,035.65 | $0.00 | $29,334.04 | $41,511.54 | $84.72 | Excluded |
| **HDD** | N | PCSFA-IEDS 4.3; UFC 3-550-01 3-11.4.1 | 490.0 | 131.8 | $11,432.43 | $2,898.52 | $18,322.14 | $41,464.00 | $74,117.09 | $104,885.46 | $214.05 | Excluded |
| **OH** | N | PCSFA-IEDS 4.1; UFC 3-550-01 3-11 | 490.0 | 154.4 | $13,587.40 | $3,528.70 | $29,251.83 | $0.00 | $46,367.93 | $65,616.74 | $133.91 | Excluded |

**Technical & Economic Selection Rationale:**
Item C03 serves Central Utility Plant CUP-1 across parking facility P-1. CEDB is the only permitted method under IEDS 4.2. Overhead construction is prohibited by IEDS 4.1. Unencased and direct-buried methods are excluded by UFC 3-550-01. CEDB with localized heavy structural reinforcement under Parking Lot P-1 ensures lifetime survivability against heavy vehicular shear.

### 4.04 Item C04: CUP-1 Feeder CF-2 to Lift Station LS-2
**Circuit Operational Parameters:**
- **Origin / Destination:** Per RFP Section 01 11 00 1.2
- **Design Load Current:** 60 A | **Governing Installation Ampacity:** 300 A per set
- **Cable Configuration:** 1 set(s) of 3x 1/C 250 kcmil AL 15 kV 133% TR-XLPE (Underground)
- **Recommended Conveyance:** **CEDB** | **Total Route Length:** 1,327.0 LF
- **Financial Summary:** Direct Cost: **$260,519.67** | Contract Cost: **$332,179.75** | Total Project Cost: **$368,669.70** (**$277.82 / LF**)

#### Recommended Design Engineering Details (C04 — CEDB):
**Route Segments Summary:**
| Seg # | Method | Route Polyline Coordinates (x, y) | Length (ft) | Cover (in) | Duct Config | Spares | Soil / OSHA | Protective System | Dewatering |
|:---:|:---:|:---|---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | CE | `600,1020; 705,1020` | 105.0 | 24" | 1x2 (5") | 1 | OSHA B | none | N |
| 2 | CE | `705,1020; 730,1000` | 32.0 | 30" | 1x2 (5") | 1 | OSHA B | none | N |
| 3 | HDD | `730,1000; 810,1000` | 80.0 | 48" | 1x2 (5") | 1 | OSHA B | none | N |
| 4 | CE | `810,1000; 1560,1000` | 750.0 | 30" | 1x2 (5") | 1 | OSHA B | none | N |
| 5 | HDD | `1560,1000; 1680,1000` | 120.0 | 120" | 1x2 (5") | 1 | OSHA C | none | N |
| 6 | CE | `1680,1000; 1760,1000; 1760,1160` | 240.0 | 30" | 1x2 (5") | 1 | OSHA C | none | Y |

**Associated Structures Summary:**
| Structure ID | Type / Kind | Coordinates (x, y) | Pole Height | Guys | Dead-End | Excavation Protection |
|:---|:---:|:---|:---:|:---:|:---:|:---:|
| **MH-06** | MH | (730.0, 1,000.0) | — | — | N | box |
| **MH-07** | MH | (810.0, 1,000.0) | — | — | N | box |
| **MH-08** | MH | (1,180.0, 1,000.0) | — | — | N | box |
| **MH-09** | MH | (1,560.0, 1,000.0) | — | — | N | box |
| **MH-10** | MH | (1,680.0, 1,000.0) | — | — | N | box |

#### Comprehensive Alternatives Pricing & Permissibility Table (C04):
| Conveyance Type | Permitted? | Governing Decision Clause | Length (ft) | Labor (MH) | Labor ($) | Equip ($) | Mat ($) | Sub ($) | Direct ($) | Total Project ($) | Cost/LF ($/LF) | Selection Status |
|:---|:---:|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| **CEDB** | Y | UFC 3-550-01 3-11.2.1; PCSFA-IEDS 4.2 | 1,327.0 | 667.2 | $57,157.67 | $10,535.84 | $164,594.16 | $28,232.00 | $260,519.67 | $368,669.70 | $277.82 | **RECOMMENDED** |
| **UEDB** | N | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1 | 1,327.0 | 604.3 | $51,684.82 | $10,727.82 | $167,893.42 | $28,232.00 | $258,538.06 | $365,865.46 | $275.71 | Excluded |
| **DBC** | N | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1, 3-11.3.1 | 1,327.0 | 218.7 | $18,849.93 | $4,722.08 | $32,583.31 | $28,232.00 | $84,387.32 | $119,419.19 | $89.99 | Excluded |
| **HDD** | N | PCSFA-IEDS 4.3; UFC 3-550-01 3-11.4.1 | 1,327.0 | 310.9 | $26,874.55 | $7,510.81 | $31,014.46 | $103,067.20 | $168,467.02 | $238,403.06 | $179.66 | Excluded |
| **OH** | N | PCSFA-IEDS 4.1; UFC 3-550-01 3-11 | 1,327.0 | 250.1 | $21,843.91 | $5,541.42 | $40,822.16 | $0.00 | $68,207.49 | $96,522.60 | $72.74 | Excluded |

**Technical & Economic Selection Rationale:**
Item C04 traverses complex topography, crossing Mission Drive and Drainage Channel DC-1. CEDB is the only permitted conveyance for the overall run. Directional drilling is integrated specifically for the Mission Drive and DC-1 crossings (80 LF and 120 LF). Continuous HDD for the entire 1,327 LF run is prohibited by IEDS 4.3 and UFC 3-550-01. Splicing/pulling manholes MH-06 through MH-10 divide the pull lengths into manageable tension sections.

### 4.05 Item C05: MB-1 MSG-A to Unit Substation USS-A1
**Circuit Operational Parameters:**
- **Origin / Destination:** Per RFP Section 01 11 00 1.2
- **Design Load Current:** 200 A | **Governing Installation Ampacity:** 245 A per set
- **Cable Configuration:** 1 set(s) of 3x 1/C 500 kcmil AL 15 kV 133% TR-XLPE (Underground)
- **Recommended Conveyance:** **RMC** | **Total Route Length:** 400.0 LF
- **Financial Summary:** Direct Cost: **$82,464.82** | Contract Cost: **$105,148.08** | Total Project Cost: **$116,698.60** (**$291.75 / LF**)

#### Recommended Design Engineering Details (C05 — RMC):
**Route Segments Summary:**
| Seg # | Method | Route Polyline Coordinates (x, y) | Length (ft) | Cover (in) | Duct Config | Spares | Soil / OSHA | Protective System | Dewatering |
|:---:|:---:|:---|---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | RMC | `1132,732; 1132,710; 1442,710; 1442,642` | 400.0 | N/A | N/A | 0 | OSHA None | none | N |

**Associated Structures Summary:**
| Structure ID | Type / Kind | Coordinates (x, y) | Pole Height | Guys | Dead-End | Excavation Protection |
|:---|:---:|:---|:---:|:---:|:---:|:---:|
| **PB-01** | PULLBOX | (1,442.0, 710.0) | — | — | N | none |

#### Comprehensive Alternatives Pricing & Permissibility Table (C05):
| Conveyance Type | Permitted? | Governing Decision Clause | Length (ft) | Labor (MH) | Labor ($) | Equip ($) | Mat ($) | Sub ($) | Direct ($) | Total Project ($) | Cost/LF ($/LF) | Selection Status |
|:---|:---:|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| **RMC** | Y | UFC 3-520-01 Table 3-1; UFGS 26 20 00 3.1.6; PCSFA-IEDS 5.1 | 400.0 | 287.0 | $29,303.88 | $1,580.16 | $51,580.78 | $0.00 | $82,464.82 | $116,698.60 | $291.75 | **RECOMMENDED** |
| **EMT** | N | UFGS 26 20 00 3.1.6.7 | 400.0 | 231.6 | $23,646.54 | $1,252.85 | $29,589.74 | $0.00 | $54,489.13 | $77,109.31 | $192.77 | Excluded |
| **TRAY-EN** | N | PCSFA-IEDS 5.1; A-501 Ceiling Schedule | 400.0 | 303.1 | $30,943.69 | $1,675.03 | $46,791.02 | $0.00 | $79,409.74 | $112,375.26 | $280.94 | Excluded |
| **TRAY-LD** | N | UFC 3-520-01 Table 3-1; PCSFA-IEDS 5.1 | 400.0 | 279.1 | $28,496.22 | $1,533.43 | $36,903.17 | $0.00 | $66,932.82 | $94,718.77 | $236.80 | Excluded |

**Technical & Economic Selection Rationale:**
Item C05 is an interior 13.8 kV feeder inside MB-1. Rigid Metal Conduit (RMC) is the only permitted method. EMT is prohibited above 600 V by NEC 300.37 and IEDS 5.1. Solid-bottom enclosed tray (TRAY-EN) and ladder tray (TRAY-LD) violate the 18-in maintenance clearance required below the ceiling joists in Corridor COR-1 and infringe upon the 10-ft keep-out zone surrounding SCIF IT-1. RMC provides robust physical containment and EMC shielding.

### 4.06 Item C06: SS-1 Feeder F4 to Gate House GH-1
**Circuit Operational Parameters:**
- **Origin / Destination:** Per RFP Section 01 11 00 1.2
- **Design Load Current:** 40 A | **Governing Installation Ampacity:** 196 A per set
- **Cable Configuration:** 1 set(s) of 3x 1/C 250 kcmil AL 15 kV 133% TR-XLPE (1/0 Raven)
- **Recommended Conveyance:** **OH** | **Total Route Length:** 1,978.0 LF
- **Financial Summary:** Direct Cost: **$89,590.88** | Contract Cost: **$114,234.28** | Total Project Cost: **$126,782.91** (**$64.10 / LF**)

#### Recommended Design Engineering Details (C06 — OH):
**Route Segments Summary:**
| Seg # | Method | Route Polyline Coordinates (x, y) | Length (ft) | Cover (in) | Duct Config | Spares | Soil / OSHA | Protective System | Dewatering |
|:---:|:---:|:---|---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | CE | `180,480; 180,420; 195,395; 180,370; 180,220` | 268.3 | 30" | 1x2 (5") | 1 | OSHA B | none | N |
| 2 | OH | `180,220; 1800,220` | 1,620.0 | N/A | N/A | 0 | OSHA None | none | N |
| 3 | CE | `1800,220; 1800,130` | 90.0 | 30" | 1x2 (5") | 1 | OSHA B | none | N |

**Associated Structures Summary:**
| Structure ID | Type / Kind | Coordinates (x, y) | Pole Height | Guys | Dead-End | Excavation Protection |
|:---|:---:|:---|:---:|:---:|:---:|:---:|
| **P-01** | RISER_POLE | (180.0, 220.0) | 45 ft | 1 | Y | none |
| **P-02** | POLE | (460.0, 220.0) | 45 ft | 0 | N | none |
| **P-03** | POLE | (740.0, 220.0) | 50 ft | 0 | N | none |
| **P-04** | POLE | (810.0, 220.0) | 50 ft | 0 | N | none |
| **P-05** | POLE | (1,057.5, 220.0) | 45 ft | 0 | N | none |
| **P-06** | POLE | (1,305.0, 220.0) | 45 ft | 0 | N | none |
| **P-07** | POLE | (1,552.5, 220.0) | 45 ft | 0 | N | none |
| **P-08** | RISER_POLE | (1,800.0, 220.0) | 45 ft | 1 | Y | none |

#### Comprehensive Alternatives Pricing & Permissibility Table (C06):
| Conveyance Type | Permitted? | Governing Decision Clause | Length (ft) | Labor (MH) | Labor ($) | Equip ($) | Mat ($) | Sub ($) | Direct ($) | Total Project ($) | Cost/LF ($/LF) | Selection Status |
|:---|:---:|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| **CEDB** | Y | UFC 3-550-01 3-11.2.1; PCSFA-IEDS 4.2 | 1,978.0 | 869.3 | $74,027.25 | $14,054.83 | $200,791.65 | $14,000.00 | $302,873.73 | $428,606.28 | $216.69 | Admissible (Higher Cost) |
| **UEDB** | N | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1 | 1,978.0 | 797.7 | $68,222.16 | $14,522.15 | $207,510.76 | $14,000.00 | $304,255.07 | $430,561.06 | $217.67 | Excluded |
| **DBC** | N | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1, 3-11.3.1 | 1,978.0 | 319.2 | $27,471.37 | $7,029.03 | $47,638.24 | $14,000.00 | $96,138.64 | $136,048.86 | $68.78 | Excluded |
| **HDD** | N | PCSFA-IEDS 4.3; UFC 3-550-01 3-11.4.1 | 1,978.0 | 450.2 | $38,885.09 | $11,098.15 | $44,996.12 | $150,980.80 | $245,960.16 | $348,066.07 | $175.97 | Excluded |
| **OH** | Y | PCSFA-IEDS 4.1; UFC 3-550-01 3-11 | 1,978.0 | 336.1 | $29,253.72 | $7,275.58 | $53,061.58 | $0.00 | $89,590.88 | $126,782.91 | $64.10 | **RECOMMENDED** |

**Technical & Economic Selection Rationale:**
Item C06 serves Gate House GH-1 along the southern Annex boundary (y=220). Both CEDB and Overhead (OH) are permitted because this corridor lies entirely south of the industrial core keep-out polygon (IEDS 4.1). CEDB totals $428,606.28 ($216.69/LF), whereas Overhead construction totals **$126,782.91** ($64.10/LF). In accordance with the RFP Core Directives ('Among designs the criteria permit, the one with the lower total project cost is the better design'), **Overhead construction (OH) is selected, achieving a direct savings of $301,823.37**.

### 4.07 Item C07: CUP-1 Feeder CF-1 to Warehouse W-3
**Circuit Operational Parameters:**
- **Origin / Destination:** Per RFP Section 01 11 00 1.2
- **Design Load Current:** 120 A | **Governing Installation Ampacity:** 300 A per set
- **Cable Configuration:** 1 set(s) of 3x 1/C 250 kcmil AL 15 kV 133% TR-XLPE (Underground)
- **Recommended Conveyance:** **CEDB** | **Total Route Length:** 680.0 LF
- **Financial Summary:** Direct Cost: **$157,968.31** | Contract Cost: **$201,420.01** | Total Project Cost: **$223,546.00** (**$328.74 / LF**)

#### Recommended Design Engineering Details (C07 — CEDB):
**Route Segments Summary:**
| Seg # | Method | Route Polyline Coordinates (x, y) | Length (ft) | Cover (in) | Duct Config | Spares | Soil / OSHA | Protective System | Dewatering |
|:---:|:---:|:---|---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | CE | `470,1060; 470,1080` | 20.0 | 30" | 1x2 (5") | 1 | OSHA B | none | N |
| 2 | JB | `470,1080; 470,1120` | 40.0 | 42" | 1x2 (5") | 1 | OSHA B | none | N |
| 3 | CE | `470,1120; 470,1135; 1030,1135; 1030,1180` | 620.0 | 30" | 1x2 (5") | 1 | OSHA B | none | N |

**Associated Structures Summary:**
| Structure ID | Type / Kind | Coordinates (x, y) | Pole Height | Guys | Dead-End | Excavation Protection |
|:---|:---:|:---|:---:|:---:|:---:|:---:|
| **MH-11** | MH | (470.0, 1,080.0) | — | — | N | box |
| **MH-12** | MH | (470.0, 1,120.0) | — | — | N | box |
| **MH-13** | MH | (750.0, 1,135.0) | — | — | N | box |

#### Comprehensive Alternatives Pricing & Permissibility Table (C07):
| Conveyance Type | Permitted? | Governing Decision Clause | Length (ft) | Labor (MH) | Labor ($) | Equip ($) | Mat ($) | Sub ($) | Direct ($) | Total Project ($) | Cost/LF ($/LF) | Selection Status |
|:---|:---:|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| **CEDB** | Y | UFC 3-550-01 3-11.2.1; PCSFA-IEDS 4.2 | 680.0 | 353.6 | $30,184.02 | $5,521.87 | $100,142.42 | $22,120.00 | $157,968.31 | $223,546.00 | $328.74 | **RECOMMENDED** |
| **UEDB** | N | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1 | 680.0 | 329.4 | $28,226.56 | $5,679.45 | $102,408.09 | $22,120.00 | $158,434.10 | $224,205.15 | $329.71 | Excluded |
| **DBC** | N | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1, 3-11.3.1 | 680.0 | 125.1 | $10,813.83 | $2,491.20 | $23,620.42 | $22,120.00 | $59,045.45 | $83,557.10 | $122.88 | Excluded |
| **HDD** | N | PCSFA-IEDS 4.3; UFC 3-550-01 3-11.4.1 | 680.0 | 172.4 | $14,937.81 | $3,945.52 | $17,118.72 | $55,448.00 | $91,450.05 | $129,413.88 | $190.31 | Excluded |
| **OH** | N | PCSFA-IEDS 4.1; UFC 3-550-01 3-11 | 680.0 | 159.3 | $14,038.29 | $3,732.07 | $27,768.18 | $0.00 | $45,538.54 | $64,443.04 | $94.77 | Excluded |

**Technical & Economic Selection Rationale:**
Item C07 feeds Warehouse W-3 across active rail spur RR-SPUR-2. CEDB is the governing underground standard per IEDS 4.2. An open cut across the railroad is prohibited by AREMA and UFC 3-550-01; therefore, a 40-ft Jack-and-Bore (JB) crossing is integrated between MH-11 and MH-12 at 42 in depth. Continuous HDD is excluded by IEDS 4.3.

---
## 5. ESTIMATING METHODOLOGY, COST BASIS & MARKUPS
### 5.1 Labor Classification Plan & Loaded Rates
All direct craft labor is estimated bottom-up utilizing local prevailing wages under Wage Determination **CA20260022 Modification 5** (published 2026-08-06, legally effective per 29 CFR 1.6(c)(2)(ii)(A)). Payroll taxes and insurance (FICA 7.65%, FUTA 0.60%, CA SUI 3.40%, and California Workers' Compensation) are applied strictly to base wages in accordance with the Contractor's Payroll Burden and Insurance Plan; fringe benefits are added unburdened.
$$Loaded Rate = Base  *  (1 + Burden %) + Fringe$$

### Table 5.1: Labor Classification & Loaded Hourly Rates
| Class Code | WD Group | Classification Title | Base ($/hr) | Fringe ($/hr) | Burden (%) | Loaded Rate ($/hr) |
|:---|:---|:---|---:|---:|---:|---:|
| **LINEMAN** | `ELEC1245-001` | LINE CONSTRUCTION: (1) LINEMAN; CABLE SPLICER | $70.16 | $24.71 | 20.39% | **$109.18** |
| **EQSPEC** | `ELEC1245-001` | LINE CONSTRUCTION: (2) EQUIPMENT SPECIALIST | $53.30 | $22.26 | 20.39% | **$86.43** |
| **GROUNDMAN** | `ELEC1245-001` | LINE CONSTRUCTION: (3) GROUNDMAN | $40.76 | $21.76 | 20.39% | **$70.83** |
| **LAB1** | `LABO0300-003` | LABORER GROUP 1 | $46.48 | $25.95 | 19.00% | **$81.26** |
| **LAB3** | `LABO0300-003` | LABORER GROUP 3 | $47.58 | $25.95 | 19.00% | **$82.57** |
| **LAB4** | `LABO0300-003` | LABORER GROUP 4 (PREFABRICATED MANHOLE INSTALLER) | $49.13 | $25.95 | 19.00% | **$84.41** |
| **PUMPOP** | `ENGI0012-024` | OPERATOR: POWER EQUIPMENT, ALL OTHER WORK: GROUP 1 (PUMP OPERATOR) | $63.40 | $33.20 | 19.00% | **$108.65** |
| **ELECTRICIAN** | `ELEC0011-004` | ELECTRICIAN: INSIDE ELECTRICAL WORK: JOURNEYMAN ELECTRICIAN | $60.80 | $31.59 | 15.77% | **$101.98** |
| **SPLICER_IN** | `ELEC0011-004` | ELECTRICIAN: INSIDE ELECTRICAL WORK: CABLE SPLICER (5% ADDITIONAL) | $63.84 | $31.59 | 15.77% | **$105.50** |

### 5.2 Construction Equipment Rates
Contractor-owned equipment rates are derived from USACE EP 1110-1-8 (Region VII, 2025/2026), adjusted for jobsite off-road diesel ($3.85/gal) and gasoline ($4.45/gal) per Fuel Supplier Invoice FSI-0826-2207, with fuel and oil (FOG) adjustments per EP 1110-1-8 Sections 3.9 and 3.10. Specialized equipment (line truck, cable puller, trench box, scissor lift) is priced per Rental Quote RQ-26-0419.

### Table 5.2: Equipment Hourly Rates
| Equipment ID | Description | Source / Authority | Hourly Rate ($/hr) |
|:---|:---|:---|---:|
| **H25CA040** | HYDRAULIC EXCAVATOR, CRAWLER, 40,600 LBS, 1.00 CY | EP 1110-1-8 Region VII | **$58.68** |
| **T30DW022** | TRENCHER, CHAIN TYPE CUTTER, 48" MAX DEPTH X 3.5"-6" WIDTH | EP 1110-1-8 Region VII | **$14.61** |
| **L50CA001** | LOADER / BACKHOE, WHEEL, 1.00 CY, 14.5' DIGGING DEPTH | EP 1110-1-8 Region VII | **$30.98** |
| **C10BO003** | COMPACTOR, VIBROPLATE, 14.2" X 22" PLATE, 2,250 LBS | EP 1110-1-8 Region VII | **$2.90** |
| **C80TE008** | CRANES, HYDRAULIC, TRUCK MTD, ROUGH TERRAIN, 25 TON | EP 1110-1-8 Region VII | **$61.06** |
| **P50WC002** | PUMP, WATER, CENTRIFUGAL, TRASH, ENGINE DRIVE, 3" DIA | EP 1110-1-8 Region VII | **$3.85** |
| **RQ-BDT** | Bucket / digger-derrick line truck, 47 ft, 4x4 | Rental Quote RQ-26-0419 | **$96.00** |
| **RQ-PUL** | Cable puller, hydraulic capstan/bullwheel, 10,000 lb | Rental Quote RQ-26-0419 | **$58.50** |
| **RQ-TBX** | Trench shield (box), 8 ft x 20 ft, steel | Rental Quote RQ-26-0419 | **$7.25** |
| **RQ-LFT** | Scissor lift, 26 ft, electric (indoor) | Rental Quote RQ-26-0419 | **$11.80** |

### 5.3 Material Pricing & Price-Index Adjustments
Materials are priced from Supplier Quote Q-2608-114, adjusted by BLS Producer Price Index WPU102603 escalation to the study date (September 2026), incorporating standard scrap/waste factors (3% for duct/wire, 5% for concrete/sand/rebar) and local Los Angeles County sales tax of 9.50%.

### 5.4 Roll-up Markups & Statutory Additions
Markup compounding follows UFC 3-740-05 and RFP Section 01 11 00 Clause 3.6:
1. **Job Office Overhead (JOOH):** 9.50% of Direct Cost.
2. **Home Office Overhead (HOOH):** 4.50% of (Direct Cost + JOOH).
3. **Profit:** **7.9714%** calculated via UFC 3-740-05 Section 11-2 weighted guidelines applied to (Direct + JOOH + HOOH).
4. **Surety Bond:** **1.24043%** effective rate derived from Sierra Surety Class B graduated rate schedule on the combined base sum of the 7 recommended items ($1,468,431.67) plus a 3% surcharge for the 15-month performance period.
5. **Escalation to Midpoint of Construction:** Factor of **1.019388** (increment of 1.9388%) derived from linear daily interpolation of UFS 3-701-01 Table 4-2 between study date (2026-09-15) and construction midpoint (2027-08-18).
6. **Design Contingency:** 5.00% of Contract Cost.
7. **Supervision, Inspection & Overhead (SIOH):** 5.70% of (Contract Cost + Contingency) per UFC 3-740-05 13-3.2.
8. **Area Cost Factor (ACF):** **1.000** (UFS 3-701-01 Clause 4-1.1 strictly prohibits applying regional cost factors to locally priced bottom-up estimates).

---
## 6. REGISTER OF APPLIED GOVERNING REQUIREMENTS
The formal register below documents all mandatory design, code, and safety requirements implemented in the conveyance design:

| Req ID | Governing Document | Clause | Requirement Summary | Applied Design Value | Applies To |
|:---|:---|:---|:---|:---|:---|
| **REQ-01** | PCSFA-IEDS Rev 3 | 4.2 | Underground primary distribution shall be concrete-encased ductbanks | `CEDB required; DBC and UEDB prohibited` | All site items (C01-C04, C06, C07) |
| **REQ-02** | PCSFA-IEDS Rev 3 | 4.1 | Overhead lines prohibited inside industrial area and crane area | `OH prohibited in industrial polygon` | C01, C02, C03, C04, C07 |
| **REQ-03** | PCSFA-IEDS Rev 3 | 4.1 | Overhead distribution permitted outside industrial area | `OH permitted along south corridor` | C06 |
| **REQ-04** | PCSFA-IEDS Rev 3 | 4.4 | Redundancy separation between Bus A and Bus B feeders | `Minimum 20 ft separation` | C01/C03 (Bus A) vs C02/C06 (Bus B) |
| **REQ-05** | PCSFA-IEDS Rev 3 | 4.3 | Pavement crossing restrictions for Mission Drive and Perimeter Road | `No open cut; directional bore or jack-and-bore` | C01, C02, C04, C06 |
| **REQ-06** | PCSFA-IEDS Rev 3 | 4.3 | Drainage channel DC-1 crossing restriction | `No open cut; directional bore` | C04 |
| **REQ-07** | PCSFA-IEDS Rev 3 | 4.5 | Active rail spur RR-SPUR-2 crossing requirement | `Jacked RGS conduit where length <= 50 ft` | C07 |
| **REQ-08** | PCSFA-IEDS Rev 3 | 4.14 | Retained tree protection zone (TPZ) | `Radius = 1 ft per inch DBH; no open excavation` | Retained trees T-201, T-204, T-206, T-208 |
| **REQ-09** | PCSFA-IEDS Rev 3 | 2.4 | Cable short-circuit withstand requirement | `Cable must withstand available fault current for backup clearing time` | All 13.8 kV circuits (250 kcmil minimum AL) |
| **REQ-10** | PCSFA-IEDS Rev 3 | 2.3 | Feeder load factor for ampacity sizing | `100% for F1, F2; 75% for other feeders` | C01, C02 at 100% LF; C03, C04, C06, C07 at 75% LF |
| **REQ-11** | PCSFA-IEDS Rev 3 | 4.8 | Ductbank design: minimum 5 in duct, 3 in encasement/spacing, spare ducts | `Minimum 1/3 spare ducts (50% for 2x2 and 1x2)` | C01-C04, C06, C07 |
| **REQ-12** | PCSFA-IEDS Rev 3 | 4.9 | Overhead line design: Class 3 poles, 50 ft at road crossings, spans <= 300 ft | `50 ft poles at Mission Drive crossing` | C06 |
| **REQ-13** | PCSFA-IEDS Rev 3 | 5.1 | Interior MV raceways: RMC permitted; EMT and tray headroom limits | `EMT prohibited >600 V; tray requires 18 in space` | C05 inside MB-1 |
| **REQ-14** | PCSFA-IEDS Rev 3 | 5.1 | SCIF IT-1 keep-out zone | `No conveyances within 10 ft of SCIF walls` | C05 route in corridor COR-1 |
| **REQ-15** | UFC 3-550-01 | 3-11.2.2 | Minimum burial depth for underground conduits | `18 in general, 24 in under roads/pavement` | All underground segments |
| **REQ-16** | UFC 3-550-01 | App B | Directional bore cover requirements | `48 in under pavement, 120 in under non-pavement` | HDD crossings on C01, C02, C04 |
| **REQ-17** | UFC 3-550-01 | 3-11.5.5 | Air Force manhole distance from fueling points | `Maintain minimum 200 ft separation from fuel points` | Manholes relative to FP-1 generator fill |
| **REQ-18** | 29 CFR 1926 Subpart P | App A & B | OSHA excavation classification and sloping | `Type B slope 1:1; Type C slope 1.5:1; excavations >= 5 ft protected` | Trench and manhole excavations |
| **REQ-19** | UFC 3-740-05 | 11-2 | Profit computation by weighted guidelines | `Factor rates and weights per programmed amount and duration` | Markups profit_pct |
| **REQ-20** | UFS 3-701-01 | 4-1.1 | Area Cost Factor prohibition on bottom-up estimates | `Area cost factor applied = 1.0` | Markups area_cost_factor_applied |

---
## 7. FINDINGS & CORRECTIONS IN GOVERNMENT-FURNISHED DOCUMENTS
In accordance with RFP Section 01 11 00 Clause 1.6, the design-build team conducted a rigorous quality control audit of all Government-Furnished Information (GFI). The following defects, omissions, and discrepancies were identified, resolved per governing order of precedence, and incorporated into the design:

| Finding ID | Document & Citation | Affected Element | Discrepancy & Conflicting Values | Applied Engineering Correction |
|:---|:---|:---|:---|:---|
| **FIND-01** | E-001 Rev B vs Protective Device Settings Rev D | **SS-1 Feeder F1** | E-001 shows F1 51P pickup as 560 A; Settings Schedule Rev D increases pickup to 640 A for MB-1 Phase 2 load | Governed by Settings Schedule Rev D (640 A) per IEDS 1.3 order of precedence. |
| **FIND-02** | GEO-24-0117 Table 2 vs Boring Logs B-7 and B-10 | **GEO Report Table 2** | Table 2 lists B-7 and B-10 as OSHA Type B; boring logs reveal granular SP/SM soils and shallow groundwater (4.0 ft and 3.0 ft), requiring OSHA Type C | Governed by boring logs and 29 CFR 1926 Subpart P App A (Type C) per IEDS 1.3 / 4.12. |
| **FIND-03** | Government Estimate Template vs UFS 3-701-01 | **Gov Estimate Line 2** | Template applies Area Cost Factor of 1.16; UFS 3-701-01 4-1.1 strictly prohibits applying ACFs to locally priced bottom-up estimates | Set applied Area Cost Factor to 1.0 per UFS 3-701-01 4-1.1 and RFP 3.1. |
| **FIND-04** | C-101 Utility Note vs SUE-24-0117 Survey | **Water Main W-12** | C-101 indicates W-12 top of pipe at approx 72 in; SUE QL-A test holes TH-1 and TH-2 measured actual depth at 56 in (16 in shallower) | Governed by SUE-24-0117 field measurements (56 in) per IEDS 1.3 and C-101 Note 2. |
| **FIND-05** | C-101 Drawing vs TS-24-0117 Tree Survey | **Retained Tree T-208** | C-101 omits retained tree T-208 (14" Jacaranda, TPZ radius 14 ft at (170, 395)); direct route from SS-1 south stub-out would encroach TPZ | Governed by arborist survey TS-24-0117 per IEDS 1.3 and Note 2A; routed C06 underground ductbank east of TPZ at x=195. |
| **FIND-06** | TD-15AL-133 Catalogue vs SUB-33 71 02-07 Submittal | **Cable Pulling Limits** | Catalogue states max SWBP as 1,000 lb/ft; approved project submittal letter restricts tape-shielded construction to 600 lb/ft | Governed by approved submittal SUB-33 71 02-07 (600 lb/ft) per IEDS 1.3 order of precedence. |
| **FIND-07** | Attachment J-3 vs 29 CFR 1.6(c)(2)(ii)(A) | **Wage Determination** | Attachment J-3 included superseded WD CA20260022 Mod 2; Mod 5 was published on 2026-08-06 (>10 days before bid opening 2026-10-08) | Applied Mod 5 as legally effective wage determination per 29 CFR 1.6(c)(2)(ii)(A). |

---
## 8. PROFESSIONAL ENGINEERING QA/QC CERTIFICATION
I hereby certify that this Conveyance Study for Solicitation FA4610-26-R-0031 has been prepared in accordance with recognized professional engineering standards, the 5 Core Engineering Verification Principles, and the governing criteria of the Department of Defense and Department of the Air Force.

All quantities, labor units, equipment hours, and material takeoffs have been computed deterministically. The recommended conveyance selections represent the most cost-effective technical solutions compliant with base security, mission redundancy, electrical safety, and constructability requirements.

**Submitted By:**
*Lead Electrical Engineer & Chief Cost Estimator*  
Design-Build Team | Pacific Crest Space Force Annex Distribution Modernization  
Seal / Signature: `[RECORD SIGN-OFF - 2026-09-15]`
