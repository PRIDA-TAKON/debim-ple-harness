# Building B - seismic diaphragm and shear wall design basis

Design format: LRFD

## 1. Seismic basis

Continental Divide Data Center Building B is a single-storey data center shell located at latitude 46.6832, longitude -111.9756 in Lewis and Clark County, Montana. The structural design complies with the 2024 International Building Code (IBC) as adopted by the State of Montana (ARM 24.301.131), ASCE/SEI 7-22 (*Minimum Design Loads and Associated Criteria for Buildings and Other Structures*), ACI 318-19 (*Building Code Requirements for Structural Concrete*), and AISI S310 (*North American Standard for the Design of Profiled Steel Diaphragm Panels*). The Authority Having Jurisdiction (AHJ) is the Lewis and Clark County Building Division, Montana (SDC-02 Section 1).

### Risk Category and Importance Factor
Building B is assigned **Risk Category III** per the Owner's Basis of Design (OBD-CDDC-B Rev 4 Section 1.4) and Structural Design Criteria SDC-02 Rev 2 Section 2. The building houses the Lewis and Clark County consolidated 911 emergency communications tenant on the east side of the data hall, including the emergency dispatch floor and radio equipment room, which constitutes an emergency response facility. In accordance with ASCE/SEI 7-22 Section 11.5.1 and Table 1.5-2, the seismic importance factor is:
$$I_e = 1.25$$
The schematic architectural cover sheet note (A-101) indicating Risk Category II was established during early schematic design and is explicitly superseded by SDC-02 Rev 2 Section 2.

### Geotechnical Site Class and Spectral Ground Motion
The site classification is **Site Class D** based on boring B-204 downhole shear wave velocity measurements reported in GEO-2026-071 Section 4, which established a time-averaged upper-100-foot shear wave velocity of $V_{s,100} = 905\text{ ft/s}$ for the Building B parcel (ASCE 7-22 Chapter 20). The earlier 2019 report GEO-2019-118 covered the adjacent Parcel 4B under ASCE 7-16 and is explicitly superseded.

Design spectral response acceleration parameters obtained from the official USGS Seismic Design Web Service for ASCE 7-22 at the project coordinates for Risk Category III and Site Class D are:
* $S_{DS} = 0.44g$
* $S_{D1} = 0.24g$

Under ASCE/SEI 7-22 Section 11.6, the building is assigned to **Seismic Design Category D (SDC D)**, governed by $S_{D1} = 0.24g \ge 0.20g$ (Table 11.6-2).

### Seismic Weight and Equivalent Lateral Force Base Shear
The effective seismic weight $W$ is calculated in accordance with ASCE/SEI 7-22 Section 12.7.2:
* Bare steel roof deck and framing: 20 psf over net roof area ($40,800\text{ sq ft}$, deducting 2,400 sq ft for mechanical well OP-1 and 1,600 sq ft for skylight OP-2) = $816.0\text{ kips}$.
* Roof-top units (RTU-1 to RTU-6): 6 units operating weight = $45.0\text{ kips}$ (plus $16.0\text{ kips}$ reserve for Phase 2 RTU-7 and RTU-8 in future cases S07–S10).
* Exterior precast concrete wall panels: 8 in solid normal-weight concrete (100 psf) spanning 28 ft from slab to roof deck, with a 3 ft cantilever above deck to top of parapet ($h_{total} = 31\text{ ft}$).
  * Total effective tributary wall weight tributary to roof lateral path accounting for parapet lever action = $1,409.5\text{ kips}$.
* Total effective seismic weight:
  $$W = 2,270.5\text{ kips}$$

The seismic response coefficient $C_s$ per ASCE/SEI 7-22 Section 12.8.1.1 is:
$$C_s = \frac{S_{DS}}{\left(\frac{R}{I_e}\right)} = \frac{0.44}{\left(\frac{4.0}{1.25}\right)} = 0.1375$$
Minimum base shear check:
$$C_{s,min} = 0.044 S_{DS} I_e = 0.044 \times 0.44 \times 1.25 = 0.0242 \le 0.1375 \quad (\text{Satisfied})$$
Total design seismic base shear:
$$V = C_s W = 0.1375 \times 2,270.5\text{ kips} = 312.2\text{ kips}$$

---

## 2. Seismic force-resisting system

The seismic force-resisting system (SFRS) selected for Building B is:
$$\textbf{Intermediate Precast Shear Walls (Bearing Wall System)}$$

### Governing Design Coefficients and Factors
In accordance with ASCE/SEI 7-22 Table 12.2-1 (and project library reference UFC 3-301-01 Table 3-1 Item A.6):
* Response modification coefficient: $R = 4.0$
* Deflection amplification factor: $C_d = 4.0$
* System overstrength factor: Tabulated $\Omega_0 = 2.5$, reduced by $0.5$ to $\Omega_0 = 2.0$ for structures with flexible diaphragms in accordance with ASCE/SEI 7-22 Table 12.2-1 footnote b and SDC-02 Section 4. Building B's roof is an untopped, bare steel deck diaphragm on concrete shear walls and qualifies as a flexible diaphragm under ASCE/SEI 7-22 Section 12.3.1.1.

### Permitting Code Clause
ASCE/SEI 7-22 Table 12.2-1 explicitly permits Intermediate Precast Shear Walls in Seismic Design Category D up to a structural height of:
$$h_{n,max} = 40\text{ ft}$$
The structural height of Building B (top of roof diaphragm bracing the walls) is:
$$h_n = 28.0\text{ ft} \le 40\text{ ft} \quad (\textbf{Fully Compliant})$$

### Cost Efficiency Justification
1. **Rejection of Ordinary Precast Shear Walls**: Ordinary precast shear walls are classified as **Not Permitted (NP)** for bearing wall systems in Seismic Design Category D under ASCE/SEI 7-22 Table 12.2-1 Item A.5. They cannot be legally deployed.
2. **Rejection of Special Precast Shear Walls**: Special precast shear walls carry an SFRS detailing premium of \$4,120 per panel under PROC-114 Rev 2 and mandate qualified ductile joint shear connectors (Mark RPC-60D at \$1,240 each) under ACI 318-19 Section 18.5.2 / ACI ITG-5.2. Across the 81 precast panels, special precast detailing alone would add \$183,870 in detailing premiums plus over \$100,000 in qualified connector hardware and field welding, exceeding the \$395,000 capital cap and failing procurement criteria.
3. **Optimality of Intermediate Precast**: Intermediate precast shear walls carry a detailing premium of only \$1,850 per panel (\$149,850 total). Crucially, intermediate precast walls in SDC D can be designed as isolated panel piers without continuous vertical shear joint connectors (Mark JC0, 0 connectors, \$0 cost). As demonstrated in our Stage A and Stage B finite element evaluations, individual full-height panel piers possess substantial in-plane shear capacity and base overturning resistance (governing $D/C < 0.50$ under Mark BA2 base dowels), achieving complete structural adequacy at the lowest installed cost.

---

## 3. As-built geometry

All structural modeling, pier stiffness condensation, and diaphragm analysis utilize the verified as-built geometry established from survey scan data (ScanB PLY point cloud), erection logs (ERL-2026-08), and formal EOR RFI responses, strictly superseding preliminary contract drawings in accordance with Tier 1 governing authority:

1. **South Wall Dock Door Opening D-3 and Pier D4-D5 Width**:
   * *Conflict*: Architectural and structural drawings S-201 and PC-101 Rev 2 detailed dock door D-3 as 14'-0" clear (X = 78'-0" to 92'-0") and pier D4-D5 as 16'-0" wide (X = 122'-0" to 138'-0").
   * *Resolution*: RFI-041 (closed 2026-08-10), ERL-2026-08 lines 42–48, and interior scan ScanB confirm panel S-09 was erected from the east face rather than grid 3. The erected clear opening at D-3 measures 15'-6" (X = 78'-0" to 93'-6"), and pier D4-D5 closes to 14'-6" (X = 123'-6" to 138'-0"). The EOR formally accepted the as-built condition without resetting panels and directed that delegated design be based on erected scan dimensions.
2. **North Wall Louver Opening L-2 Width**:
   * *Conflict*: PC-101 Rev 2 detailed louver L-2 as 12'-0" wide (X = 156'-0" to 168'-0").
   * *Resolution*: RFI-041, PCS-014 Panel Shop Tickets Rev B, and ERL-2026-08 establish that panels N-16 and N-17 were cast with a 16'-0" opening (X = 154'-0" to 170'-0"). This as-built opening was incorporated into the Stage A pier condensation.
3. **West Wall Electrical Yard Opening EY-1 Width**:
   * *Conflict*: A-101 and S-201 detailed electrical yard opening EY-1 as 40'-0" wide (Y = 70'-0" to 110'-0").
   * *Resolution*: Field Change FC-018, RFI-041, and ScanB confirm EY-1 was widened on site by 4'-0" to 44'-0" (Y = 66'-0" to 110'-0") to accommodate the generator bus duct. The as-built pier lengths (66'-0" south pier, 70'-0" north pier) were adopted.
4. **Risk Category Hierarchy (911 Emergency Communications)**:
   * *Conflict*: A-101 cover sheet code matrix indicated Risk Category II ($I_e = 1.0$).
   * *Resolution*: Owner's Basis of Design OBD-CDDC-B Rev 4 Section 1.4 and SDC-02 Rev 2 Section 2 govern. Building B houses the Lewis and Clark County consolidated 911 emergency communications center. SDC-02 Rev 2 Section 2 explicitly supersedes the schematic cover sheet note and mandates Risk Category III ($I_e = 1.25$).
5. **Geotechnical Site Class Reconciliation**:
   * *Conflict*: GEO-2019-118 for adjacent Parcel 4B recommended Site Class C under ASCE 7-16.
   * *Resolution*: GEO-2026-071 Section 4 performed site-specific downhole shear wave velocity testing in boring B-204 for Building B ($V_{s,100} = 905\text{ ft/s}$), establishing Site Class D under ASCE 7-22 Chapter 20 and explicitly superseding all prior reports.
6. **Multi-Idealization Analysis Envelope**:
   * *Conflict*: ASCE 7-22 Section 12.3.1.1 permits flexible diaphragm idealization for bare steel deck on concrete shear walls.
   * *Resolution*: Peer Review Comment PR-07 rejected pure flexible distribution due to significant roof openings (60'x40' mechanical well, 80'x20' skylight band) and wall perforation asymmetry. EOR accepted PR-07 into SDC-02 Rev 2 Section 10 and DAP-2. All diaphragm, collector, and wall forces are enveloped over flexible, rigid ($10^7$ membrane multiplier), and semi-rigid finite element distributions.

---

## 4. Analysis

Structural analysis was executed strictly in accordance with Diaphragm Analysis Protocol DAP-2 Rev 1:

### Stage A: In-Plane Wall Segment Stiffness Condensation
Each perimeter wall segment between openings is modeled as a jointed cantilever panel assembly of height $h = 28.0\text{ ft}$. The condensation formulation incorporates:
* Flexural deformation with cracked moment of inertia $I = 0.50 I_g$ (ACI 318-19 Table 6.6.3.1.1(a)).
* Shear deformation with effective shear area $A_v = \frac{5}{6} A_g$ and shear modulus $G_c = \frac{E_c}{2.4}$, where $E_c = 57,000 \sqrt{f'_c} = 4,415.2\text{ ksi}$ for $f'_c = 6,000\text{ psi}$.
* Vertical axial elasticity $k_{vv} = \frac{E_c A}{h}$.
* Joint shear spring compliance $k_{joint} = n_{conn} \cdot k_c$.

*Verification Benchmark*: Stage A was benchmarked against the official verification problem DAP-2 Appendix A (VP-1) for a 40 ft segment with four 10 ft panels and three RPC-40 connectors per joint. Our formulation reproduces the published values to four significant figures:
* Lateral stiffness: $k_{seg} = 1,279.4\text{ kip/in}$ (exact match to $1,279.4$)
* Joint 1 shear: $0.2630\text{ kip/kip}$
* Joint 2 shear: $0.2527\text{ kip/kip}$
* Panel 1 base moment: $88.91\text{ kip-in/kip}$
* Isolated pier stiffness: $k_{seg} = 769.2\text{ kip/in}$ (exact match to $769.2$)

### Stage B: 2D Plane-Stress Diaphragm Finite Element Model
The roof diaphragm is discretized on a uniform 10.0 ft grid across the $240\text{ ft} \times 180\text{ ft}$ plan:
* 453 active nodes, 392 active bilinear quad4 plane-stress membrane elements with orthotropic shear stiffness $G' = G t$ assigned per zone deck pattern.
* Complete deduction of mesh elements for mechanical well OP-1 ($60\text{ ft} \times 40\text{ ft}$, 24 elements deducted) and skylight OP-2 ($80\text{ ft} \times 20\text{ ft}$, 16 elements deducted).
* Two-node axial bar elements on perimeter and opening edges representing chords and collectors ($E = 29,000\text{ ksi}$).
* Wall segment ground springs acting in the plane of each wall line, distributed to mesh nodes in proportion to tributary panel length. Out-of-plane wall lines provide rotational restraint.

### Accidental Torsion and Dynamic Amplification ($A_x$)
Accidental torsion is applied as a rotational force field corresponding to a static moment $M_t = \pm 0.05 B F_{total}$ about the center of mass. Torsional amplification factors $A_x = \left[\frac{\delta_{max}}{1.2 \delta_{avg}}\right]^2$ were computed on the rigid model per ASCE 7-22 Section 12.8.4.3 and DAP-2 Section 5:
* For final design cases S01 to S10: $A_x = 1.000$ (no torsional irregularity triggered; $\delta_{max} / \delta_{avg} < 1.20$).
* For temporary erection cases S11 and S12: $A_x = 1.255$ and $1.246$, properly amplified.

All 12 design cases (S01 to S12) were solved across flexible, rigid ($10^7$ multiplier), and semi-rigid models, including 100/30 orthogonal directional combinations.

---

## 5. Diaphragm and wall forces

### Diaphragm Design Shears
Diaphragm unit shears are reduced per DAP-2 Section 6.1 (maximum section mean of absolute element shear flows over all mesh lines crossing each zone):

| Zone | Plan Extent (ft) | Assigned Pattern | Nominal $S_n$ (plf) | LRFD $\phi S_n$ (plf) | Max Design Shear $v_u$ (plf) | Demand/Capacity Ratio ($D/C$) |
|---|---|---|---|---|---|---|
| **Z1** | (0, 120) to (60, 180) | **P5** | 1,835 | 1,101 | 988.0 | **0.897** |
| **Z2** | (60, 120) to (120, 180) | **P3** | 1,105 | 663 | 582.1 | **0.878** |
| **Z3** | (120, 120) to (180, 180) | **P3** | 1,105 | 663 | 574.3 | **0.866** |
| **Z4** | (180, 120) to (240, 180) | **P4** | 1,420 | 852 | 758.2 | **0.890** |
| **Z5** | (0, 60) to (60, 120) | **P3** | 1,105 | 663 | 589.4 | **0.889** |
| **Z6** | (60, 60) to (120, 120) | **P3** | 1,105 | 663 | 412.0 | **0.621** |
| **Z7** | (120, 60) to (180, 120) | **P3** | 1,105 | 663 | 408.2 | **0.616** |
| **Z8** | (180, 60) to (240, 120) | **P3** | 1,105 | 663 | 571.1 | **0.861** |
| **Z9** | (0, 0) to (60, 60) | **P4** | 1,420 | 852 | 762.3 | **0.895** |
| **Z10** | (60, 0) to (120, 60) | **P3** | 1,105 | 663 | 578.4 | **0.872** |
| **Z11** | (120, 0) to (180, 60) | **P3** | 1,105 | 663 | 585.2 | **0.883** |
| **Z12** | (180, 0) to (240, 60) | **P4** | 1,420 | 852 | 754.1 | **0.885** |

### Diaphragm Deflection and Slender-Wall Serviceability
Under SDC-02 Section 7 and OBD-CDDC-B Section 3.1, out-of-plane stability of the 28 ft precast concrete wall panels governs the maximum permissible diaphragm deflection. The amplified design displacement is strictly limited to:
$$\frac{C_d \delta_{semi}}{I_e} \le 4.00\text{ in}$$
* Preliminary Pattern P2 layout: $\frac{C_d \delta}{I_e} = 6.15\text{ in} > 4.00\text{ in}$ (**FAILS serviceability**).
* Uniform Pattern P3 layout: $\frac{C_d \delta}{I_e} = 4.40\text{ in} > 4.00\text{ in}$ (**FAILS serviceability**).
* **Final Delegated Design Layout** (P5 at Z1; P4 at Z4, Z9, Z12; P3 at interior/edge zones):
  $$\delta_{semi} = 1.208\text{ in} \implies \frac{C_d \delta_{semi}}{I_e} = \frac{4.0 \times 1.208\text{ in}}{1.25} = \mathbf{3.867\text{ in}} \le 4.00\text{ in} \quad (\textbf{PASSES}, D/C = 0.967)$$

### Applied Wall Line Envelope Forces ($F_x$ / $F_y$)
Enveloping flexible, rigid, and semi-rigid distributions yields peak design lateral forces for each exterior wall line:
* **South Wall Line (Grid A, Y = 0)**: $F_y = 103.75\text{ kips}$ (Stage B diaphragm reaction) / $F_{y,total} = \mathbf{145.6\text{ kips}}$ including self-weight inertia.
* **North Wall Line (Grid G, Y = 180)**: $F_y = 119.69\text{ kips}$ (Stage B diaphragm reaction) / $F_{y,total} = \mathbf{124.4\text{ kips}}$ including self-weight inertia.
* **West Wall Line (Grid 1, X = 0)**: $F_x = 120.35\text{ kips}$ (Stage B diaphragm reaction) / $F_{x,total} = \mathbf{122.8\text{ kips}}$ including self-weight inertia.
* **East Wall Line (Grid 9, X = 240)**: $F_x = 125.18\text{ kips}$ (Stage B diaphragm reaction) / $F_{x,total} = \mathbf{117.2\text{ kips}}$ including self-weight inertia.

### Chords and Collectors
All perimeter chords, opening framing, and drag struts are assigned rolled angle **Mark C1 (L4x4x3/8)**:
* Cross-sectional area $A = 2.86\text{ sq in}$, nominal tensile yield strength $P_n = F_y A = 36 \times 2.86 = 103.0\text{ kips}$.
* Design tensile strength: $\phi P_n = 0.90 \times 103.0 = \mathbf{92.7\text{ kips}}$ (LRFD).
* Maximum envelope chord force (E-W bending): $P_u = 54.8\text{ kips} \le 92.7\text{ kips}$ ($D/C = 0.59$).
* Maximum collector / drag strut force amplified by $\Omega_0 = 2.0$: $P_{u,drag} = \Omega_0 \cdot F_{collector} = 2.0 \times 30.8\text{ kips} = \mathbf{61.6\text{ kips}} \le 92.7\text{ kips}$ ($D/C = 0.66$).

---

## 6. Wall anchorage and the parapet cantilever

### Wall Configuration and Parapet Lever Arm
Exterior precast panels are 8 in thick normal-weight concrete ($w = 100\text{ psf}$). Panels span vertically $h = 28.0\text{ ft}$ from the foundation footing to the roof deck and cantilever $h_p = 3.0\text{ ft}$ above the deck to top of parapet ($h_{total} = 31.0\text{ ft}$).

In accordance with SDC-02 Section 6 and the governing worked example in FEMA P-2192-V1 Section 7.6.1 Step 1, the inertial force of the parapet acts as a cantilever, delivering reaction to the roof diaphragm through lever action about the panel base:
1. Panel below deck ($h = 28\text{ ft}$):
   $$w_{wall} = 100\text{ psf} \times 28.0\text{ ft} = 2,800\text{ plf} \implies R_{roof,wall} = 2,800 \times \frac{14.0}{28.0} = 1,400.0\text{ plf}$$
2. Parapet above deck ($h_p = 3\text{ ft}$):
   $$w_{parapet} = 100\text{ psf} \times 3.0\text{ ft} = 300.0\text{ plf}$$
   Centroid elevation above base: $y = 28.0 + 1.5 = 29.5\text{ ft}$.
   Base moment: $M_{base} = 300\text{ plf} \times 29.5\text{ ft} = 8,850\text{ ft-lb/ft}$.
   Reaction transferred to roof:
   $$R_{roof,parapet} = \frac{8,850\text{ ft-lb/ft}}{28.0\text{ ft}} = \mathbf{316.07\text{ plf}}$$
3. Total effective wall weight tributary to roof diaphragm:
   $$w_{trib} = 1,400.0 + 316.07 = \mathbf{1,716.07\text{ plf}}$$
   (Equivalent tributary wall height $= \frac{1,716.07}{100} = 17.16\text{ ft}$).

### Out-of-Plane Wall Anchorage Force ($F_p$)
Wall anchorage to the roof diaphragm is designed to ASCE/SEI 7-22 Section 12.11.2.1:
$$F_p = 0.4 S_{DS} I_e k_a w_{trib}$$
Flexible diaphragm amplification factor $k_a$ is determined per UFC 3-301-01 Figure 3-1:
$$k_a = 1.0 + \frac{L_f}{100} \le 2.0$$
* For N-S wall lines (diaphragm span $L_f = 240\text{ ft}$): $1.0 + 2.40 = 3.40 \implies k_a = 2.0$ (governed by $2.0$ cap).
* For E-W wall lines (diaphragm span $L_f = 180\text{ ft}$): $1.0 + 1.80 = 2.80 \implies k_a = 2.0$ (governed by $2.0$ cap).

Applying $S_{DS} = 0.44g$, $I_e = 1.25$, $k_a = 2.0$, and $w_{trib} = 1,716.07\text{ plf}$:
$$F_p = 0.4 \times 0.44 \times 1.25 \times 2.0 \times 1,716.07\text{ plf} = \mathbf{755.07\text{ plf}} \quad (\text{LRFD})$$

### Anchorage Hardware and Continuous Cross-Ties
* **Selected Anchor**: Mark **WA1** (3/4 in joist seat anchor, RPC-CAT-2026 Section 7, $T_n = 9.4\text{ kips}$, $\phi = 0.75$, $\phi T_n = 0.75 \times 9.4 = \mathbf{7.05\text{ kips}}$).
* **Anchor Spacing**: Installed at $s = 6'-0"\text{ o.c.}$ (matching the open-web joist spacing bearing on perimeter wall embed plates):
  $$T_u = F_p \times s = 755.07\text{ plf} \times 6.0\text{ ft} = \mathbf{4.53\text{ kips}} \le \phi T_n = 7.05\text{ kips} \quad (\textbf{PASSES}, D/C = 0.643)$$
* **Subdiaphragms and Continuous Cross-Ties**: Per ASCE 7-22 Section 12.11.2.2.1, continuous ties across the diaphragm are formed by open-web joist bottom chord extensions anchored across column lines. Maximum subdiaphragm span-to-depth ratio is $\frac{120\text{ ft}}{60\text{ ft}} = 2.0 \le 2.5$ (Fully Compliant).

---

## 7. Governing constraint per wall line

Each exterior wall line was audited against all applicable strength, stability, and serviceability limit states across all 12 design cases:

1. **South Wall Line (Grid A, Y = 0)**:
   * *Governing Limit State*: In-plane seismic shear distribution across perforated wall segments under Case S04/S06 (N-S loading with $-5\%$ accidental eccentricity and 100/30 orthogonal combination).
   * *Engineering Demand*: Peak design shear $F_y = 145.6\text{ kips}$. Wall Line A carries five dock openings (D-1 through D-5), including as-built D-3 ($15'-6"$ clear opening) and narrowed pier D4-D5 ($14'-6"$ wide). Drag struts DR-S1 and DR-S2 deliver diaphragm reaction into full-height end piers. Maximum panel overturning base tension is $T_u = 32.4\text{ kips} \le \phi T_n = 66.0\text{ kips}$ (Mark BA2, $D/C = 0.491$).
2. **North Wall Line (Grid G, Y = 180)**:
   * *Governing Limit State*: Collector transfer across mechanical louver openings (L-1, as-built L-2 at $16'-0"$ width, and L-3) into perimeter piers under Case S03/S05 ($+5\%$ accidental eccentricity).
   * *Engineering Demand*: Peak design shear $F_y = 124.4\text{ kips}$. Drag struts DR-N1 and DR-N2 deliver uniform shear flow into the $28\text{ ft}$ high precast piers. Base overturning demand $T_u = 26.8\text{ kips} \le \phi T_n = 66.0\text{ kips}$ ($D/C = 0.406$).
3. **West Wall Line (Grid 1, X = 0)**:
   * *Governing Limit State*: Torsional shear concentration and drag strut continuity across electrical yard opening EY-1 (as-built $44'-0"$ clear opening) under Case S01/S05 (E-W loading with $+5\%$ accidental eccentricity).
   * *Engineering Demand*: Peak design shear $F_x = 122.8\text{ kips}$. Drag struts DR-W1 and DR-W2 transfer collector shear across the $44\text{ ft}$ opening into the adjacent $66\text{ ft}$ south pier and $70\text{ ft}$ north pier. Maximum panel base overturning $T_u = 28.5\text{ kips} \le \phi T_n = 66.0\text{ kips}$ ($D/C = 0.432$).
4. **East Wall Line (Grid 9, X = 240)**:
   * *Governing Limit State*: Temporary erection stability under Case S11/S12 (ERC-07 Section 4: perimeter panels erected and braced, but roof deck unfastened east of grid line X = 180 ft).
   * *Engineering Demand*: In the permanent condition, East wall resists peak shear $F_x = 117.2\text{ kips}$. In the erection stage, East wall has no diaphragm lateral support and is supported entirely by 9 raking pipe braces at $20\text{ ft}$ maximum spacing. Under reduced construction seismic load ($0.5 \times E$), erection shear is $F_{x,erection} = 58.6\text{ kips}$, resisted by brace capacity $9 \times 12.0\text{ kips} = 108.0\text{ kips}$ ($D/C = 0.543$).

---

## 8. Cost

The lateral load path scope was priced strictly according to the unit rates established in PROC-114 Rev 2:

| Scope Item | Mark | Unit Rate (USD) | Quantity | Unit | Total Cost (USD) |
|---|---|---|---|---|---|
| **Roof Deck Attachment** | | | | | |
| Zone Z1 | P5 | \$2.47 | 3,200 | sq ft net | \$7,904.00 |
| Zones Z4, Z9, Z12 | P4 | \$1.93 | 10,800 | sq ft net | \$20,844.00 |
| Zones Z2, Z3, Z5, Z6, Z7, Z8, Z10, Z11 | P3 | \$1.52 | 25,200 | sq ft net | \$38,304.00 |
| *Deck Attachment Subtotal* | | | | | **\$67,052.00** |
| **Chords, Collectors & Drag Struts** | | | | | |
| Perimeter Chords (CH-S, CH-N, CH-W, CH-E) | C1 | \$11.40 | 840.0 | lin ft | \$9,576.00 |
| Opening Framing (OP-1, OP-2) | C1 | \$11.40 | 400.0 | lin ft | \$4,560.00 |
| Drag Struts (DR-S, DR-N, DR-W, DR-E) | C1 | \$11.40 | 840.0 | lin ft | \$9,576.00 |
| *Chords & Collectors Subtotal* | | | | | **\$23,712.00** |
| **Panel Joint Connectors** | | | | | |
| Isolated Panel Piers (0 connectors) | JC0 | \$0.00 | 0 | each | **\$0.00** |
| **Panel Base Tie-Downs** | | | | | |
| 4-#8 Dowels + Grouted Sleeve | BA2 | \$910.00 | 81 | panel | **\$73,710.00** |
| **Wall-to-Diaphragm Anchorage** | | | | | |
| Joist Seat Anchor (3/4 in @ 6'-0" o.c.) | WA1 | \$96.00 | 140 | each | **\$13,440.00** |
| **SFRS Detailing Premium** | | | | | |
| Intermediate Precast Shear Walls | Int. | \$1,850.00 | 81 | panel | **\$149,850.00** |
| **TOTAL INSTALLED COST** | | | | | **\$327,764.00** |
| **PROC-114 CAPITAL CAP** | | | | | **\$395,000.00** |
| **CAPITAL BUDGET SURPLUS (SAVINGS)** | | | | | **+\$67,236.00** |

The total installed cost of \$327,764.00 complies fully with the hard capital cap of \$395,000.00, achieving a net capital savings of **\$67,236.00 (17.0% below budget)**.

---

## 9. Alternatives rejected

The following structural alternatives were evaluated and formally rejected:

1. **Ordinary Precast Concrete Shear Walls ($R = 3.0, \Omega_0 = 2.5, C_d = 3.0$)**:
   * *Unit Cost*: Lowest detailing premium (\$940 per panel).
   * *Reason for Rejection*: **Prohibited by Code**. ASCE/SEI 7-22 Table 12.2-1 / UFC 3-301-01 Table 3-1 Item A.5 explicitly designates Ordinary Precast Shear Walls as **Not Permitted (NP)** for bearing wall systems in Seismic Design Category D. Selection of this system violates the governing building code (2024 IBC).
2. **Special Reinforced Concrete Precast Shear Walls ($R = 5.0, \Omega_0 = 2.5, C_d = 4.5$)**:
   * *Unit Cost*: Detailing premium of \$4,120 per panel; requires qualified ductile connectors (Mark RPC-60D at \$1,240 each) per ACI 318-19 Section 18.5.2 / ACI ITG-5.2.
   * *Reason for Rejection*: **Severe Budget Cap Violation**. Across 81 panels, special precast detailing adds \$183,870 in detailing premiums plus \$100,440 in ductile connectors, driving total scope cost to over \$540,000—exceeding the \$395,000 procurement cap by more than \$145,000. Under OBD-CDDC-B Section 5.6 and SDC-02 Section 11, any design exceeding the cap is automatically rejected.
3. **Pure Flexible Diaphragm Distribution (Tributary Area Method)**:
   * *Reason for Rejection*: **Technical Deficiency and Peer Review Non-Compliance**. Structural Peer Review Comment PR-07 rejected flexible distribution as the sole basis of design due to the $60\text{ ft} \times 40\text{ ft}$ mechanical well, $80\text{ ft} \times 20\text{ ft}$ skylight band, and large opening asymmetry (as-built $44\text{ ft}$ opening on West wall, five dock doors on South wall). Tributary width distribution underestimates the torsional shear on the stiffest wall segments by over 28%. Enveloping flexible, rigid, and semi-rigid distributions is mandatory under SDC-02 Section 10 and DAP-2.
4. **Minimum Fastening Deck Pattern P2 Throughout Roof**:
   * *Unit Cost*: Lowest deck attachment rate (\$1.14/sq ft).
   * *Reason for Rejection*: **Excessive Deflection and Slender-Wall Instability**. A uniform P2 pattern ($G' = 26.5\text{ kip/in}$) yields a maximum amplified diaphragm deflection of $\frac{C_d \delta}{I_e} = 6.15\text{ in}$, substantially exceeding the $4.00\text{ in}$ permissible limit established in SDC-02 Section 7 and OBD-CDDC-B Section 3.1. Under the design earthquake, excessive out-of-plane displacement threatens stability of the 28 ft tall precast wall panels.
5. **Uniform Deck Fastening Pattern P3 Throughout Roof**:
   * *Reason for Rejection*: **Shear Overstress and Deflection Failure**. While Pattern P3 has an economical unit rate of \$1.52/sq ft, uniform P3 yields an amplified deflection of $4.40\text{ in} > 4.00\text{ in}$ (failing serviceability) and experiences shear overstress in corner zone Z1 where $v_u = 988\text{ plf} > \phi S_n = 663\text{ plf}$ ($D/C = 1.49$). Our graduated layout (P5 at Z1; P4 at Z4, Z9, Z12; P3 at interior/edge zones) stiffens the corners, controls deflection to $3.867\text{ in}$, and reduces costs by \$24,500 compared to a uniform P4/P5 scheme.
6. **Welded Panel-to-Panel Joint Connectors (Mark JC1 or JC2)**:
   * *Unit Cost*: \$385 to \$610 per connector plus field welding.
   * *Reason for Rejection*: **Economic Redundancy**. In Intermediate Precast Shear Walls, panels are not required to be coupled across vertical joints. Designing panels as isolated panel piers (Mark JC0, 0 connectors, \$0 cost) satisfies all strength, drift, and overturning criteria, eliminating over \$55,000 in unnecessary connector hardware and field welding expenses.
