# Construction Method Statement: 3-Lift RC Frame Extension Over Occupied Ground Floor

**Document ID:** TWP-09-MS-REV-C  
**Author:** Qualified Construction Engineer & Temporary Works Designer, PE  
**Governing Standard:** TWP-09 Revision C & Adopted OSHA 29 CFR 1926 Standards  
**Target Completion:** Day 204 (Contract Deadline: Day 250)

---

## 1. Document Precedence and Hierarchy of Truth

Where conflicts exist within the project documents, the following strict hierarchy of governing authority applies:

1. **Governing Site Procedure:** `TWP-09 Revision C` (Temporary Works Procedure, Revision C) governs over `TWP-09 Revision B (SUPERSEDED)`. Revision B is marked superseded and is not in force. All parameters, thresholds, and operational limits are taken strictly from Revision C and its associated parameter schedule.
2. **Construction Programme:** The issued `activity_list.csv` and `zone_work_schedule.csv` govern over the preliminary `SUPERSEDED_baseline_programme_revA.csv`. All activity durations, crane hour allocations, and logical dependencies match the issued contract set exactly.
3. **Scope Demarcation:** The method package covers exclusively the 3-lift reinforced concrete frame extension (Levels 2, 3, and 4) over the existing building footprint. The method statement `MS-14_facade_replacement_OTHER_SCOPE.md` is expressly designated as non-applicable external scope and forms no part of this temporary works package or its constraint register.
4. **Design Takeoff:** Specific schedules extracted from the engineering model (`model/storey_schedule.csv`, `model/zone_schedule.csv`, `model/column_schedule.csv`, and `model/slab_schedule.csv`) supersede general overview architectural views.

---

## 2. Concrete Striking and Reshoring Engineering Protocol

In accordance with TWP-09 Clause 6.3 and 29 CFR 1926.703(e)(1)(i), an engineered early-strike and reshoring methodology is implemented to achieve continuous site operations while strictly maintaining structural safety and yard stock limits.

- **Early-Striking Thresholds:** Slabs are struck at the concrete mix's early-strike age stipulated in `catalogue/concrete_mix_schedule.csv`:
  - **M40-PUMP Mix (Bands A through D):** Early-strike age is achieved at **7 days** following pour completion.
  - **M50-HE High-Early Mix (Bands E through G):** Early-strike age is achieved at **4 days** following pour completion.
- **Reshoring Installation (`29 CFR 1926.703(b)(10)`):** Original falsework and SP-16 shores are struck only under the condition that reshoring is erected concurrently as the original shores are stripped. Reshores consist of heavy-duty `RS-16` screw-jack posts installed on an **8.0 ft by 8.0 ft** orthogonal grid (64.0 sq ft tributary area per post), per TWP-09 Clause 6.4.
- **Full-Strength Curing Age (`29 CFR 1926.703(e)(2)`):** Reshore posts remain undisturbed beneath the slab until the concrete reaches its certified 28-day full compressive design strength (`POUR.finish_day + 28`).
- **Yard Inventory Optimization:** While actively shored, each zone occupies 100% of its soffit area in the temporary works compound. Upon early strike and installation of reshores, yard stock occupancy drops to **25%** of the zone area (TWP-09 Clause 8.3). This protocol prevents exceeding the site yard limit of 3,600 sq ft of soffit formwork while enabling multi-zone concurrent progress.

---

## 3. Governing Technical Constraints by Zone Breakdown

Each zone-lift on site is governed by specific physical, environmental, or operational constraints that dictate its temporary works configuration and sequencing:

- **Bands A through C (Level 2) — Occupied Building Footprint:**  
  The ground floor space beneath Bands A, B, and C remains in active, continuous public and commercial occupation throughout construction (`site/existing_occupation.csv`). Per TWP-09 Clauses 5.4 and 6.1, falsework must support an overhead protective catch deck rated at **15.0 psf**, raising the shoring design load to **387.6 psf** (312.6 psf self-weight + 10 psf forms + 50 psf pump live load + 15 psf deck). Access scaffolding serving these zones is classified as **medium duty** (1,000 lb/bay maximum intended load), requiring 3 `PL-95` planks per bay.
- **Stair Core Zones (`Z-A-N`, `Z-B-S`, `Z-E-S`) — Means of Egress Maintenance:**  
  In compliance with 29 CFR 1926.34(a)/(c) and TWP-09 Clause 7.3, two independent, unobstructed means of emergency egress must remain fully operational at all times on every level. To prevent simultaneous blockage of stairwells, no more than **one** stair core zone may be shored across the entire building on any given working day. Shoring intervals for stair cores are strictly sequenced in series.
- **Bands E through G (Levels 2, 3, and 4) — Crane-and-Bucket Placement & Heavy Duty Edge:**  
  Due to mobile concrete pump reach limits from the west haul road, concrete for Bands E, F, and G must be placed via tower crane and concrete bucket landing at the exterior slab edge (TWP-09 Clause 5.3). This operational requirement mandates a construction live load of **75.0 psf** (total shoring load **397.6 psf**) and **heavy duty** perimeter scaffolding (1,750 lb/bay maximum intended load). Scaffolding uses the `SF-5` system (5.0 ft base width) fully decked with 5 `PL-95` planks per bay, providing 7,500 lb capacity per bay.
- **Band D (and Upper Levels of Bands A-C) — Pump Placement:**  
  Poured using pump lines (50 psf live load; 372.6 psf design load). Scaffolds are classified as **light duty** (750 lb/bay maximum intended load), fitted with 2 `PL-95` planks per bay (3,000 lb capacity).

---

## 4. Engineering Safety Margins and Verification Summary

All calculated engineering parameters maintain rigorous safety factors exceeding governing statutory and site criteria:

- **Shore Post Capacity Margin:** All falsework utilizes `SP-16` steel shores (rated capacity 6,000 lb, maximum extension 16.0 ft). At a 3.5 ft orthogonal grid, the maximum design load per post is 4,870.6 lb (Bands E-G), 4,748.1 lb (L2 Bands A-C), and 4,564.4 lb (Bands A-D). This provides a minimum capacity reserve margin of **23.2% to 31.4%** above design loads.
- **Scaffold Strength Factor:** In accordance with 29 CFR 1926.451(a)(1), all working platforms provide an ultimate capacity exceeding **4.0 times** the maximum intended load:
  - Light Duty: 3,000 lb ultimate plank capacity vs 4 × 750 lb demand = exactly 4.0× factor.
  - Medium Duty: 4,500 lb capacity vs 4 × 1,000 lb demand = 4.5× factor (12.5% reserve).
  - Heavy Duty: 7,500 lb capacity vs 4 × 1,750 lb demand = 4.29× factor (7.1% reserve).
- **Ground Bearing Margin:** Scaffold mudsills transmit combined dead and live loads generating a maximum ground bearing pressure of under **320 psf**, well within the allowable 2,000 psf site limit (safety factor > 6.2).
- **Scaffold Tipping Restraint & Ties:** With `SF-5` (5.0 ft base width), Level 2 scaffolds (height 18.75 ft) maintain a height-to-base ratio of 3.75, eliminating tipping risk without ties. On Level 3 (height 35.42 ft) and Level 4 (height 52.08 ft), positive ties are anchored at the closest horizontal members (19.5 ft on L3; 19.5 ft and 45.5 ft on L4) at two tie columns per zone face, complying with 29 CFR 1926.451(c)(1)(ii).
- **Lateral Stability Bracing:** Notional lateral loads (2% of vertical shoring load, up to 9,511.7 lb) govern over wind forces (12 psf, up to 1,449.6 lb). Temporary frame cross-bracing using `XB-1` units (4,000 lb ultimate capacity each) provides 8,000 lb or 12,000 lb capacity, providing a minimum **26.2%** strength margin across all zones.
- **Crane Operational Margins:** The single tower crane is positioned at central hardstand `CP-C` (x = 98.0 ft, y = 118.0 ft). CP-C is the sole standing position capable of serving all 14 zones within the 140 ft maximum working radius while satisfying heaviest pick capacities (up to 13,674 lb in Band D). Demarcated working radius is capped at 140.0 ft, maintaining a 15.0 ft clearance buffer from the northern 34.5 kV overhead distribution line, well exceeding the 10.0 ft Table A minimum approach distance required under 29 CFR 1926.1408 Option 3.
- **Site-Wide Resource Buffers:** The optimized 204-day programme complies with all site-wide envelopes:
  - Daily Crane Hours: Peak at 9.88 hours/day (Shift limit: 10.0 hours/day).
  - Active Gangs: Peak at 7 gangs (Site ceiling: 8 gangs).
  - Laydown Usage: Peak at 13 units (Laydown limit: 16 units).
  - Shoring Compound: Peak at 3,592.4 sq ft (Yard limit: 3,600.0 sq ft).
  - Scaffold Compound: Peak at 117.7 lin ft (Yard limit: 120.0 lin ft).
  - Stair Core Shoring: Strictly maximum 1 stair core shored concurrently site-wide.

---

## 5. Dataset Attribution and CC BY 4.0 Licensing

The building structural geometry, column grid and sections, storey elevations, slab thickness, and stair core layouts in this method package are derived from:

> **LivingBIM Dataset:** *As-designed and As-built Dataset for an Academic Building including BIM 3d models, Point Clouds, and Panoramic Images.*  
> **DOI:** [10.5281/zenodo.17934615](https://doi.org/10.5281/zenodo.17934615)  
> **License:** Creative Commons Attribution 4.0 International (**CC BY 4.0**).  
> In compliance with CC BY 4.0 conditions, appropriate credit is given to the original dataset authors, and all derived temporary works and constructability schedules maintain full transparency and attribution.
