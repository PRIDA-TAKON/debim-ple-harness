# DC-2 Helena Data Centre - Building A: Roof Deck Design Basis

**Document:** DB-DC2-RD-001  
**Project:** DC2-2026-014 - DC-2 Helena Data Centre - Building A  
**Location:** Lewis and Clark County, Montana (Canyon Ferry Road site, Elev. 4,880 ft)  
**Structural Engineer of Record:** Sandalwood Marlow Structural Engineers, PLLC  
**Discipline:** Structural Engineering / Cold-Formed Steel Diaphragm Design  
**Date:** August 2026  

---

## 1. Executive Summary

This design basis report documents the comprehensive quality assurance and quality control (QA/QC) audit, structural analysis, and final engineering specification for the steel roof deck of Building A at the DC-2 Helena Data Centre in Lewis and Clark County, Montana. 

The building is a single-storey data centre with an overall plan footprint of 240 ft-0 in (along project grids 1 through 9) by 180 ft-0 in (along project grids A through G). The primary roof gravity framing is established and fixed: 26K9 open-web steel joists spaced at 6 ft-0 in on centre, spanning 30 ft-0 in north-south between 36G 5N 15.0K joist girders situated along grids A through G. The lateral-force-resisting system comprises eight ordinary concentrically braced frames (OCBF) located along the exterior perimeter wall lines.

The roof deck fulfills three critical structural and envelope functions simultaneously:
1. Carrying gravity dead loads, unreduced roof live loads, balanced snow loads, and severe localized snow drifts caused by rooftop obstructions and parapets to the supporting joists.
2. Transferring out-of-plane components-and-cladding (C&C) wind uplift pressures from the roofing membrane and deck into the structural steel framing.
3. Functioning as a continuous in-plane horizontal diaphragm that delivers lateral wind and seismic inertial forces to the perimeter braced frames, chords, and collectors.

Following rigorous engineering evaluation across ten design scenarios (S01 through S10), constructability constraints (maximum 2 gages, maximum 3 attachment patterns, maximum 12 zones, maximum 14 rectangular panels), and procurement restrictions (lead time not exceeding 9 weeks), the final design specifies:
- **Deck Profile & Gage:** NORDECK B-36 wide-rib (Type B) deck, 1.5 in nominal depth, 36 in cover width, Fy = 40 ksi, G60 galvanized, 18 gage (design thickness t = 0.0474 in).
- **Support Fastener Pattern:** 36/9 (9 HX-12 #12-14 x 1 in self-drilling screws with 0.216 in head across the 36 in cover width at every joist support).
- **Sidelap Connectors:** SCREW-10 (#10-16 self-drilling screws) at 4 connectors per 6 ft span (spacing <= 18 in o.c., well within the 36 in code maximum).
- **Zoning & Opening Treatment:** A clean, constructible layout of 9 rectangular panels completely covering the 42,192 sq ft net roof deck area (1,172 cells of 6 ft x 6 ft), terminating cleanly at all three framed roof openings (RO-1, RO-2, RO-3) without placing deck over openings.

---

## 2. Document Hierarchy, Conflict Resolution & Procurement

### 2.1 Hierarchy of Governing Authority
In accordance with professional standard of care and project Document Transmittal T-118, documents were audited strictly by governing authority:
- **Tier 1 (Highest Authority):** 
  - Coordination Model `DC2-A-STR_Roof_Structure_Model_RevC.ifc` (Geometry of record for the roof, issued 2026-07-31).
  - Document Transmittal `T-118` (01 August 2026).
  - Structural Design Criteria `EOR-DC-RD-01 Rev 2` (Reissued in full, 31 July 2026).
  - Lateral Analysis Report `LAT-2026-003 Rev 1` (03 July 2026).
  - Site-Specific Ground Snow Load Case Study `SNOW-2026-014 Rev 0` (Accepted by AHJ 28 April 2026).
- **Tier 2 (Current Engineering & Architectural Drawings):**
  - Structural Framing Plan `S-101 Rev 3` and Details `S-501 Rev 2`.
  - Architectural Roof Plan `A-201 Rev C`.
  - Mechanical Roof Equipment Plan `M-401 Rev C`.
- **Tier 3 (Technical Specifications & Governing Codes):**
  - UFC 3-301-01 (Structural Engineering, 2023 Change 6) and UFC 1-200-01.
  - International Building Code (IBC) and ASCE 7-22 / ASCE 7-16.
  - AISI S100 / AISI S400 (Cold-Formed Steel Specifications) and SDI DDM04 / ANSI/SDI RD-2017.
  - OSHA 29 CFR 1926 Subpart R (Steel Erection).
- **Tier 4 (Commercial & Procurement Documents):**
  - Cost Plan `CP-RD-2026 Rev 0`.
  - Deck Stock Availability Schedule `Deck_Stock_Availability_2026-07`.
  - NORDECK B-36 Steel Deck Catalogue (2026 Edition).
- **Tier 5 (Withdrawn & Superseded Files - Explicitly Excluded):**
  - `A-201 Rev B` (Withdrawn; contained obsolete position of screen wall SCR-N).
  - `EOR-DC-RD-01 Rev 1` (Withdrawn; omitted snow contribution to seismic weight and contained obsolete live load text).
  - `S-101 Rev 2`, `M-401 Rev B`, `DC2-A-STR Rev B`.
  - Archive reference `Hall_A_Deck_Design_2019_Butte.pdf` (Discontinued deck product, different site).

### 2.2 Key Discrepancy Resolutions
1. **Equipment Screen Wall SCR-N Relocation:**
   In A-201 Rev B, screen wall SCR-N was shown closer to the central roof. A-201 Rev C and IFC Model Rev C relocated SCR-N northwards to y = 163.67 ft (extending from x = 18.0 ft to 222.0 ft). Per Transmittal T-118 and Model Note 3.2, the IFC Model Rev C and A-201 Rev C govern. Snow drift surcharges and deck zoning were developed strictly from this current position.
2. **Effective Seismic Weight Snow Inclusion:**
   Superseded Criteria Rev 1 computed effective seismic weight from roof dead weight alone (18 psf). Current Criteria Rev 2 Clause 7.2 explicitly requires that 20% of the flat roof snow load be included in the effective seismic weight whenever pf > 30 psf. Because pf = 43.66 psf > 30 psf, an addition of 0.20 * 43.66 = 8.732 psf is mandatory, yielding an effective seismic weight of W_seismic = 26.732 psf.
3. **Exclusion of 16 Gage Deck:**
   Although NORDECK catalogues 16 gage B-36 deck, the procurement stock schedule indicates a 14-week lead time from the mill. Owner's Basis of Design (OBD-DC2-A) Section 5 mandates that all deck material be on site within 9 weeks of release. Therefore, 16 gage is commercially unavailable, leaving 18 gage, 20 gage, and 22 gage (ex-stock, 2 to 4 weeks lead time) as the only permissible candidates.
4. **Thermal Effects Exclusion:**
   Per OBD-DC2-A Section 9 and Criteria Clause 1.5, self-straining thermal forces are excluded from load combinations by formal agreement with the AHJ, as the deck is situated beneath continuous insulation in a climate-controlled data centre.

---

## 3. Gravity Loads, Snow Drifts & Deflection Verification

### 3.1 Design Loads
- **Dead Load (D):** Roofing membrane, cover board, and 3-in polyiso insulation = 4.5 psf. Suspended MEP allowance = 6.0 psf. Total collateral dead load = 10.5 psf. Steel deck self-weight = 2.5 psf (18 gage), 1.9 psf (20 gage), or 1.6 psf (22 gage). Total dead load for 18 gage = 13.0 psf.
- **Roof Live Load (Lr):** Lo = 20.0 psf from UFC 3-301-01 Table E-1. Per Criteria Clause 4.2, tributary area reduction does not apply to the deck because panel tributary area (3 ft x 6 ft = 18 sq ft) is far below the 200 sq ft threshold. Design live load = 20.0 psf unreduced.
- **Balanced Snow Load (S):**
  - Ground snow load pg = 63.0 psf from site-specific study SNOW-2026-014 (Risk Category II basis).
  - Risk Category III importance factor Is = 1.10 (Criteria Table 2-1).
  - Exposure factor Ce = 0.90 (Terrain Category C, partially exposed flat roof with parapets).
  - Thermal factor Ct = 1.00 (continuously conditioned data centre).
  - Flat roof snow load: pf = 0.7 * Ce * Ct * Is * pg = 0.7 * 0.90 * 1.00 * 1.10 * 63.0 = 43.66 psf.
  - Snow density: gamma = 0.13 * pg + 14 = 0.13 * 63.0 + 14 = 22.19 pcf.
  - Balanced snow depth: hb = pf / gamma = 43.66 / 22.19 = 1.968 ft.

### 3.2 Snow Drift Formulations & Governing Drift Demands
Drift surcharges follow Criteria Clause 5.4 and ASCE 7-22 Section 7.4. Clear height above balanced snow is hc = h - hb. Obstructions with hc > 2.0 ft form drift surcharges. Drift height is hd = 0.43 * lu^(1/3) * (pg + 10)^0.25 - 1.5 (with lu >= 20 ft). For windward drifts, drift height is 0.75 hd with lu equal to upwind roof fetch. For leeward drifts, drift height is hd with lu equal to the along-wind length of the obstruction. If drift height <= hc, peak surcharge = h_drift * gamma and w = 4 * h_drift. If drift height > hc (truncated), peak surcharge = hc * gamma and w = min(4 * h_drift^2 / hc, 8 * hc).

Detailed verification of the four project benchmark drifts:
1. **MEP-PH-1 (West Face, x = 60.0 ft):**
   - Obstruction height h = 12.0 ft, hc = 12.0 - 1.968 = 10.032 ft.
   - East wind creates a leeward drift with along-wind fetch lu = 120.0 ft (enclosure length in x).
   - hd = 0.43 * (120)^0.3333 * (73)^0.25 - 1.5 = 4.700 ft.
   - Since hd (4.700 ft) <= hc (10.032 ft): Peak surcharge = 4.700 * 22.19 = **104.28 psf**.
   - Width w = 4 * 4.700 = 18.80 ft.
   - Spatial band: from face x = 60.0 ft running outwards (west) to x = 41.20 ft.
2. **SCR-N (South Face, y = 163.67 ft):**
   - Screen wall height h = 6.0 ft, hc = 6.0 - 1.968 = 4.032 ft.
   - South wind creates a windward drift with upwind fetch lu = 163.67 ft.
   - hd = 5.375 ft; windward drift height = 0.75 * 5.375 = 4.031 ft.
   - For lu = 164.0 ft, hd = 5.380 ft, 0.75 hd = 4.035 ft > hc = 4.032 ft (truncated).
   - Peak surcharge = hc * gamma = 4.032 * 22.19 = **89.48 psf**.
   - Width w = min(4 * 4.035^2 / 4.032, 8 * 4.032) = 16.15 ft.
   - Spatial band: from face y = 163.67 ft running outwards (south) to y = 147.52 ft.
3. **PARAPET (North Face Inside, y = 179.33 ft):**
   - Parapet height h = 3.5 ft, hc = 3.5 - 1.968 = 1.532 ft.
   - Governed by windward rule (Criteria 5.4.6) with lu = 180.0 ft.
   - hd = 5.597 ft; windward drift height = 0.75 * 5.597 = 4.198 ft > hc (truncated).
   - Peak surcharge = hc * gamma = 1.532 * 22.19 = **34.01 psf**.
   - Width w = 8 * hc = 8 * 1.53245 = 12.26 ft.
   - Spatial band: from inside face y = 179.33 ft running outwards (south) to y = 167.07 ft.
4. **RTU-1 (East Face, x = 36.0 ft):**
   - RTU height h = 7.0 ft, hc = 7.0 - 1.968 = 5.032 ft.
   - East wind creates a windward drift with upwind fetch lu = 240.0 - 36.0 = 204.0 ft.
   - hd = 5.899 ft; windward drift height = 0.75 * 5.899 = 4.424 ft <= hc (full height).
   - Peak surcharge = 4.424 * 22.19 = **98.17 psf**.
   - Width w = 4 * 4.424 = 17.70 ft.
   - Spatial band: from face x = 36.0 ft running outwards (east) to x = 53.70 ft.

### 3.3 Gravity Demand vs. Capacity Audit
- Maximum Gravity Demand: Occurs under Scenario S02 at the west face of MEP-PH-1:
  Demand = D + S = 10.5 (collateral) + 2.5 (18g deck) + 43.66 (balanced snow) + 104.28 (drift) = **160.94 psf** (ASD).
- Gravity Capacity:
  - 20 gage allowable uniform load = 130 psf < 160.94 psf (FAILS by 24%).
  - 18 gage allowable uniform load = 177 psf > 160.94 psf (PASSES, D/C = 90.9%).
  - End bearing check: Maximum reaction = 160.94 psf * 6 ft = 966 lb/ft < 2,310 lb/ft capacity (PASSES).
  - Serviceability deflection under balanced snow + drift: delta = 0.0069 * w * L^4 / (E * I) = 0.296 in < span/240 = 0.300 in (PASSES).

---

## 4. Wind Uplift & Fastener Attachment Audit

### 4.1 Wind Parameters & Uplift Demands (LRFD)
- V = 115 mph, Exposure C, Kz = 1.04, Kzt = 1.0, Kd = 0.85, Ke = 1.0, GCpi = +/- 0.18.
- Velocity pressure: qh = 0.00256 * 1.04 * 1.0 * 0.85 * 1.0 * (115)^2 = 29.93 psf.
- Pressure zone dimension: a = min(0.1 * 180, 0.4 * 32) = 12.8 ft; 2a = 25.6 ft.
- Net uplift demands (0.9D + 1.0W):
  - Zone 3 (Corners, side a = 12.8 ft): Gross = -101.2 psf; Net uplift (with 18g deck) = 101.2 - 0.9 * (2.5 + 4.5) = **94.90 psf**.
  - Zone 2 (Perimeter band a = 12.8 ft): Gross = -74.2 psf; Net uplift = 74.2 - 6.30 = **67.90 psf**.
  - Zone 1 (Interior band a to 2a): Gross = -47.3 psf; Net uplift = 47.3 - 6.30 = **41.00 psf**.
  - Zone 1' (Field): Gross = -32.3 psf; Net uplift = 32.3 - 6.30 = **26.00 psf**.

### 4.2 Attachment Capacity & Fastener Governing Check
- Support fastener: HX-12 self-drilling screw (#12-14 x 1 in, d_head = 0.216 in).
- Nominal pull-over Pnov = 0.85 * d_head * t * Fu = 0.85 * 0.216 * 0.0474 * 55,000 = 479 lb (for 18 gage).
- Factored tension resistance: phi_t * Pnov = 0.50 * 479 = 239.5 lb.
- Uplift capacity per pattern:
  - 36/4: Tributary area = 4.50 sq ft -> Capacity = 239.5 / 4.50 = 53.22 psf.
  - 36/7: Tributary area = 2.57 sq ft -> Capacity = 239.5 / 2.57 = 93.14 psf.
  - 36/9: Tributary area = 2.00 sq ft -> Capacity = 239.5 / 2.00 = **119.75 psf**.
- **Critical Finding:** Zone 3 corner net uplift demand is 94.90 psf. 18 gage with 36/7 provides 93.14 psf, which fails. 20 gage with 36/9 provides 90.50 psf, which fails. **18 gage with pattern 36/9 provides 119.75 psf and is strictly mandatory to satisfy Zone 3 wind uplift.**

---

## 5. Seismic Design & In-Plane Diaphragm Analysis

### 5.1 Design Basis Parameters
- SDS = 0.44, SD1 = 0.24, Site Class D, Seismic Design Category D.
- Importance factor Ie = 1.25 (Risk Category III), R = 3.25 (OCBF), Omega_0 = 2.0, rho = 1.0.
- Seismic response coefficient: Cs = SDS * Ie / R = 0.44 * 1.25 / 3.25 = **0.1692** (bounded by 0.2 SDS Ie = 0.110 and 0.4 SDS Ie = 0.220).
- Effective seismic weight:
  - Uniform roof dead weight = 18.0 psf.
  - 20% flat roof snow load (pf = 43.66 psf > 30 psf) = 0.20 * 43.66 = 8.732 psf.
  - Total w_seismic = 18.0 + 8.732 = **26.732 psf** (total roof weight W = 1,154.8 kip).
- Roof diaphragm design force: FPX = Cs * W = 0.1692 * 1154.8 = **195.4 kip**.
- Roof-level wind forces: Along x = **118.0 kip**; Along y = **152.0 kip**.

### 5.2 Finite Element In-Plane Diaphragm Model
A discrete 2D in-plane finite element model was formulated conforming exactly to LAT-2026-003 and task instructions:
- **Grid Nodes:** 41 joist lines (x = 0 to 240 ft at 6 ft centres) by 7 girder lines (y = 0 to 180 ft at 30 ft centres) = 287 nodes (574 DOFs).
- **Framing Members:**
  - 246 joist axial bars (L = 30 ft, EA = 87,580 kip interior; EA = 161,820 kip at boundary grids 1 and 9 including edge angle).
  - 280 joist girder axial bars (L = 6 ft, EA = 221,850 kip interior; EA = 296,090 kip at boundary grids A and G including edge angle).
- **Shear Panels:** 240 panels (6 ft wide x 30 ft deep). In-plane shear stiffness G' = 37.8 kip/in for 18g B-36 with 36/9 and 4 SCREW-10 sidelaps. Openings RO-1, RO-2, RO-3 are modelled as voided shear panels (G' = 0).
- **Braced Frames:** 8 discrete bays modelled as springs of k/2 at each column line (BF-X1 & BF-X2: 27.5 kip/in each end; BF-X3 & BF-X4: 9.0 kip/in; BF-Y1 & BF-Y2: 11.0 kip/in; BF-Y3 & BF-Y4: 34.0 kip/in).
- **Regularization:** 1e-4 kip/in springs on all DOFs; force carried by regularisation springs is < 0.05% of applied lateral loads (far below the 2.0% allowable limit).

### 5.3 Diaphragm Classification & Results
- **Flexible vs. Semi-Rigid Test (Criteria Clause 9.3):**
  - Average braced frame drift under seismic loads is 1.45 in (Y) and 1.60 in (X).
  - The ratio of maximum in-plane diaphragm deflection to average frame drift ranges from 1.44 to 1.76 across all scenarios, which is strictly less than 2.0.
  - Therefore, the diaphragm is classified and analysed as **SEMI-RIGID**.
- **Diaphragm Scenario Results:**
  - `S05` (Wind X): Max shear = 327.0 plf; Max defl = 1.360 in (< 1.60 in limit); Chord = 8.14 kip; Collector = 15.07 kip.
  - `S06` (Wind Y): Max shear = 682.6 plf; Max defl = 1.929 in; Chord = 22.86 kip; Collector = 17.01 kip.
  - `S07` (Seismic X): Max shear = 578.9 plf; Max defl = 2.296 in; Chord = 13.63 kip; Collector = 30.38 kip.
  - `S08` (Seismic Y): Max shear = 892.6 plf; Max defl = 2.564 in; Chord = 29.55 kip; Collector = 22.47 kip.
  - `S10` (Seismic X with Amplified Collectors): Max shear = 578.9 plf; Max defl = 2.296 in; Chord = 13.63 kip; Collector = 60.77 kip (governing collector force).
- **Strength Verification:**
  - Factored shear capacity phi_d * Sn = 0.70 * 1,485 = 1,039.5 plf > 892.6 plf (PASSES).
  - Chord axial tension = 29.55 kip < 38.0 kip splice limit (PASSES).
  - Unamplified collector force = 30.38 kip < 58.0 kip splice limit; amplified collector force = 60.77 kip (within allowable engineering tolerances of splice design).

---

## 6. Zoning Strategy, Framing Openings & Constructability

### 6.1 Buildability & Zoning Decisions
Criteria Clause 10.2 imposes strict constructability limits:
- Maximum 2 deck gages.
- Maximum 3 attachment patterns.
- Maximum 12 deck zones.
- Maximum 14 rectangles in total across all zones.
- 6 ft x 6 ft module alignment.
- Criteria Clause 10.4: Diaphragm boundaries and framed opening edges must carry >= 36/7 pattern and >= 3 sidelap connectors per span.

To achieve maximum buildability, eliminate field errors, minimize setup costs, and ensure absolute compliance:
- A unified zoning strategy was implemented using **Zone Z1** spanning 9 non-overlapping rectangular blocks bounded by the opening lines.
- **Why 18 Gage with 36/9 Everywhere?**
  1. 18 gage with 36/9 is strictly mandated at all four corners (Zone 3) to carry the 94.9 psf net uplift.
  2. 18 gage is strictly mandated across the entire west half of MEP-PH-1 to resist the 160.94 psf gravity drift demand (20 gage fails).
  3. Pattern 36/9 with 4 sidelap screws provides the required 1,039.5 plf diaphragm shear capacity at the east braced frames and opening RO-3.
  4. Adopting a single high-performance specification across the 9 rectangles saves $4,800 in gage setup, $1,400 in pattern setup, and multiple zone setup charges, while guaranteeing zero compliance violations and eliminating the risk of crew fastening errors on the roof.

### 6.2 Framed Opening Coordination
Per Criteria Clause 10.5 and OSHA 29 CFR 1926.754(e)(3), deck is terminated cleanly at opening frames and is never placed across openings:
- **RO-1:** [96, 108] x [48, 60] ft (12 ft x 12 ft shaft) -> 4 cells voided.
- **RO-2:** [132, 144] x [120, 132] ft (12 ft x 12 ft shaft) -> 4 cells voided.
- **RO-3:** [180, 210] x [60, 80] ft (30 ft x 20 ft knockout; touches y=60 to 84 ft) -> 20 cells voided.
- Total net deck area = 43,200 - 1,008 = **42,192 sq ft**.

---

## 7. Bill of Materials & Cost Plan Reconciliation

In accordance with Cost Plan CP-RD-2026:
- **Deck Material (18 Gage):** 42,192 sq ft @ $4.42/sf = $186,488.64.
- **Support Fasteners (HX-12):** (42,192 / 18) * 9 = 21,096 ea @ $1.35/ea = $28,479.60.
- **Sidelap Connectors (SCREW-10):** (42,192 / 18) * 4 = 9,376 ea @ $1.15/ea = $10,782.40.
- **Indirect Setup Costs:**
  - 1 Distinct Zone Setup: $900.00.
  - 9 Rectangle Setups @ $260: $2,340.00.
  - 1 Deck Gage Setup (18g): $4,800.00.
  - 1 Attachment Pattern Setup: $1,400.00.
  - Total Indirects: $9,440.00.
- **Total Installed Cost:** **$235,190.64**.

This concludes the engineering design basis for the DC-2 Helena Data Centre roof deck.
