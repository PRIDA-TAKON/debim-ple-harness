```json
{
  "frost": {
    "afi_100yr_F_days": 556,
    "afi_product_period": "1981-2010",
    "frost_depth_in": 42,
    "superseded_product_period": "1951-1980",
    "superseded_afi_100yr_F_days": 416
  },
  "pads": {
    "CR-P1": {
      "governing_constraint": "ANGULAR_DISTORTION",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 126074.52,
      "improved_cost_usd": 78027.63
    },
    "CR-P2": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 223521.19,
      "improved_cost_usd": 85168.14
    },
    "CR-P3": {
      "governing_constraint": "ANGULAR_DISTORTION",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 32915.26,
      "improved_cost_usd": 51117.77
    },
    "CR-P4": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 58910.86,
      "improved_cost_usd": 43115.52
    },
    "CR-P5": {
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 17922.47,
      "improved_cost_usd": 35736.19
    },
    "CR-P6": {
      "governing_constraint": "ANGULAR_DISTORTION",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 196610.46,
      "improved_cost_usd": 80186.1
    }
  },
  "campus": {
    "rigs_mobilised": 2,
    "mobilisation_cost_usd": 80000.0,
    "total_cost_usd": 417335.12,
    "pads_improved": [
      "CR-P1",
      "CR-P2",
      "CR-P4",
      "CR-P6"
    ]
  },
  "rejected_criteria": [
    "UFC 3-220-01N (2005) - Cancelled predecessor foundation design criteria superseded by UFC 3-220-01 (2012 c3)",
    "UFC 3-220-10N (2005) - Cancelled predecessor soil mechanics criteria superseded by UFC 3-220-10 / DM 7.1",
    "AV-CR-2604 Basis of Design Structural Rev 1 - Superseded in its entirety by Basis of Design Structural Rev 3",
    "AV-CR-2604 Geotechnical Addendum 1 - Superseded in its entirety by Geotechnical Data Report Rev 2",
    "Broadview Commons Adjacent Parcel Report (2023) - Different property; information only per RFI-013",
    "NOAA NCEI Air-Freezing Index return periods (1951-1980) - Superseded product period; set aside per RFI-007 and AHJ Letter Amendment 3",
    "USACE EM 1110-2-2104 Table 3-1 - Hydraulic structure load factors rejected per Load Combination Memo Note 8"
  ]
}
```

# Basis of Design: Phase 1 Foundation Strategy — Spread Footings vs. Rammed Aggregate Piers
**Project:** Cattail Run Data Campus (AV-CR-2604), Loudoun County, Virginia  
**Engineer of Record:** Structural & Geotechnical Engineer of Record  
**Date:** 2026-11-13  

---

## 1. Executive Summary & Campus Programme Decision

A comprehensive geotechnical, structural, and cost optimisation audit was conducted for the thirty-six foundation units across the six building pads (CR-P1 through CR-P6) of the Cattail Run Data Campus Phase 1 development. Each pad carries one instrumented column line of six foundation units: five isolated column footings (F1 through F5) and one continuous shear-wall footing (W1).

### Campus Optimization Strategy:
- **Improved Spread Footings over Rammed Aggregate Piers (4 Pads):** CR-P1 (Data Hall 1), CR-P2 (Data Hall 2), CR-P4 (Administration & Operations Building), and CR-P6 (Data Hall 3).
- **Shallow Spread Footings Alone (2 Pads):** CR-P3 (Electrical Yard Building) and CR-P5 (Logistics & Spares Warehouse).
- **Rig Mobilisation Programme:** Exactly **2 specialty ground-improvement rigs** are mobilised, serving up to 2 pads each within the milestone window (Rig 1: CR-P1, CR-P2; Rig 2: CR-P4, CR-P6). This fully utilizes the mobilised rigs at zero wasted mobilization capacity and avoids triggering an unnecessary third rig ($40,000 penalty).
- **Total Campus Foundation Programme Cost:** **$417,335.12** (including $80,000 rig mobilisation, concrete, reinforcement, excavation, backfill, aggregate piers, working platform geosynthetic, and quality-control production modulus testing).

---

## 2. Governing Criteria and Hierarchy of Truth

All foundation analyses, sizing, detailing, and costings strictly adhere to the governing authority:
1. **Local Jurisdiction Mandates (Tier 1):**
   - **Loudoun County Department of Building and Development Amendment Letter LC-BD-26-0774 (Permit BP-26-11884, 2026-08-14):**
     - **Amendment 3 (Frost Protection):** Establishes a 100-year return-period Air-Freezing Index threshold of 500 degree F-days. For sites exceeding 500 F-days, the minimum foundation bearing surface depth is **42 inches** below finished grade. The governing station of record is NOAA NCEI cooperative station USC00444909 (LINCOLN, VA). The current product computed over the 1981-2010 normals period governs (yielding **556 degree F-days**, exceeding the 500 F-day threshold). The 1951-1980 tables (reporting 416 F-days) are superseded and set aside per RFI-007. Thus, **bearing depth Df = 42 inches (3.50 ft)** governs campus-wide.
     - **Amendment 4 (Prohibition on Presumptive Values):** Strictly prohibits building code presumptive load-bearing values. Site-specific bearing capacity and settlement analyses are required.
2. **Governing Geotechnical Criteria (Tier 2):**
   - **UFC 3-220-01 Geotechnical Engineering (2012, Change 3, 1 July 2025):**
     - Paragraph 2-4.7.1: Mandates bearing capacity and settlement analysis using a minimum of three widely accepted methods.
     - Paragraph 2-4.7.1: Establishes total post-construction settlement limit of **1.0 inch (25.4 mm)** and differential settlement angular distortion limit of **1/500 (0.0020 rad)** between adjacent units.
     - Paragraph 2-4.7.1: Sets minimum footing plan dimensions: isolated column footings B >= 24 inches (610 mm); continuous footings B >= 18 inches or wall thickness + 8 inches = 12 + 8 = 20 inches (dimensioned to 21 inches minimum).
     - Table 2-3: Minimum factors of safety on bearing capacity:
       - CR-P1, CR-P2, CR-P3, CR-P6 (Light Industrial, Public): **FS = 3.5**.
       - CR-P4 (Apartments, Office): **FS = 3.0**.
       - CR-P5 (Warehouse): **FS = 2.5**.
     - Paragraph 2-4.6.3: Minimum factor of safety against sliding of **2.0**.
     - Paragraph 2-4.7.7: Maximum rebar spacing of 12 inches (305 mm) and minimum bar size of #4.
3. **Governing References (Tier 3):**
   - **UFC 3-220-20 Foundations and Earth Structures (DM 7.2, 2025):** Section 5-3 general bearing capacity equations (Brinch Hansen and Meyerhof), shape/depth correction factors, groundwater table corrections (Figure 5-6), and net allowable bearing formulation (Eqn 5-14).
   - **FHWA GEC 13 Vol 1 Ground Modification Methods:** Rammed aggregate pier design for rigid footings: stress concentration ratio ns = 10.0 (Section 4.2.1 and RFI-011), top-of-pier stress equation (Eqn 5-12), two-layer settlement model with upper zone compression (Eqn 5-13), and lower zone layered elastic compression (Eqn 5-14).
   - **USACE EM 1110-2-2000 Concrete for Civil Works Structures:** Table 2-2 sulfate exposure condition thresholds: Negligible (<0.10% SO4, Class S0), Moderate (0.10-0.20% SO4, Class S1), Severe (>0.20% SO4, Class S2).
   - **USACE EM 1110-2-2502 Retaining and Flood Walls:** Limit-equilibrium sliding stability and passive earth pressure calculations.
   - **UFGS 03 30 00 Cast-in-Place Concrete:** Durability limits on maximum w/cm and minimum f'c across environmental exposure classes.
   - **AV-CR-2604 Basis of Design Structural Rev 3:** Supersedes Rev 1; assigns occupancy, environmental exposure classes, dimensioning rules (nearest 3 in, min thickness 12 in, max depth 15 ft), minimum reinforcement ratio rho_min = 0.0018, and effective depth d = t - 4 in.
4. **Documents Reviewed and Set Aside:**
   - UFC 3-220-01N (2005) & UFC 3-220-10N (2005): Cancelled predecessor standards.
   - AV-CR-2604 Basis of Design Structural Rev 1: Superseded by Rev 3.
   - AV-CR-2604 Geotechnical Addendum 1: Superseded by Geotechnical Data Report Rev 2.
   - Adjacent Parcel Report Broadview Commons (2023): Non-applicable property per RFI-013.
   - NOAA NCEI AFI 1951-1980 Tables: Superseded climate normals period per RFI-007.
   - USACE EM 1110-2-2104 Table 3-1: Hydraulic structure load factors rejected per Load Combination Memo Note 8.

---

## 3. Geotechnical Analysis Methodology

### 3.1 Stratigraphy and Groundwater
Twelve borings (B-101A/B through B-106A/B) establish the subsurface stratigraphy. For each pad, Boring A is at Station 0.0 ft (coincident with F1) and Boring B is at Station 77.0 ft (coincident with W1). In accordance with GDR Rev 2 Section 4, the contact between Stratum I and Stratum II is interpolated linearly by foundation station. Stratum II thickness is uniform per pad. All footings bear uniformly at Df = 42 in = 3.5 ft below finished grade, entirely within Stratum I residual soils (unit weight = 118 pcf, phi = 26.0 deg, c = 0.25 ksf). Stabilised groundwater depths range from 8.0 ft (CR-P1, CR-P4) to 21.0 ft (CR-P5), everywhere well below the foundation bearing elevation (3.5 ft < 8.0 ft), confirming that construction dewatering is 0 days campus-wide.

### 3.2 Bearing Capacity Formulation
Ultimate bearing capacity is evaluated via the general bearing capacity equation of UFC 3-220-20 (Eqn 5-15) using Brinch Hansen factors:
q_ult = c * Nc * sc * dc + sigma'_zD * Nq * sq * dq + 0.5 * gamma_eff * B * Ngamma * sgamma * dgamma
For phi = 26.0 deg: Nc = 22.25, Nq = 11.85, Ngamma = 7.94. Groundwater effects on effective unit weight gamma_eff and overburden sigma'_zD are incorporated per UFC 3-220-20 Figure 5-6 (Case 2: water table between Df and Df + B). Net allowable bearing pressure is derived deterministically per UFC 3-220-20 Eqn 5-14:
q_allow,net = (q_ult / FS) - sigma_zD
Applied net bearing pressure q_net = P_service / (B * L) is strictly constrained to q_net <= q_allow,net for all units.

### 3.3 Settlement Analysis
Per RFI-019 and FHWA GEC 13 Eqn 5-14, settlement is evaluated using Layered Elastic Compression:
- The soil below the bearing surface is discretised into uniform layers of thickness H = 0.25 ft.
- Compression is integrated to a depth of z_max = max(4B, 40 ft).
- Net stress increment in each layer is computed using the 2 vertical to 1 horizontal (2:1) stress distribution:
  delta_sigma(z_i) = P_service / [(B + z_i) * (L + z_i)]
- **Unimproved Spread Footings:**
  s = 12 * sum[ delta_sigma(z_i) * H / E_s(z_i) ] [inches]
  where E_s(z_i) corresponds to the pad-specific modulus for Stratum I, Stratum II, or Stratum III at depth Df + z_i.
- **Improved Spread Footings (Two-Layer Method):**
  - **Upper Zone:** Aggregate piers reinforce Stratum I to treatment depth H_pier. Top-of-pier stress qg is computed per FHWA GEC 13 Eqn 5-12 with ns = 10.0 and replacement ratio Ra = (n * A_pier) / (B * L), with qg <= 18,000 psf. Upper zone settlement is s_uz = (qg / 144) / kg (Eqn 5-13).
  - **Lower Zone:** Layered elastic compression is integrated from the pier tip (z = H_pier) down to z_max. Because piers penetrate into Stratum II (Es = 1400 - 1800 ksf), lower zone compression is minimal (0.05 - 0.15 in).
  - **Total Settlement:** s_tot = s_uz + s_lz <= 1.0 inch.
  - **Angular Distortion:** delta_s / span <= 1/500 = 0.0020.

---

## 4. Structural Design & Detailing

- **Concrete Durability Limits (UFGS 03 30 00 & BoD Rev 3):**
  - CR-P1: F1, W1, C1, S1 (0.14% SO4) -> f'c = 4000 psi, max w/cm = 0.50.
  - CR-P2: F1, W1, C1, S2 (0.23% SO4) -> f'c = 4500 psi, max w/cm = 0.45.
  - CR-P3: F1, W1, C1, S0 (0.07% SO4) -> f'c = 4000 psi, max w/cm = 0.50.
  - CR-P4: F1, W1, C1, S1 (0.11% SO4) -> f'c = 4000 psi, max w/cm = 0.50.
  - CR-P5: F3, W1, C1, S0 (0.05% SO4) -> f'c = 5000 psi, max w/cm = 0.40.
  - CR-P6: F1, W1, C1, S2 (0.26% SO4) -> f'c = 4500 psi, max w/cm = 0.45.
- **Shear and Thickness:** Sized in 3-inch increments (t >= 12 in, d = t - 4 in) to satisfy factored two-way punching shear (Vu <= phi * 4 * sqrt(f'c) * bo * d, phi = 0.75) and one-way beam shear (Vu <= phi * 2 * sqrt(f'c) * bw * d) under STRENGTH_1.2D_1.6L.
- **Flexural Reinforcement:** Grade 60 (fy = 60,000 psi); rho >= 0.0018; bar sizes #4 through #8 with spacing <= 12 inches.
- **Shear-Wall Footing (W1) Stability:**
  - Eccentricity under SERVICE_D_PLUS_L_PLUS_W: e <= L/6 = 48 in (e = 7.2 - 7.6 in, well within middle third).
  - Net uplift under UPLIFT_W / 0.6D_PLUS_W: FS_uplift = W_resist / |P_up| >= 1.5 (actual FS = 2.97 - 3.21).
  - Sliding under 0.6D_PLUS_W: FS_sliding = (V * tan(delta) + 0.5 * Pp) / Hx >= 2.0 (actual FS = 2.70 - 3.06).

---

## 5. Pad-by-Pad Feasibility and Cost Trade-Off Analysis

| Pad ID | Building Type | Foundation Strategy | Governing Constraint | Spread-Only Cost | Improved Cost | Cost Delta (Savings) | Technical Basis |
| :--- | :--- | :--- | :--- | :---: | :---: | :---: | :--- |
| **CR-P1** | Data Hall 1 | **IMPROVED_SPREAD** | `ANGULAR_DISTORTION` | $126,074.52 | $78,027.63 | **+$48,046.89** | Soft Stratum I (Es=110 ksf) causes excessive settlement (>3 in) under spread footings; unimproved footings exceed 30 ft width and overlap. Aggregate piers reduce settlement to <0.95 in, satisfy 1/500 angular distortion, and save $48,046.89. |
| **CR-P2** | Data Hall 2 | **IMPROVED_SPREAD** | `SETTLEMENT` | $223,521.19 | $85,168.14 | **+$138,353.05** | Softest soil on campus (Es=85 ksf, Base I down to 13.5 ft). Spread footings are physically infeasible (>3 in settlement). Aggregate piers provide stiff upper zone support (kg=140 pci) and save $138,353.05. |
| **CR-P3** | Electrical Yard | **SPREAD** | `ANGULAR_DISTORTION` | $32,915.26 | $51,117.77 | **+$18,202.51** | Stiff Stratum I (Es=210 ksf) with shallow Stratum II contact (5.5-7.0 ft) and lighter loads. Sizing W1 to B=135 in satisfies 1/500 angular distortion. Avoids mobilizing a third rig ($40,000 penalty) and eliminates specialty ground improvement costs, saving $18,202.51 directly. |
| **CR-P4** | Admin & Operations | **IMPROVED_SPREAD** | `BEARING` | $58,910.86 | $43,115.52 | **+$15,795.34** | Modest loads but low modulus (Es=130 ksf). Improved footings utilize spare capacity of Rig 2 at zero additional mobilisation cost, yielding a direct net savings of $15,795.34 over massive spread footings. |
| **CR-P5** | Logistics Warehouse | **SPREAD** | `BEARING` | $17,922.47 | $35,736.19 | **+$17,813.72** | Stiffest matrix soil (Es=250 ksf) with very shallow rock/Stratum II (4.5-5.5 ft) and lightest loads. Sized strictly by bearing capacity (B=6.5 - 10.5 ft). All settlements are 0.50-0.74 in with distortion <1/1300. Ground improvement would add unnecessary cost and trigger a third rig, saving $17,813.72 directly. |
| **CR-P6** | Data Hall 3 | **IMPROVED_SPREAD** | `ANGULAR_DISTORTION` | $196,610.46 | $80,186.10 | **+$116,424.36** | Heavy data hall loads over soft soil (Es=95 ksf, Base I up to 14.0 ft). Unimproved footings would overlap. Piers ensure complete structural compliance, satisfy 1/500 angular distortion, and save $116,424.36. |

---

## 6. Rig Allocation and Scheduling Programme

The Kettleridge specialty subcontractor budget proposal restricts each mobilised rig to serving at most 2 building pads within the milestone window. Mobilisation is priced as a lump sum of $40,000 per rig and is not prorated.
- **Rig 1:** Mobilised for **CR-P1** and **CR-P2** ($40,000). Both are heavy data halls with deep soft residual soils requiring ground improvement.
- **Rig 2:** Mobilised for **CR-P6** and **CR-P4** ($40,000). CR-P6 is a heavy data hall. CR-P4 utilizes Rig 2's second pad slot, capturing substantial savings without triggering additional mobilisation.
- **Pads CR-P3 and CR-P5:** Designed as compliant, high-performance shallow spread footings. They require zero rig mobilisations, perfectly capping total campus mobilisation at **2 rigs ($80,000)**.
- **Verification Testing:** Exactly **1 production modulus load test** is specified and budgeted per improved pad (4 tests total at $9,500/EA = $38,000).
