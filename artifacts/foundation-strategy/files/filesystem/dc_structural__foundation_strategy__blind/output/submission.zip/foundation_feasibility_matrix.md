# Foundation Feasibility and Optimisation Matrix
**Project:** Cattail Run Data Campus Phase 1 (AV-CR-2604)  
**Document:** Foundation Type Feasibility Matrix  
**Campus Total Cost:** $417,335.12  

---

## 1. Overview
This matrix summarizes the foundation demands, geotechnical capacity checks, predicted settlements, shear-wall footing stability checks, governing constraints, and shallow-versus-improved cost evaluations for all 36 foundation units across the six building pads.

---

## Pad CR-P1 — Light Industrial, Public
- **Decision:** **IMPROVED_SPREAD**
- **Pad Governing Constraint:** `ANGULAR_DISTORTION`
- **Concrete:** f'c = 4000 psi, max w/cm = 0.5 (Exposure Classes: F1, W1, C1, S1)
- **Bearing Depth:** 42 in (3.50 ft) below finished grade (Stratum I residual soil)
- **Bearing Factor of Safety:** 3.5
- **Cost Comparison:**
  - Spread-Only Alternative: **$126,074.52**
  - Improved-Spread Alternative: **$78,027.63**
  - Decision Basis: Improved spread footing selected to prevent excessive settlement (>3 in) and footing overlap, saving substantial concrete/excavation costs.

| Tag | Element | B (in) | L (in) | t (in) | Service P (k) | Factored Pu (k) | q_net (ksf) | q_allow (ksf) | Piers (n x H_ft) | Ra | qg (psf) | Settlement (in) | Governing Constraint |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| F1 | Col 24.0x24.0 in | 135 | 135 | 27 | 610.0 | 838.0 | 4.82 | 4.88 | 5 x 8 ft | 0.194 | 17556 | 0.855 | `BEARING` |
| F2 | Col 26.0x26.0 in | 186 | 186 | 39 | 1180.0 | 1622.0 | 4.91 | 4.96 | 10 x 8 ft | 0.204 | 17301 | 0.919 | `BEARING` |
| F3 | Col 28.0x28.0 in | 204 | 204 | 42 | 1420.0 | 1953.0 | 4.91 | 4.99 | 12 x 8 ft | 0.204 | 17335 | 0.952 | `BEARING` |
| F4 | Col 26.0x26.0 in | 171 | 171 | 33 | 980.0 | 1348.0 | 4.83 | 4.93 | 8 x 9 ft | 0.193 | 17610 | 0.906 | `BEARING` |
| F5 | Col 22.0x22.0 in | 126 | 126 | 24 | 520.0 | 715.0 | 4.72 | 4.88 | 5 x 10 ft | 0.223 | 15703 | 0.758 | `BEARING` |
| W1 | Shear Wall 24 ft | 180 | 288 | 33 | 1650.0 | 2244.0 | 4.58 | 4.59 | 13 x 16 ft | 0.177 | 17660 | 0.868 | `ANGULAR_DISTORTION` |

**Shear-Wall Footing (W1) Stability Evaluation:**
- Resultant Eccentricity e: **7.51 in** (Middle third limit: <= 48.0 in) — **PASS**
- Net Uplift Factor of Safety: **3.13** (Code minimum: >= 1.50) — **PASS**
- Sliding Factor of Safety: **2.96** (UFC 3-220-01 minimum: >= 2.00) — **PASS**

## Pad CR-P2 — Light Industrial, Public
- **Decision:** **IMPROVED_SPREAD**
- **Pad Governing Constraint:** `SETTLEMENT`
- **Concrete:** f'c = 4500 psi, max w/cm = 0.45 (Exposure Classes: F1, W1, C1, S2)
- **Bearing Depth:** 42 in (3.50 ft) below finished grade (Stratum I residual soil)
- **Bearing Factor of Safety:** 3.5
- **Cost Comparison:**
  - Spread-Only Alternative: **$223,521.19**
  - Improved-Spread Alternative: **$85,168.14**
  - Decision Basis: Improved spread footing selected to prevent excessive settlement (>3 in) and footing overlap, saving substantial concrete/excavation costs.

| Tag | Element | B (in) | L (in) | t (in) | Service P (k) | Factored Pu (k) | q_net (ksf) | q_allow (ksf) | Piers (n x H_ft) | Ra | qg (psf) | Settlement (in) | Governing Constraint |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| F1 | Col 24.0x24.0 in | 138 | 138 | 27 | 646.6 | 888.3 | 4.89 | 4.93 | 6 x 11 ft | 0.223 | 16274 | 0.917 | `BEARING` |
| F2 | Col 26.0x26.0 in | 192 | 192 | 39 | 1250.8 | 1719.3 | 4.89 | 5.01 | 12 x 10 ft | 0.230 | 15911 | 0.974 | `BEARING` |
| F3 | Col 28.0x28.0 in | 210 | 210 | 42 | 1505.2 | 2070.2 | 4.91 | 5.05 | 15 x 9 ft | 0.240 | 15535 | 0.992 | `BEARING` |
| F4 | Col 26.0x26.0 in | 174 | 174 | 36 | 1038.8 | 1428.9 | 4.94 | 4.98 | 10 x 8 ft | 0.233 | 15932 | 0.977 | `BEARING` |
| F5 | Col 22.0x22.0 in | 129 | 129 | 27 | 551.2 | 757.9 | 4.77 | 4.92 | 5 x 8 ft | 0.212 | 16382 | 0.931 | `BEARING` |
| W1 | Shear Wall 24 ft | 189 | 288 | 33 | 1749.0 | 2378.6 | 4.63 | 4.70 | 17 x 8 ft | 0.221 | 15491 | 0.999 | `BEARING` |

**Shear-Wall Footing (W1) Stability Evaluation:**
- Resultant Eccentricity e: **7.52 in** (Middle third limit: <= 48.0 in) — **PASS**
- Net Uplift Factor of Safety: **3.13** (Code minimum: >= 1.50) — **PASS**
- Sliding Factor of Safety: **2.95** (UFC 3-220-01 minimum: >= 2.00) — **PASS**

## Pad CR-P3 — Light Industrial, Public
- **Decision:** **SPREAD**
- **Pad Governing Constraint:** `ANGULAR_DISTORTION`
- **Concrete:** f'c = 4000 psi, max w/cm = 0.5 (Exposure Classes: F1, W1, C1, S0)
- **Bearing Depth:** 42 in (3.50 ft) below finished grade (Stratum I residual soil)
- **Bearing Factor of Safety:** 3.5
- **Cost Comparison:**
  - Spread-Only Alternative: **$32,915.26**
  - Improved-Spread Alternative: **$51,117.77**
  - Decision Basis: Shallow spread footing alone selected because soil stiffness and shallow Stratum II contact provide full settlement and distortion compliance at lower direct cost and zero rig mobilization.

| Tag | Element | B (in) | L (in) | t (in) | Service P (k) | Factored Pu (k) | q_net (ksf) | q_allow (ksf) | Piers (n x H_ft) | Ra | qg (psf) | Settlement (in) | Governing Constraint |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| F1 | Col 24.0x24.0 in | 114 | 114 | 21 | 439.2 | 603.4 | 4.87 | 5.09 | None | 0.000 | 0 | 0.639 | `BEARING` |
| F2 | Col 26.0x26.0 in | 153 | 153 | 33 | 849.6 | 1167.8 | 5.23 | 5.25 | None | 0.000 | 0 | 0.870 | `BEARING` |
| F3 | Col 28.0x28.0 in | 168 | 168 | 33 | 1022.4 | 1406.2 | 5.22 | 5.33 | None | 0.000 | 0 | 0.995 | `BEARING` |
| F4 | Col 26.0x26.0 in | 141 | 141 | 27 | 705.6 | 970.6 | 5.11 | 5.20 | None | 0.000 | 0 | 0.950 | `BEARING` |
| F5 | Col 22.0x22.0 in | 105 | 105 | 21 | 374.4 | 514.8 | 4.89 | 5.06 | None | 0.000 | 0 | 0.839 | `BEARING` |
| W1 | Shear Wall 24 ft | 135 | 288 | 24 | 1188.0 | 1615.7 | 4.40 | 4.71 | None | 0.000 | 0 | 0.942 | `ANGULAR_DISTORTION` |

**Shear-Wall Footing (W1) Stability Evaluation:**
- Resultant Eccentricity e: **7.06 in** (Middle third limit: <= 48.0 in) — **PASS**
- Net Uplift Factor of Safety: **3.12** (Code minimum: >= 1.50) — **PASS**
- Sliding Factor of Safety: **2.89** (UFC 3-220-01 minimum: >= 2.00) — **PASS**

## Pad CR-P4 — Apartments, Office
- **Decision:** **IMPROVED_SPREAD**
- **Pad Governing Constraint:** `BEARING`
- **Concrete:** f'c = 4000 psi, max w/cm = 0.5 (Exposure Classes: F1, W1, C1, S1)
- **Bearing Depth:** 42 in (3.50 ft) below finished grade (Stratum I residual soil)
- **Bearing Factor of Safety:** 3.0
- **Cost Comparison:**
  - Spread-Only Alternative: **$58,910.86**
  - Improved-Spread Alternative: **$43,115.52**
  - Decision Basis: Improved spread footing selected to prevent excessive settlement (>3 in) and footing overlap, saving substantial concrete/excavation costs.

| Tag | Element | B (in) | L (in) | t (in) | Service P (k) | Factored Pu (k) | q_net (ksf) | q_allow (ksf) | Piers (n x H_ft) | Ra | qg (psf) | Settlement (in) | Governing Constraint |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| F1 | Col 24.0x24.0 in | 99 | 99 | 21 | 384.3 | 527.9 | 5.65 | 5.77 | 4 x 8 ft | 0.288 | 15700 | 0.648 | `BEARING` |
| F2 | Col 26.0x26.0 in | 138 | 138 | 30 | 743.4 | 1021.9 | 5.62 | 5.77 | 7 x 8 ft | 0.260 | 16838 | 0.739 | `BEARING` |
| F3 | Col 28.0x28.0 in | 150 | 150 | 33 | 894.6 | 1230.4 | 5.73 | 5.78 | 8 x 8 ft | 0.251 | 17552 | 0.788 | `BEARING` |
| F4 | Col 26.0x26.0 in | 126 | 126 | 27 | 617.4 | 849.2 | 5.60 | 5.76 | 6 x 8 ft | 0.267 | 16450 | 0.713 | `BEARING` |
| F5 | Col 22.0x22.0 in | 93 | 93 | 21 | 327.6 | 450.4 | 5.45 | 5.78 | 3 x 8 ft | 0.245 | 17010 | 0.691 | `BEARING` |
| W1 | Shear Wall 24 ft | 108 | 288 | 21 | 1039.5 | 1413.7 | 4.81 | 4.92 | 9 x 8 ft | 0.205 | 16941 | 0.753 | `BEARING` |

**Shear-Wall Footing (W1) Stability Evaluation:**
- Resultant Eccentricity e: **6.98 in** (Middle third limit: <= 48.0 in) — **PASS**
- Net Uplift Factor of Safety: **3.08** (Code minimum: >= 1.50) — **PASS**
- Sliding Factor of Safety: **2.81** (UFC 3-220-01 minimum: >= 2.00) — **PASS**

## Pad CR-P5 — Warehouse
- **Decision:** **SPREAD**
- **Pad Governing Constraint:** `BEARING`
- **Concrete:** f'c = 5000 psi, max w/cm = 0.4 (Exposure Classes: F3, W1, C1, S0)
- **Bearing Depth:** 42 in (3.50 ft) below finished grade (Stratum I residual soil)
- **Bearing Factor of Safety:** 2.5
- **Cost Comparison:**
  - Spread-Only Alternative: **$17,922.47**
  - Improved-Spread Alternative: **$35,736.19**
  - Decision Basis: Shallow spread footing alone selected because soil stiffness and shallow Stratum II contact provide full settlement and distortion compliance at lower direct cost and zero rig mobilization.

| Tag | Element | B (in) | L (in) | t (in) | Service P (k) | Factored Pu (k) | q_net (ksf) | q_allow (ksf) | Piers (n x H_ft) | Ra | qg (psf) | Settlement (in) | Governing Constraint |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| F1 | Col 24.0x24.0 in | 84 | 84 | 18 | 335.5 | 460.9 | 6.85 | 7.19 | None | 0.000 | 0 | 0.499 | `BEARING` |
| F2 | Col 26.0x26.0 in | 114 | 114 | 24 | 649.0 | 892.1 | 7.19 | 7.29 | None | 0.000 | 0 | 0.663 | `BEARING` |
| F3 | Col 28.0x28.0 in | 126 | 126 | 27 | 781.0 | 1074.2 | 7.08 | 7.35 | None | 0.000 | 0 | 0.742 | `BEARING` |
| F4 | Col 26.0x26.0 in | 105 | 105 | 21 | 539.0 | 741.4 | 7.04 | 7.25 | None | 0.000 | 0 | 0.734 | `BEARING` |
| F5 | Col 22.0x22.0 in | 78 | 78 | 18 | 286.0 | 393.3 | 6.77 | 7.19 | None | 0.000 | 0 | 0.664 | `BEARING` |
| W1 | Shear Wall 24 ft | 78 | 288 | 18 | 907.5 | 1234.2 | 5.82 | 5.97 | None | 0.000 | 0 | 0.710 | `BEARING` |

**Shear-Wall Footing (W1) Stability Evaluation:**
- Resultant Eccentricity e: **6.94 in** (Middle third limit: <= 48.0 in) — **PASS**
- Net Uplift Factor of Safety: **3.00** (Code minimum: >= 1.50) — **PASS**
- Sliding Factor of Safety: **2.69** (UFC 3-220-01 minimum: >= 2.00) — **PASS**

## Pad CR-P6 — Light Industrial, Public
- **Decision:** **IMPROVED_SPREAD**
- **Pad Governing Constraint:** `ANGULAR_DISTORTION`
- **Concrete:** f'c = 4500 psi, max w/cm = 0.45 (Exposure Classes: F1, W1, C1, S2)
- **Bearing Depth:** 42 in (3.50 ft) below finished grade (Stratum I residual soil)
- **Bearing Factor of Safety:** 3.5
- **Cost Comparison:**
  - Spread-Only Alternative: **$196,610.46**
  - Improved-Spread Alternative: **$80,186.10**
  - Decision Basis: Improved spread footing selected to prevent excessive settlement (>3 in) and footing overlap, saving substantial concrete/excavation costs.

| Tag | Element | B (in) | L (in) | t (in) | Service P (k) | Factored Pu (k) | q_net (ksf) | q_allow (ksf) | Piers (n x H_ft) | Ra | qg (psf) | Settlement (in) | Governing Constraint |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| F1 | Col 24.0x24.0 in | 138 | 138 | 27 | 622.2 | 854.8 | 4.70 | 4.91 | 5 x 12 ft | 0.186 | 17619 | 0.886 | `BEARING` |
| F2 | Col 26.0x26.0 in | 189 | 189 | 39 | 1203.6 | 1654.4 | 4.85 | 4.98 | 10 x 10 ft | 0.198 | 17447 | 0.959 | `BEARING` |
| F3 | Col 28.0x28.0 in | 204 | 204 | 42 | 1448.4 | 1992.1 | 5.01 | 5.01 | 13 x 8 ft | 0.221 | 16777 | 0.980 | `BEARING` |
| F4 | Col 26.0x26.0 in | 171 | 171 | 33 | 999.6 | 1375.0 | 4.92 | 4.95 | 8 x 8 ft | 0.193 | 17962 | 0.978 | `BEARING` |
| F5 | Col 22.0x22.0 in | 126 | 126 | 24 | 530.4 | 729.3 | 4.81 | 4.90 | 5 x 8 ft | 0.223 | 16017 | 0.825 | `BEARING` |
| W1 | Shear Wall 24 ft | 183 | 288 | 30 | 1683.0 | 2288.9 | 4.60 | 4.64 | 14 x 10 ft | 0.188 | 17095 | 0.939 | `ANGULAR_DISTORTION` |

**Shear-Wall Footing (W1) Stability Evaluation:**
- Resultant Eccentricity e: **7.37 in** (Middle third limit: <= 48.0 in) — **PASS**
- Net Uplift Factor of Safety: **3.12** (Code minimum: >= 1.50) — **PASS**
- Sliding Factor of Safety: **2.93** (UFC 3-220-01 minimum: >= 2.00) — **PASS**
