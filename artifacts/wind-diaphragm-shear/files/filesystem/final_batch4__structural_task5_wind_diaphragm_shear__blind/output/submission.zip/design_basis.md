# Building A2 Lateral Diaphragm & Shear Wall Package — Design Basis Narrative

**Northern Divide Data Campus, Building A2**  
*Lewis and Clark County, Montana*  
**Delegated Structural Lateral Package**  
**Revision:** 0 (Issued for EOR Review) · **Date:** 2026-11-14  
**Governing Standard:** 2021 International Building Code / ASCE/SEI 7-16 / UFC 3-301-01  

---

## 1. Design Basis Summary Tables

Per Specification 01 33 00 clause 1.6, the values upon which this lateral design package is constructed are tabulated below.

### Table 1: Governing Design Parameters
| item | value | source |
| :--- | :--- | :--- |
| Kzt | 1.19 | TS-2026-02 Site-Specific Topographic Wind Study, clause 4 |
| Ke | 0.8670 | EOR-NDDC-A2-S01 clause 4.4 / ALTA-2025-77 Site Benchmark BM-2 (El. 3941.02 ft) |
| q_h_psf | 28.74 | EOR-NDDC-A2-S01 clause 4.2 / ASCE 7-16 eq. 26.10-1 at mean roof height 28.0 ft |
| screen_wall_top_ft | 36.00 | SR-2026-118 Roof Line Scan Report clause 5.2 / NDDC-A2 Federated Model 2026 |
| asbuilt_opening_panel | S14 | NDDC-A2 Federated Model 2026 (void S14-O1 cut post-erection) |
| asd_combination | 0.6W | EOR-NDDC-A2-S01 clause 3.3 / 2021 IBC Section 1605.1 |
| omega_d | 2.35 | CDS-B36 Diaphragm Design Manual Table 3 / Note 2 |
| analysis_method | semi-rigid | EOR-NDDC-A2-S01 clause 9 (DIAPH-MT 1.0 bilinear membrane FEA) / NDDC-AHJ-014 |
| mesh_level | L2 | EOR-NDDC-A2-S01 clause 9.1 & 9.7 (structured mesh H = 5.0 ft) |

### Table 2: Governing Wind Scenario per Wall Line
| line | governing scenario |
| :--- | :--- |
| S | W07 |
| E | W05 |
| N1 | W08 |
| N2 | W03 |
| E2 | W01 |
| W | W01 |

---

## 2. Document Conflict Reconciliation Log

During the QA/QC audit and lateral engineering takeoff, several significant conflicts were identified across the issued document set. In accordance with the governing authority hierarchy and Specification 01 33 00, each discrepancy was reconciled as follows:

### 2.1 Basic Wind Speed & Risk Category
* **Conflict:** Preliminary Structural Criteria Rev 0 (dated 3 May 2024) specified a basic wind speed of V = 105 mph for Risk Category II.
* **Governing Resolution:** AHJ Letter NDDC-AHJ-014 (dated 11 June 2026) mandates Risk Category III due to continuous-operation data processing serving critical county communications, accepting V = 115 mph (3-second gust). Structural Criteria Rev 2 (clause 2 & 4.2) supersedes Rev 0. **V = 115 mph and Risk Category III govern.**

### 2.2 Topographic Speed-Up Factor Kzt
* **Conflict:** Preliminary Criteria Rev 0 specified Kzt = 1.00, assuming a level site pending study completion.
* **Governing Resolution:** Site-Specific Topographic Wind Study TS-2026-02 (dated 30 April 2026) evaluated sixteen terrain radials on the valley bench, classifying the feature as an escarpment and determining an amplified factor of Kzt = 1.19 across the entire footprint with no reduction with height. **Kzt = 1.19 governs.**

### 2.3 Ground Elevation Factor Ke
* **Conflict:** Criteria Rev 0 assumed Ke = 1.00.
* **Governing Resolution:** Criteria Rev 2 (clause 4.4) prohibits taking Ke = 1.0 at this high-altitude valley bench and requires Ke = exp(-0.0000362 * zg) with zg taken from the ALTA survey benchmark. ALTA-2025-77 establishes site benchmark BM-2 (brass cap at NE corner of generator yard slab) at elevation 3941.02 ft NAVD 88, yielding Ke = exp(-0.0000362 * 3941.02) = 0.8670. **Ke = 0.8670 governs.**

### 2.4 North Parapet / Mechanical Screen Wall Top Elevation
* **Conflict:** 2024 Precast Panel Schedule PC-S01 and shop drawing PC-S02 Rev 1 showed a uniform top-of-panel elevation of 31.00 ft along the entire North elevation.
* **Governing Resolution:** As-built Laser Scan Report SR-2026-118 (clause 5.2) and the 2026 Federated Model reveal that between stations x = 96.0 ft and x = 168.0 ft (panels N108, N109, N110, N111), the precast panels were fabricated and erected with an extended solid mechanical screen wall reaching elevation 36.00 ft (8.00 ft cantilever above the roof deck). The velocity pressure on this screen parapet was evaluated at z = 36.0 ft (qp = 30.31 psf) with the lever action of clause 6.4 delivering substantial roof-level line loads. **Screen wall elevation 36.00 ft governs.**

### 2.5 Field-Cut Opening on Panel S14 and Effective Pier Leg Width
* **Conflict:** 2024 Fabrication Schedule PC-S01 indicated panel S14 (Line S, x = 192 ft to 204 ft) was cast solid without openings.
* **Governing Resolution:** The 2026 Federated Model carries void element S14-O1 (field-cut post-erection between stations 194.5 ft and 202.5 ft, width 8.0 ft). This opening partitions panel S14 into two vertical legs: Leg 1 from 192.0 to 194.5 ft (w = 2.5 ft) and Leg 2 from 202.5 to 204.0 ft (w = 1.5 ft). Per Criteria Rev 2 clause 5.4, legs narrower than 2.0 ft carry no in-plane stiffness and are neglected. Leg 2 is neglected entirely; Leg 1 (2.5 ft) is modeled as a cantilever spring. **As-built void and neglected leg govern.**

### 2.6 Building Footprint Geometry and Generator Yard Notch
* **Conflict:** Architectural Plan Rev A (2024) illustrated a plain rectangular footprint (240 ft x 180 ft).
* **Governing Resolution:** Architectural Plan A-101 Rev C, Structural Framing Plan S-201 Rev C, and the 2026 Federated Model incorporate an unroofed generator yard notch on building lines N2 (y = 140 ft, x = 180 to 240 ft) and E2 (x = 180 ft, y = 140 to 180 ft). The diaphragm boundary follows this re-entrant corner. **As-built notched boundary governs.**

### 2.7 Superseded Archive Documents & Campus Hall B Study
* **Conflict:** The project archive contains HallB_Lateral_Study_2023.pdf, which used flexible tributary diaphragm analysis, basic wind speed 105 mph, and level ground assumptions.
* **Governing Resolution:** Transmittal T-204 and Criteria Rev 2 explicitly note that the Hall B study belongs to Building A1 and was issued for background context only. It is not applicable to Building A2. Building A2 is designed strictly to the site-specific wind tunnel coefficients (WT-2026-07) and semi-rigid FEA (DIAPH-MT).

---

## 3. Structural Analysis Methodology & Load Path

### 3.1 Wind-to-Diaphragm Transfer
Facade wind pressures act on precast panels spanning vertically as simple beams between foundation and roof deck bearing at elevation +28.00 ft. For each elevation band patch (B1 through B4 and parapet band P), the patch force centroid elevation z delivers an equivalent simple-beam roof reaction: R_roof = p * A * (z / h). For parapet patches (z > 28.0 ft), this formulation captures the cantilever lever action, delivering an amplified roof reaction into the deck and an uplift reaction at the foundation. Patch roof reactions on each wall line are summed and divided by total wall length to establish the roof-level line load w_line in plf along the inward normal.

### 3.2 Diaphragm Modeling (DIAPH-MT 1.0)
The diaphragm is discretized using a structured bilinear 4-node membrane mesh at Level L2 (H = 5.0 ft):
1. **Membrane Elements:** Formulated with 2 x 2 Gauss quadrature carrying smeared orthogonal framing axial stiffness (EAx = 2,900 kip/ft from EW girders, EAy = 13,920 kip/ft from NS joists) and shear rigidity Ghat = 12 G'. In mechanical bay Zone Z22, joists are spaced at 4 ft o.c., providing a 1.15 multiplier on G' per CDS-B36 Note 4.
2. **Chord & Collector Bar Elements:** Modeled as 2-node axial bar elements with Es = 29,000 ksi along all 12 boundary and opening drag lines.
3. **Cantilever Pier Supports:** 73 spring supports derived from concrete leg geometry (Ec = 4,030 ksi, G = 1,612 ksi, f'c = 5,000 psi) attached to the mesh node nearest the pier centerline.

### 3.3 Acceptance Criteria & Compliance
1. **Diaphragm Deflection:** Maximum relative deflection across all 12 scenarios is 0.2741 in in X and 0.5108 in in Y, well within the 0.55 in limit set by OBD clause 4.4.
2. **Pier Drift:** Maximum pier lateral drift is 0.183 in <= h / 400 = 0.840 in.
3. **Deck Shear Capacity:** Unit shears in all 12 deck zones satisfy the ASD shear capacities with safety factor omega_d = 2.35.
4. **Trade Standardization:** Exactly 3 distinct deck types are utilized across the 12 zones (D22-36/7-4, D22-36/7-2, D22-36/4-4), meeting the OBD clause 4.6 cap of at most 4 types.
5. **Total Package Cost:** The total installed lateral package cost is $234,350.93, complying with the Owner's Basis of Design cap of $310,000.00.
