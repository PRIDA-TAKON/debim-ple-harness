# Design Basis Memorandum: Condenser Water Heat Rejection Replacement
**Papago Federal Center, Phoenix, Arizona — 95% Construction Documents**  
**Engineer of Record: Sandoval Klee Mechanical Engineers, PC**  
**Project Design Basis & Life-Cycle Cost Analysis**  

---

## 1. Executive Summary & Governing Constraints

This memorandum establishes the engineering basis for the replacement of three condenser water heat rejection plants on the roofs of the Courthouse Central Utility Plant (CUP), the Data Annex (ANNEX), and the Laboratory Wing (LAB). The design has been developed in strict accordance with the Federal Energy Management Program (FEMP) life-cycle cost methodology (10 CFR Part 436 Subpart A), UFC 3-410-01 (Change 1, July 2025), GSA PBS-P100 (2024), UFM 3-230-13 (5 February 2026), and project criteria DC-02 and EC-01.

In accordance with Section 9 of Design Criteria Memorandum DC-02, the governing constraint having the smallest relative margin at each plant is documented below:

GOVERNING CONSTRAINT CUP: structural capacity (relative margin 0.0250)
GOVERNING CONSTRAINT ANNEX: tower capability (relative margin 0.0510)
GOVERNING CONSTRAINT LAB: electrical capacity (relative margin 0.0003)

---

## 2. Documented Conflict Resolutions

In accordance with Section 9.1 and Table 4 of Memorandum DC-02, the three documented conflicts in the project document library are formally resolved as follows:

CONFLICT 1: ADOPTED UFC 3-410-01 paragraph 2-4.2.4 | SET ASIDE GSA PBS-P100 paragraph 5.3.1
CONFLICT 2: ADOPTED UFM 3-230-13 5 February 2026 | SET ASIDE UFC 3-230-13 2023
CONFLICT 3: ADOPTED M-401 Revision C | SET ASIDE M-401 Revision B

### Technical Justification for Conflict Resolutions:
1. **Conflict 1 (Outdoor Design Wet Bulb)**: GSA PBS-P100 paragraph 5.3.1 specifies general HVAC design conditions. However, DC-02 paragraph 2 explicitly allocates outdoor design conditions for mechanical equipment sizing to UFC 3-410-01, which mandates in paragraph 2-4.2.4 that open cooling tower selections be based on the 1.0% annual outdoor wet-bulb temperature with a mandatory +5.0 °F safety adder. Using the Phoenix Sky Harbor Airport station record (2022–2024), the 1.0% annual wet bulb is 75.0 °F, establishing the governing design wet bulb of **80.0 °F**. The 0.4% annual wet bulb of 76.0 °F with the +5.0 °F adder establishes the N-1 redundancy evaluation condition of **81.0 °F**.
2. **Conflict 2 (Water Treatment Manual Edition)**: UFM 3-230-13 issued on 5 February 2026 directly supersedes and cancels UFC 3-230-13 (1 March 2023). Under governing federal hierarchy, the latest approved manual governs all water chemistry calculations, scaling indices, and cooling tower water balance procedures.
3. **Conflict 3 (Roof Mechanical Plan Revision)**: Sheet M-401 Revision C (dated 2026-07-31) incorporates revised architectural outdoor air intake positions and equipment clear zones, superseding Revision B.

---

## 3. Climate Basis & Psychrometric Analysis

* **Station Record**: Phoenix Sky Harbor International Airport Local Climatological Data (LCD), covering continuous FM-15 and FM-16 observations for the 3-year period 2022–2024 (26,527 valid observations).
* **Mean Station Pressure**: Mean atmospheric pressure across the dataset is 28.7221 inHg (97,264.08 Pa / 0.960 atm).
* **Scenario Bins**: Binned across 2.0 °F wet-bulb increments and 5.0 °F dry-bulb increments, normalized to exactly 8,760.0 annual hours (180 unique scenario bins).
* **Outdoor Design Temperatures**:
  * Design Sizing Wet Bulb: 80.0 °F (UFC 3-410-01 paragraph 2-4.2.4; 75.0 °F 1.0% Twb + 5.0 °F safety adder).
  * Redundancy Wet Bulb: 81.0 °F (UFC 3-410-01 paragraph 2-4.2.4; 76.0 °F 0.4% Twb + 5.0 °F safety adder).
  * Winter 99.6% Dry Bulb: 41.0 °F. Since 41.0 °F is well above the freezing threshold of 32.0 °F, no basin heaters or heat-traced makeup lines are required (`BASINHEATER = NO`).

---

## 4. Evaporation Formulation & Water Balance

In accordance with Section 7 of Memorandum DC-02, the **SATURATED-EXIT** formulation has been adopted and applied consistently across all three plants for annual water balances, scenario tables, and peak day tests.

* **Methodology**: Evaluates the moist-air energy and mass balance implemented in the EnergyPlus variable-speed cooling tower water consumption routine. Leaving air enthalpy is determined from entering air enthalpy (at saturated entering wet bulb) plus water-side heat rejection divided by dry air mass flow rate. The leaving air is saturated at the exit enthalpy, and water loss is computed from the rise in specific humidity multiplied by air mass flow rate, converted to volumetric flow via water density evaluated at the mean air temperature.
* **Chemical Treatment & Cycles of Concentration (COC)**:
  * In accordance with WT-01 and UFM 3-230-13 Section 5-3.4.2, the water treatment programme is an alkaline phosphonate/polymer programme with sulfuric acid feed holding circulating M-alkalinity at 120 ppm as CaCO3.
  * Supply water quality of record: USGS-332255112182101 (2022-07-26 complete analysis): Ca = 109 mg/L (272.17 ppm CaCO3), TDS = 1720 ppm, dissolved silica = 16.0 ppm.
  * Controlling COC is determined by the Practical (Puckorius) Scaling Index (PSI >= 5.60) evaluated at the achieved design CWR temperature:
    * **CUP**: Achieved CWR = 98.02 °F -> Max allowable COC = 4.14 -> Scheduled `COC = 4.14`.
    * **ANNEX**: Achieved CWR = 99.38 °F -> Max allowable COC = 4.00 -> Scheduled `COC = 4.00`.
    * **LAB**: Achieved CWR = 100.05 °F -> Max allowable COC = 3.93 -> Scheduled `COC = 3.93`.
* **Allocations & Discharge Compliance**:
  * **CUP**: Annual makeup 8,100.2 kgal <= 10,300.0 kgal allocation (21.4% margin). Peak day makeup 48,446 gpd <= 58,000 gpd limit. Peak day blowdown 11,665 gpd <= 14,500 gpd sewer limit.
  * **ANNEX**: Annual makeup 11,705.1 kgal <= 12,600.0 kgal amended allocation (7.1% margin). Peak day makeup 53,647 gpd <= 62,000 gpd limit. Peak day blowdown 13,370 gpd <= 15,800 gpd sewer limit.
  * **LAB**: Annual makeup 15,085.6 kgal <= 17,400.0 kgal allocation (13.3% margin). Peak day makeup 67,651 gpd <= 80,000 gpd limit. Peak day blowdown 17,158 gpd <= 20,800 gpd sewer limit.

---

## 5. Electrical Distribution & Motor Control Centers

* **Peak Coincident Demand (PCD)**: Evaluated over all 8,760 hours of operation as the maximum simultaneous demand of chillers, cooling tower fans, and condenser water pumps.
* **Spare Capacity Verification**:
  * **CUP (MCC-R1)**: 480V, 1200A bus, 798.1 kW continuous limit (80%), 270.1 kW retained load -> **528.0 kW available spare capacity**. PCD = **508.84 kW** (Margin: 3.63%).
  * **ANNEX (MCC-R2)**: 480V, 1200A bus, 798.1 kW continuous limit (80%), 208.1 kW retained load -> **590.0 kW available spare capacity**. PCD = **559.58 kW** (Margin: 5.16%).
  * **LAB (MCC-R3)**: 480V, 1600A bus, 1064.2 kW continuous limit (80%), 404.2 kW retained load -> 660.0 kW initial spare. Less RFI-034 laboratory exhaust fans EF-L1/L2/L3 (3 x 7.5 hp, 91.7% eff, 97% VFD eff = 18.8627 kW) -> **641.1373 kW available spare capacity**. PCD = **640.975 kW** (Margin: 0.025% / 0.0003 relative margin).
* **Motor Selections**: All fan motors comply with 10 CFR 431.25 Table 5 premium efficiency standards (93.0% for 20 hp, 93.6% for 30 hp, 4-pole, TEFC enclosure).

---

## 6. Structural Loading & Roof Clearances

* **Framing Limits & Zoning**:
  * Per Sheet S-401 Revision C, equipment supports must bear entirely within one framing zone without crossing boundary grid lines.
  * **CUP**: Four CTX-0600-S cells (10x20 ft plan, 23,400 lb operating weight = 117.0 psf). Cells 1 & 2 bear entirely in CUP-S1 (allowable 126 psf, margin 7.14%); Cells 3 & 4 bear entirely in CUP-S2 (allowable 120 psf, margin 2.50%). Governing structural margin is **0.0250**.
  * **ANNEX**: Four CTX-0600-S cells (117.0 psf). Cells 1 & 2 bear in ANNEX-S1 (allowable 128 psf, margin 8.59%); Cells 3 & 4 bear in ANNEX-S2 (allowable 124 psf, margin 5.65%).
  * **LAB**: Three CTX-0900-S cells (12x24 ft plan, 33,600 lb operating weight = 116.67 psf). All three cells bear entirely in LAB-S1 (allowable 126 psf, margin 7.41%). Allowable on LAB-S2 is 118 psf (margin 1.13%).
* **Clearances**: All cells maintain >= 6.0 ft air inlet clearance between adjacent cells, >= 6.0 ft to equipment zone perimeter, and >= 25 ft separation from outdoor air intakes (CUP = 34 ft, ANNEX = 36 ft, LAB = 42 ft).

---

## 7. Life-Cycle Cost Analysis & Net Savings Optimization

* **Economic Parameters**:
  * Base Date: 1 October 2025.
  * Construction Period: 1 year (beneficial occupancy 1 October 2026).
  * Service Period: 25 years (study period 26 years, ending 1 October 2051).
  * Discount Rates: DOE real discount rate = 3.0% (NIST IR 85-3273-40).
  * Present Value Factors:
    * Electricity: $UPV^*_{elec} = 15.335223$ (Table Ba-4, West/Mountain commercial).
    * Non-Fuel O&M: $UPV_{nonfuel} = 16.905969$ (Table 2, 3.0% real, 25-yr service period).
    * Water/Sewer: $UPV^*_{water} = 21.777005$ (1.9704% real escalation rate).
  * Utility Rates: Electricity $0.0782/kWh, $17.80/kW-month (Rate E-32); Reclaimed water $1.94/kgal; Sewer $3.20/kgal; Chemical treatment $0.42/kgal.
* **Capital Investments & Material Selection**:
  * Type 304 Stainless Steel (SS-304) selected for all basins and casings (22% adder on base tower price per VD-05). Stainless steel provides a certified 25-year service life, resulting in **$0.00 replacement cost** and **$0.00 salvage credit** over the 25-year service period, whereas galvanized steel would require complete replacement at Year 21.
  * Class DE-2 cellular drift eliminators ($2,100 adder/cell) provide certified 0.002% drift rate.
* **Life-Cycle Cost Results & Net Savings**:
  * **CUP**: Basic Design LCC = $5,963,669.04; Proposed LCC = $5,683,849.89 -> **Net Savings = $279,819.15** (4.69% net savings).
  * **ANNEX**: Basic Design LCC = $8,102,579.88; Proposed LCC = $7,791,697.78 -> **Net Savings = $310,882.10** (3.84% net savings).
  * **LAB**: Basic Design LCC = $8,257,141.54; Proposed LCC = $7,957,532.74 -> **Net Savings = $299,608.80** (3.63% net savings).
  * **Total Campus Life-Cycle Net Savings**: **$890,310.05**.
